#!/usr/bin/python3
"""Preserve both-simulator full512 CMAC/shared-dispatch logical evidence."""
from __future__ import annotations
import ast,datetime,gzip,hashlib,json,pathlib,re
ROOT=pathlib.Path('/home/fedora/rknpu-fpga')
RUN=ROOT/'build/full512-ddr-preparation/dual-dispatch-numerical-v1'
DEST=ROOT/'verification/runs/2026-10-27-full512-dispatch-logical'
BUILD=ROOT/'build/full512-ddr-preparation/dual-dispatch-archive-v1'
PLAN=BUILD/'plan.json';PACKER=pathlib.Path(__file__).resolve()
IV_REPORT=RUN/'iverilog-modes-v1/report.json';VL_REPORT=RUN/'verilator-modes-v1/report.json'
IV_COMPILE=RUN/'iverilog-compile-v1/report.json';VL_COMPILE_V1=RUN/'verilator-compile-v1/report.json';VL_COMPILE_V2=RUN/'verilator-compile-v2/report.json'
BOTH_REVIEW=RUN/'both-simulators-root-review-v1.json'
IV_REVIEW=RUN/'iverilog-modes-root-review-v1.json'
IV_SCOPE_REVIEW=RUN/'iverilog-scope-root-review-v1.json'
WARN_REVIEW=RUN/'verilator-diagnostics-root-review-v1.json'
CMAC_BOTH_REVIEW=ROOT/'build/full512-ddr-preparation/cmac-async-both-simulators-root-review-v1.json'
CMAC_IV0_REVIEW=ROOT/'build/full512-ddr-preparation/cmac-async-iverilog-mode0-v1-root-review.json'
CMAC_DIAG_REVIEW=ROOT/'build/full512-ddr-preparation/cmac-async-diagnostics-root-review-v1.json'
DUAL=ROOT/'build/full512-ddr-preparation/dual-csr-v1'
CONTROL_REVIEW=DUAL/'control-root-review-v1.json';CONTROL_REPORT=DUAL/'native-controls-v8/report.json'
DISPATCH=DUAL/'dispatch-pending-offer-controls';DISPATCH_REPORT=DISPATCH/'results-v1/report.json'
V6=ROOT/'build/full512-ddr-preparation/combined-source-v6'
ASSERT_ROOT=ROOT/'build/tinystories-fpga-preparation/dual-v1/source/rtl/vendor/nvdla/compat'

class ArchiveError(RuntimeError):pass
def need(ok,msg):
 if not ok:raise ArchiveError(msg)
def sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def relpath(p):
 p=pathlib.Path(p).resolve()
 try:return p.relative_to(ROOT).as_posix()
 except ValueError:return str(p)
relroot=relpath
def load(p):
 try:return json.loads(pathlib.Path(p).read_text())
 except Exception as e:raise ArchiveError(f'cannot parse {p}: {e}')
def text_file(p):
 try:
  with pathlib.Path(p).open('rb') as f:
   for b in iter(lambda:f.read(1024*1024),b''):
    if b'\0' in b or any(x<32 and x not in (9,10,12,13) for x in b):return False
  return True
 except OSError:return False

need(not DEST.exists(),'fresh archive directory required')
need(RUN.is_dir() and DUAL.is_dir(),'dispatch evidence package missing')
iv=load(IV_REPORT);vl=load(VL_REPORT);ivc=load(IV_COMPILE);vl1=load(VL_COMPILE_V1);vl2=load(VL_COMPILE_V2)
both=load(BOTH_REVIEW);ivrev=load(IV_REVIEW);scope=load(IV_SCOPE_REVIEW);warn=load(WARN_REVIEW)
cmac_both=load(CMAC_BOTH_REVIEW);cmac_iv0=load(CMAC_IV0_REVIEW);cmac_diag=load(CMAC_DIAG_REVIEW)
control=load(CONTROL_REVIEW);control_report=load(CONTROL_REPORT);dispatch=load(DISPATCH_REPORT)
prep=load(RUN/'preparation.json');v6prep=load(V6/'preparation.json')
need(iv.get('status')=='PASS_ALL_NINE_SHARED_DISPATCH_CMAC_NUMERICAL_MODES_ONLY' and len(iv.get('selected_modes',[]))==9 and iv.get('all_inputs_unchanged') is True,'Icarus nine-mode receipt changed')
need(vl.get('status')=='PASS_ALL_NINE_SHARED_DISPATCH_CMAC_NUMERICAL_MODES_ONLY' and len(vl.get('selected_modes',[]))==9 and vl.get('all_inputs_unchanged') is True,'Verilator nine-mode receipt changed')
need(len(iv['source_and_fixture_hashes_before'])==70 and len(vl['source_and_fixture_hashes_before'])==71,'mode source/fixture input map counts changed')
need(both.get('status')=='PASS_INDEPENDENT_ALL_NINE_FULL512_CMAC_DISPATCH_MODES_BOTH_SIMULATORS_ONLY','both-simulator independent review changed')
need(both.get('seed')=='0x3588ad16' and both.get('modes')==list(range(9)),'root mode seed/count changed')
need(both.get('full512_product_lanes')==512 and both.get('ew_numerical_composition_qualified') is False and
     both.get('ddr_composition_qualified') is False and both.get('mapped_or_timing_qualified') is False and both.get('hardware_accessed') is False,
     'root evidence boundary changed')
need(ivc.get('status')=='PASS_COMPILE_ONLY_UNQUALIFIED','Icarus compile report changed')
need(vl1.get('status')=='FAIL_STRICT_COMPILE_ONLY','strict Verilator v1 failure must remain FAIL')
need(vl2.get('status')=='PASS_COMPILE_ONLY_REVIEWED_WARNINGS','reviewed Verilator v2 compile changed')
need(vl2.get('warning_review',{}).get('strict_rc')==1 and vl2.get('warning_review',{}).get('only_nonfatal_summary_removed') is True,
     'Verilator warning-review scope changed')
need(control.get('status')=='PASS_INDEPENDENT_DUAL_CSR_LEAF_CONTROL_REVIEW_ONLY' and control.get('hardware_accessed') is False,
     'controller root review changed')
need(control_report.get('status')=='PASS_PRIVATE_DUAL_CSR_CONTROL_BENCH_ONLY','controller leaf control report changed')
need(dispatch.get('status')=='PASS_PRIVATE_DISPATCH_CONTROL_AND_OLD_NEGATIVE_ONLY' and dispatch.get('source_hashes_unchanged') is True,
     'dispatch control report changed')
need(dispatch['existing_bench_fixed_private']['expected_result'] is True and dispatch['pending_offer_fixed_private']['expected_result'] is True and
     dispatch['pending_offer_old_public_negative']['expected_result'] is True and dispatch['pending_offer_old_public_negative']['run']['returncode']==1,
     'dispatch old-failure/new-pass control results changed')
need(len(vlc:=vl2['selected_frontend_hashes_before'])==48 and len(ivc['selected_frontend_hashes_before'])==48,
     'compile records do not bind exactly 48 private v6 frontend sources')
need(vlc==ivc['selected_frontend_hashes_before'],'selected frontend source maps differ between compilers')
need(len(vl2['selected_assertion_sources'])==2 and vl2['selected_assertion_sources']==ivc['selected_assertion_sources'],
     'assertion compatibility input bodies changed')
need(vl2.get('selected_fixture_hashes_before')==ivc.get('selected_fixture_hashes_before') and len(ivc['selected_fixture_hashes_before'])==10,
     'fixture hash maps changed')

# Hash every report-declared file input before copying (mode-map counts are
# preserved separately, even where tool/binary inputs are excluded from payloads).
verified={}
def verify(path,expected,label):
 p=pathlib.Path(path).resolve();need(p.is_file(),f'missing {label}: {p}')
 h=sha(p);need(h==expected,f'hash mismatch for {label}: {p} expected={expected} actual={h}')
 old=verified.get(str(p))
 need(old is None or old['sha256']==h,f'conflicting declarations for {p}')
 verified[str(p)]={'sha256':h,'bytes':p.stat().st_size};return p,h
report_paths=[IV_REPORT,VL_REPORT,IV_COMPILE,VL_COMPILE_V1,VL_COMPILE_V2,BOTH_REVIEW,IV_REVIEW,IV_SCOPE_REVIEW,
              WARN_REVIEW,CMAC_BOTH_REVIEW,CMAC_IV0_REVIEW,CMAC_DIAG_REVIEW,CONTROL_REVIEW,CONTROL_REPORT,DISPATCH_REPORT,
              RUN/'preparation.json',V6/'preparation.json']
for p in report_paths:verify(p,sha(p),'review/report artifact')
# Root review evidence maps pin the actual two modes reports and compile warning review.
for p,d in ((BOTH_REVIEW,both),(IV_REVIEW,ivrev),(CMAC_BOTH_REVIEW,cmac_both),(CMAC_IV0_REVIEW,cmac_iv0),(CMAC_DIAG_REVIEW,cmac_diag)):
 for key,h in d.get('evidence',{}).items():verify(key,h,'root review evidence')
 for mapname in ('source_inputs','fixture_inputs','bound_inputs'):
  mapping=d.get(mapname,{})
  if isinstance(mapping,dict):
   for key,h in mapping.items():verify(key,h,'root review '+mapname)
if isinstance(ivrev.get('bound_inputs'),dict):
 for k,h in ivrev['bound_inputs'].items():verify(k,h,'Icarus root bound input')
for d in (ivc,vl1,vl2):
 for k in ('all_input_hashes_before','all_input_hashes_after','selected_frontend_hashes_before','selected_frontend_hashes_after',
           'selected_fixture_hashes_before','selected_fixture_hashes_after'):
  for path,h in d.get(k,{}).items():verify(path,h,f'compiler report {k}')
 for path in d.get('selected_assertion_sources',[]):
  expected=d['all_input_hashes_before'].get(path)
  need(expected is not None,f'assertion compatibility source missing from compile input manifest: {path}')
  verify(path,expected,'assertion compatibility source')
for d in (iv,vl):
 for path,h in d['source_and_fixture_hashes_before'].items():verify(path,h,'mode source/fixture input')
# The mode reports include 70 Icarus and 71 Verilator exact path/hash entries.
need(iv.get('all_inputs_unchanged') is True and vl.get('all_inputs_unchanged') is True,'modes report input stability changed')
# Ensure each source/fixture map has a current matching post-run file.
mode_after={'iverilog':{},'verilator':{}}
for label,d in (('iverilog',iv),('verilator',vl)):
 mode_after[label]={path:sha(pathlib.Path(path)) for path in d['source_and_fixture_hashes_before']}
 need(mode_after[label]==d['source_and_fixture_hashes_before'],f'{label} mode source/fixture drift')

# Excluded inputs are fully hashed: actual tools, compiled simulators, VVP,
# Verilator-generated C++/objects and intermediate build directories.
excluded={}
def exclude(path,expected,reason):
 p=pathlib.Path(path).resolve();need(p.is_file(),f'excluded artifact path missing: {p}')
 h=sha(p);need(h==expected,f'excluded artifact hash mismatch: {p}')
 excluded[str(p)]={'source_path':relpath(p),'bytes':p.stat().st_size,'sha256':h,'reason':reason}
# Explicit input manifests identify non-portable executable/tool inputs.
for p,h in verified.items():
 path=pathlib.Path(p)
 if path.suffix.lower() in {'.vvp','.o','.a','.gch','.elf','.dcp','.bit'} or '/verilator-compile-' in p and '/obj/' in p:
  exclude(path,h['sha256'],'compiled simulator/object/generated C++ output excluded')
 elif not text_file(path):
  exclude(path,h['sha256'],'native tool or non-text executable excluded')
# Enumerate complete compile-object trees, including outputs not in the source maps.
object_roots=[RUN/'iverilog-compile-v1',RUN/'verilator-compile-v1/obj',RUN/'verilator-compile-v2/obj']
for base in object_roots:
 if not base.exists():continue
 for p in base.rglob('*'):
  if not p.is_file():continue
  if p.suffix.lower() in {'.vvp','.o','.a','.gch','.elf','.d','.dcp','.bit'} or '/obj/' in p.as_posix() or p.name in {'Vtb_cmac_async_engine'}:
   exclude(p,sha(p),'compiled simulator binary/object/generated C++ output excluded')
# Capture explicit native binary identities from compile/modes receipts.
native_binaries=[]
def command_output_path(report):
 for command in report.get('commands',[]):
  argv=command.get('argv',[])
  if '-o' in argv:
   i=argv.index('-o')
   if i+1<len(argv):return pathlib.Path(argv[i+1])
 return None
for label,d in (('iverilog',ivc),('verilator-strict-v1',vl1),('verilator-reviewed-v2',vl2)):
 path=command_output_path(d)
 if path is None:
  # Icarus reports may express compile argv nested one level differently.
  cmds=d.get('commands',[])
  for c in cmds:
   argv=c.get('argv',[])
   if '-o' in argv:
    path=pathlib.Path(argv[argv.index('-o')+1]);break
 if path is not None:
  if not path.is_absolute():path=ROOT/path
  expected=d.get('compile_binary_sha256') or d.get('binary_sha256')
  if expected and path.is_file():
   exclude(path,expected,f'{label} native simulator binary excluded; hash retained')
   native_binaries.append({'simulator':label,'path':str(path),'sha256':expected,'bytes':path.stat().st_size})
for label,d in (('iverilog',iv),('verilator',vl)):
 mode_argv=d.get('cases',[{}])[0].get('argv',[])
 mode_path=(mode_argv[1] if label=='iverilog' and len(mode_argv)>1 else mode_argv[0] if mode_argv else '')
 mode_bin=pathlib.Path(mode_path) if mode_path else None
 if mode_bin is not None and not mode_bin.is_absolute():mode_bin=ROOT/mode_bin
 if mode_bin is not None and mode_bin.is_file():
  exclude(mode_bin,d['binary_sha256'],f'{label} mode-run compiled simulation binary excluded; hash retained')
 native_binaries.append({'simulator':label,'path':str(mode_bin) if mode_bin is not None else mode_path,
                          'sha256':d['binary_sha256'],'reason':'mode runner binary SHA; compiled executable excluded'})

# Selected content table (path-key dedup merges roles while preserving the
# strongest original source path in the archive). More than one path alias is
# tracked in root review facts for the historical dispatcher test.
selected={}
def add(path,role,expected=None,archive_path=None):
 p=pathlib.Path(path).resolve();need(p.is_file(),f'missing selected file {p}')
 h=sha(p)
 if expected is not None:need(h==expected,f'selected file changed: {p}')
 key=str(p);arc=archive_path or ('external/'+p.as_posix().lstrip('/') if not p.is_relative_to(ROOT) else 'workspace/'+p.relative_to(ROOT).as_posix())
 if key in selected:
  e=selected[key];need(e['sha256']==h,f'selected source path hash collision for {p}')
  if e['archive_path']!=arc and arc not in e.get('alternate_archive_references',[]):e.setdefault('alternate_archive_references',[]).append(arc)
  if role not in e['roles']:e['roles'].append(role)
  return
 if p in [pathlib.Path(x) for x in excluded]:return
 need(text_file(p),f'refusing to include binary/native tool: {p}')
 selected[key]={'path':p,'sha256':h,'bytes':p.stat().st_size,'archive_path':arc,'roles':[role]}

# Freeze exactly 48 private v6 frontend HDL bodies and the two assertion-
# compatibility modules named by both compiler receipts.
for src,h in vl2['selected_frontend_hashes_before'].items():
 p=pathlib.Path(src);rel=p.relative_to(V6/'source/hdl')
 add(p,'selected private-v6 frontend HDL body',h,'source/private-v6/hdl/'+rel.as_posix())
for src in vl2['selected_assertion_sources']:
 h=vl2['all_input_hashes_before'][src];p=pathlib.Path(src)
 add(p,'actual assertion compatibility body',h,'source/assertion-compat/'+p.name)
# Include the hand-written asynchronous bench and exact fixture/golden data.
BENCH=RUN/'tb_cmac_async_engine.sv'
add(BENCH,'selected CMAC asynchronous bench')
for src,h in ivc['selected_fixture_hashes_before'].items():
 p=pathlib.Path(src);add(p,'original CMAC encoded program/input/weights/expected read/write fixture',h,'fixtures/cmac-array-data/'+p.name)
# Exact direct source/fixture maps from each 9-mode simulator report.
mode_maps={'iverilog':iv['source_and_fixture_hashes_before'],'verilator':vl['source_and_fixture_hashes_before']}
for sim,mapping in mode_maps.items():
 for src,h in mapping.items():
  p=pathlib.Path(src)
  if str(p.resolve()) in excluded:continue
  if p.is_file() and text_file(p):
   if p.is_relative_to(ROOT):arc='mode-inputs/'+sim+'/'+p.relative_to(ROOT).as_posix()
   else:arc='external/'+p.as_posix().lstrip('/')
   add(p,f'{sim} report source/fixture hash-map input',h,arc)

# Reports, root reviews, workers, compile-only pass/failure records and all
# 18 per-mode stdout/stderr logs. No executable or object output is copied.
fixed=[
 (RUN/'preparation.json','provenance/dual-dispatch/preparation.json','mode package preparation'),
 (RUN/'tb_cmac_async_engine.sv','source/tb_cmac_async_engine.sv','CMAC async bench'),
 (RUN/'compile.py','workers/compile.py','Icarus compile worker'),
 (RUN/'compile_verilator_warnreview.py','workers/compile_verilator_warnreview.py','reviewed Verilator compile worker'),
 (RUN/'run_iverilog_modes.py','workers/run_iverilog_modes.py','Icarus nine-mode worker'),
 (RUN/'run_verilator_modes.py','workers/run_verilator_modes.py','Verilator nine-mode worker'),
 (ROOT/'build/full512-ddr-preparation/run_cmac_async_cases.py','workers/run_cmac_async_cases.py','reproducible logical case worker'),
 (RUN/'iverilog-compile-v1/report.json','evidence/compile/iverilog-v1/report.json','Icarus compile report, compile-only unqualified'),
 (RUN/'iverilog-compile-v1/compile.stdout.log','evidence/compile/iverilog-v1/compile.stdout.log','Icarus compile log'),
 (RUN/'iverilog-compile-v1/compile.stderr.log','evidence/compile/iverilog-v1/compile.stderr.log','Icarus compile warnings/log'),
 (RUN/'iverilog-compile-v1/version_0.stdout.log','evidence/compile/iverilog-v1/iverilog-version.stdout.log','tool version output'),
 (RUN/'iverilog-compile-v1/version_0.stderr.log','evidence/compile/iverilog-v1/iverilog-version.stderr.log','tool version stderr'),
 (RUN/'iverilog-compile-v1/version_1.stdout.log','evidence/compile/iverilog-v1/vvp-version.stdout.log','tool version output'),
 (RUN/'iverilog-compile-v1/version_1.stderr.log','evidence/compile/iverilog-v1/vvp-version.stderr.log','tool version stderr'),
 (RUN/'verilator-compile-v1/report.json','evidence/compile/verilator-v1/report.json','preserved strict compile failure'),
 (RUN/'verilator-compile-v1/compile.stdout.log','evidence/compile/verilator-v1/compile.stdout.log','strict compile stdout'),
 (RUN/'verilator-compile-v1/compile.stderr.log','evidence/compile/verilator-v1/compile.stderr.log','strict compile failure/warnings'),
 (RUN/'verilator-compile-v1/version_0.stdout.log','evidence/compile/verilator-v1/verilator-version.stdout.log','tool version output'),
 (RUN/'verilator-compile-v1/version_0.stderr.log','evidence/compile/verilator-v1/verilator-version.stderr.log','tool version stderr'),
 (RUN/'verilator-compile-v1/version_1.stdout.log','evidence/compile/verilator-v1/cxx-version.stdout.log','tool version output'),
 (RUN/'verilator-compile-v1/version_1.stderr.log','evidence/compile/verilator-v1/cxx-version.stderr.log','tool version stderr'),
 (RUN/'verilator-compile-v2/report.json','evidence/compile/verilator-v2/report.json','reviewed-warning compile-only pass'),
 (RUN/'verilator-compile-v2/compile.stdout.log','evidence/compile/verilator-v2/compile.stdout.log','reviewed compile stdout'),
 (RUN/'verilator-compile-v2/compile.stderr.log','evidence/compile/verilator-v2/compile.stderr.log','reviewed compile warnings'),
 (RUN/'verilator-compile-v2/version_0.stdout.log','evidence/compile/verilator-v2/verilator-version.stdout.log','tool version output'),
 (RUN/'verilator-compile-v2/version_0.stderr.log','evidence/compile/verilator-v2/verilator-version.stderr.log','tool version stderr'),
 (RUN/'verilator-compile-v2/version_1.stdout.log','evidence/compile/verilator-v2/cxx-version.stdout.log','tool version output'),
 (RUN/'verilator-compile-v2/version_1.stderr.log','evidence/compile/verilator-v2/cxx-version.stderr.log','tool version stderr'),
 (RUN/'iverilog-modes-v1/report.json','evidence/modes/iverilog/report.json','all nine Icarus modes'),
 (RUN/'verilator-modes-v1/report.json','evidence/modes/verilator/report.json','all nine Verilator modes'),
 (BOTH_REVIEW,'review/both-simulators-root-review-v1.json','independent both-simulator review'),
 (IV_REVIEW,'review/iverilog-modes-root-review-v1.json','independent Icarus modes review'),
 (IV_SCOPE_REVIEW,'review/iverilog-scope-root-review-v1.json','actual Icarus hierarchy/scope review'),
 (WARN_REVIEW,'review/verilator-diagnostics-root-review-v1.json','reviewed Verilator warning policy'),
 (CMAC_BOTH_REVIEW,'review/cmac-async-both-simulators-root-review-v1.json','independent CMAC both-simulator review'),
 (CMAC_IV0_REVIEW,'review/cmac-async-iverilog-mode0-v1-root-review.json','independent mode-0 Icarus review'),
 (CMAC_DIAG_REVIEW,'review/cmac-async-diagnostics-root-review-v1.json','frontend diagnostics root review'),
 (CONTROL_REVIEW,'review/controller-control-root-review-v1.json','controller root review'),
 (CONTROL_REPORT,'evidence/controller/native-controls-v8/report.json','controller CSR controls'),
 (DUAL/'source/rk_dual_job_control.sv','source/dual-csr/rk_dual_job_control.sv','dual CSR controller source'),
 (DUAL/'tests/tb_dual_job_control.sv','source/dual-csr/tb_dual_job_control.sv','dual CSR controller bench'),
 (ROOT/'rtl/rk_job_control.sv','source/dual-csr/rk_job_control.sv','root job control source'),
 (DISPATCH_REPORT,'evidence/dispatch-pending-offer/results-v1/report.json','dispatch control results with expected old public failure'),
 (DISPATCH/'run.py','workers/dispatch-pending-offer/run.py','dispatch control worker'),
 (DISPATCH/'tb_dual_dispatch.sv','source/dispatch/tb_dual_dispatch.sv','dispatch control bench')]
for src,arc,role in fixed:add(src,role,archive_path=arc)
# Add every v6 frontend text receipt, excluding compiled binaries and pycache.
for base,arcroot,excluded_root in [
 (RUN/'iverilog-modes-v1','evidence/modes/iverilog','mode_logs'),
 (RUN/'verilator-modes-v1','evidence/modes/verilator','mode_logs')]:
 for mode in range(9):
  for suffix in ('stdout.log','stderr.log'):
   path=base/f'mode-{mode}.{suffix}'
   add(path,f'{base.name} actual mode {mode} {suffix}',archive_path=f'{arcroot}/mode-{mode}.{suffix}')
# Include stable text files in compile-only and controller/dispatch result trees.
for base,prefix in [(RUN/'iverilog-modes-v1','evidence/modes/iverilog'),(RUN/'verilator-modes-v1','evidence/modes/verilator')]:
 pass
# Root review files sometimes bind a scope report or current compiler receipt by SHA.
for d in (both,ivrev):
 for path,h in d.get('evidence',{}).items():verify(path,h,'root review evidence')
if vl2.get('warning_review'):
 wr=pathlib.Path(vl2['warning_review']['review_path']);verify(wr,vl2['warning_review']['review_sha256'],'Verilator warning review')
# Preserve dispatch-control source aliases with old test-time bytes. Public paths
# advanced after the historical control; exact snapshots are copied separately.
dispatch_aliases=[]
for source,h in dispatch['source_hashes_before'].items():
 p=pathlib.Path(source).resolve();current_hash=sha(p)
 if current_hash==h:chosen=p;alias=False
 else:
  candidates=[ROOT/'build/full512-ddr-preparation/combined-source-v4/source/hdl/148/rk_dual_async_dispatch.sv',
   ROOT/'build/full512-ddr-preparation/combined-source-v4/source/hdl/148/rk_dual_async_dispatch.sv',
   ROOT/'build/full512-ddr-preparation/public-source-promotion-v1/before/tests/ddr/dispatch/tb_dual_dispatch.sv']
  matches=[q.resolve() for q in candidates if q.is_file() and sha(q)==h]
  need(matches,'historical dispatch-control source alias unavailable: '+source)
  chosen=matches[0];alias=True
  dispatch_aliases.append({'reported_path':source,'reported_sha256':h,'historical_snapshot':str(chosen),
   'historical_snapshot_sha256':sha(chosen),'current_path':str(p),'current_sha256':current_hash,
   'scope':'current source advanced after control; archived snapshot retains exact historical test input'})
 if alias:
  logical=pathlib.Path(source)
  if str(logical).endswith('rtl/ddr/rk_dual_async_dispatch.sv'):arc='source/dispatch/historical-rk_dual_async_dispatch.sv'
  elif str(logical).endswith('tests/ddr/dispatch/tb_dual_dispatch.sv'):arc='source/dispatch/historical-tb_dual_dispatch.sv'
  else:arc='source/dispatch/historical-'+logical.name
  add(chosen,'exact historical dispatch-control test input',h,arc)
  add(p,'current source after control run; not substituted for historical input',current_hash,'source/dispatch/current-'+logical.name)
 else:
  rel=pathlib.Path(source).as_posix().replace('/','_')
  add(chosen,'pending-offer control source input',h,'source/dispatch/'+rel)

# Add 10 compiled input fixtures exactly; encode program and raw expected reads/writes.
fixture_map=ivc['selected_fixture_hashes_before'];need(len(fixture_map)==10,'expected ten CMAC encoded fixtures')
for path,h in fixture_map.items():
 p=pathlib.Path(path);add(p,'actual program/input/weights/expected read/write fixture',h,'fixtures/cmac-array-data/'+p.name)
# Verify the 48 selected v6 sources and two actual assertion compatibility bodies.
for d in (ivc,vl2):
 for path,h in d['selected_frontend_hashes_before'].items():
  p=pathlib.Path(path);need(p.is_file() and sha(p)==h,f'private v6 source hash mismatch: {p}')
for path in vl2['selected_assertion_sources']:
 h=vl2['all_input_hashes_before'][path];p=pathlib.Path(path);add(p,'actual assertion compatibility module',h,'source/assertion-compat/'+p.name)
# Add compile-specific text source maps, reports and all input hash maps; data
# inputs from 70/71 maps are retained in the archive without rewriting reports.
sourcefixture_manifest={'schema':'dual-dispatch-mode-source-fixture-inputs-v1','iverilog':{'report_path':relpath(IV_REPORT),'count':len(iv['source_and_fixture_hashes_before']),
 'hashes_before':iv['source_and_fixture_hashes_before'],'hashes_after_current':mode_after['iverilog'],'selected_modes':iv['selected_modes']},
 'verilator':{'report_path':relpath(VL_REPORT),'count':len(vl['source_and_fixture_hashes_before']),
 'hashes_before':vl['source_and_fixture_hashes_before'],'hashes_after_current':mode_after['verilator'],'selected_modes':vl['selected_modes']}}
input_manifest={'schema':'dual-dispatch-compile-input-hashes-v1','iverilog_compile_v1':{'inputs_before':ivc['all_input_hashes_before'],'inputs_after':ivc['all_input_hashes_after'],
 'selected_frontend_before':ivc['selected_frontend_hashes_before'],'selected_frontend_after':ivc['selected_frontend_hashes_after'],
 'selected_assertion_sources':ivc['selected_assertion_sources'],'selected_fixtures_before':ivc['selected_fixture_hashes_before']},
 'verilator_compile_v1_failed':{'inputs_before':vl1['all_input_hashes_before'],'inputs_after':vl1['all_input_hashes_after'],
 'selected_frontend_before':vl1['selected_frontend_hashes_before'],'selected_frontend_after':vl1['selected_frontend_hashes_after'],
 'selected_assertion_sources':vl1['selected_assertion_sources'],'selected_fixtures_before':vl1['selected_fixture_hashes_before']},
 'verilator_compile_v2_reviewed':{'inputs_before':vl2['all_input_hashes_before'],'inputs_after':vl2['all_input_hashes_after'],
 'selected_frontend_before':vl2['selected_frontend_hashes_before'],'selected_frontend_after':vl2['selected_frontend_hashes_after'],
 'selected_assertion_sources':vl2['selected_assertion_sources'],'selected_fixtures_before':vl2['selected_fixture_hashes_before']}}
# Inserted generated manifest files will be written to build + archive after plan.

# Add text artifacts from output directories selected above; treat all tool/binary
# input paths as exclusions with exact hashes, never as archive payloads.
additional_excluded=[]
for path,meta in verified.items():
 p=pathlib.Path(path)
 if p.suffix.lower() in {'.vvp','.o','.a','.gch','.so','.elf','.dcp','.bit'} or '/verilator-compile-' in path and '/obj/' in path or p.name in {'Vtb_cmac_async_engine'}:
  additional_excluded.append({'source_path':relpath(p),'bytes':meta['bytes'],'sha256':meta['sha256'],'reason':'compiled simulator/VVP/native executable/object output excluded'})
 elif not text_file(p):additional_excluded.append({'source_path':relpath(p),'bytes':meta['bytes'],'sha256':meta['sha256'],'reason':'native tool binary/non-text input excluded'})
# Enumerate complete Verilator C++/object trees and VVP artifacts for precise exclusions.
for base in (RUN/'iverilog-compile-v1',RUN/'verilator-compile-v1/obj',RUN/'verilator-compile-v2/obj'):
 if not base.exists():continue
 for q in base.rglob('*'):
  if not q.is_file():continue
  if q.suffix.lower() in {'.vvp','.o','.a','.gch','.d','.elf','.so'} or '/obj/' in q.as_posix() or q.name=='Vtb_cmac_async_engine':
   row={'source_path':relpath(q),'bytes':q.stat().st_size,'sha256':sha(q),'reason':'compiled VVP/Verilator C++/object/native output excluded'}
   if row not in additional_excluded:additional_excluded.append(row)
for report,name in ((iv,'iverilog'),(vl,'verilator')):
 argv=report['cases'][0]['argv'];binpath=pathlib.Path(argv[1])
 digest=report['binary_sha256'];
 if binpath.is_file() and sha(binpath)==digest:
  row={'source_path':relpath(binpath),'bytes':binpath.stat().st_size,'sha256':digest,'reason':f'{name} mode-run compiled simulation binary excluded'}
  if row not in additional_excluded:additional_excluded.append(row)
excluded_records=list(excluded.values())+additional_excluded

# Exact tool identity from compile reports; binary hashes are excluded above.
tool_facts={}
for label,d in (('iverilog_compile_v1',ivc),('verilator_compile_v1',vl1),('verilator_compile_v2',vl2)):
 tool_facts[label]=d.get('tools',{})
# Deterministic plan and source list. Include all direct source/fixture maps but
# represent binaries/tools by explicit excluded path/hash rows.
source_selection=[{'source_path':relroot(x['path']),'archive_path':x['archive_path'],'source_sha256':x['sha256'],
 'bytes':x['bytes'],'roles':x['roles'],'alternate_archive_references':x.get('alternate_archive_references',[])} for x in sorted(selected.values(),key=lambda z:z['archive_path'])]
plan={'schema':'dual-dispatch-logical-archive-plan-v1','status':'READY','source_directory':relpath(RUN),'archive_directory':relpath(DEST),
 'both_simulator_review':{'path':relpath(BOTH_REVIEW),'sha256':sha(BOTH_REVIEW),'status':both['status'],'seed':both['seed'],'modes':both['modes']},
 'mode_input_counts':{'iverilog':len(iv['source_and_fixture_hashes_before']),'verilator':len(vl['source_and_fixture_hashes_before'])},
 'selected_private_v6_frontend_count':len(vl2['selected_frontend_hashes_before']),'assertion_compatibility_module_count':len(vl2['selected_assertion_sources']),
 'fixture_count':len(fixture_map),'selected_files':source_selection,'excluded_native_artifacts':excluded_records,
 'dispatch_source_aliases':dispatch_aliases,'archive_scope':'16 C32 kernels, 512 products, two simulators, nine modes, seed 0x3588ad16; no EW numeric alternation, DDR model/physical, PCIe, RK equivalence, CDC, or timing qualification',
 'no_sha256s_sidecar':True,'no_tools_launched':True}
PLAN.write_text(json.dumps(plan,indent=2,sort_keys=True)+'\n')
# Add the reproducible packer and source/fixture manifests before final source map.
add(PLAN,'archive preparation plan',sha(PLAN),'archive-tools/plan.json')
add(PACKER,'archive packer source',None,'archive-tools/prepare_archive.py')
source_before={path:sha(info['path']) for path,info in selected.items()}

# Ensure the destination remains fresh and create no SHA256SUMS file.
need(not DEST.exists(),'archive destination must be fresh')
DEST.mkdir(parents=True)
readme=("Full512 dual-dispatch nine-mode logical CMAC evidence archive.\n"
"Source: frozen combined-source-v6 and 48 selected private frontend source bodies plus assertion compatibility modules. 16 C32 kernels / 512 product lanes; both Icarus and Verilator passed all nine modes with original mode counts and seed 0x3588ad16.\n"
"This is selected logical CMAC/shared-dispatch numerical and control evidence only. It does not qualify EW numerical alternation, DDR/MIG modeling, physical DDR, PCIe, RK silicon, CDC, or timing. Strict Verilator compile v1 remains FAIL and is retained; v2 is compile-only under reviewed warnings. Controller/dispatch controls remain separate from CMAC numeric qualification.\n"
"Compiled VVP/ELF/object outputs and native tool binaries are excluded; their source hashes/bytes/reasons are in the index. Mode reports retain native binary hashes. No hardware was accessed.\n").encode()
(DEST/'README.txt').write_bytes(readme)
file_index={'README.txt':{'source_path':'generated scope note','archive_path':'README.txt','roles':['scope and limitations'],
 'source_bytes':len(readme),'source_sha256':hashlib.sha256(readme).hexdigest(),'archive_bytes':len(readme),
 'archive_sha256':hashlib.sha256(readme).hexdigest(),'compression':'none'}}
# Store generated exact input hash manifests in deterministic compressed form.
for key,obj,filename in [('mode-input-manifests',sourcefixture_manifest,'mode-source-fixture-inputs.json'),
                         ('compile-input-manifests',input_manifest,'compile-input-hashes.json')]:
 raw=(json.dumps(obj,indent=2,sort_keys=True)+'\n').encode();rel='manifests/'+filename
 if len(raw)>16384:
  arc=DEST/(rel+'.gz');arc.parent.mkdir(parents=True,exist_ok=True)
  with arc.open('wb') as f:
   with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0,compresslevel=9) as gz:gz.write(raw)
  arcpath=rel+'.gz';compression='gzip_mtime0_level9'
 else:
  arc=DEST/rel;arc.parent.mkdir(parents=True,exist_ok=True);arc.write_bytes(raw);arcpath=rel;compression='none'
 file_index[rel]={'source_path':'generated from source reports before/after actual hash audit','archive_path':arcpath,'roles':[key],
  'source_bytes':len(raw),'source_sha256':hashlib.sha256(raw).hexdigest(),'archive_bytes':arc.stat().st_size,'archive_sha256':sha(arc),'compression':compression}
# Copy selected source/evidence payloads with deterministic gzip above threshold.
for source,entry in sorted(selected.items(),key=lambda kv:kv[1]['archive_path']):
 src=entry['path'];need(sha(src)==entry['sha256'],f'source drift before archive copy: {src}')
 raw=src.read_bytes();rel=entry['archive_path']
 if len(raw)>16384:
  arcpath=rel+'.gz';dst=DEST/arcpath;dst.parent.mkdir(parents=True,exist_ok=True)
  with dst.open('wb') as f:
   with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0,compresslevel=9) as gz:gz.write(raw)
  compression='gzip_mtime0_level9'
 else:
  arcpath=rel;dst=DEST/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw);compression='none'
 stored=sha(dst);logical=gzip.decompress(dst.read_bytes()) if compression.startswith('gzip') else dst.read_bytes()
 need(len(logical)==len(raw) and hashlib.sha256(logical).hexdigest()==entry['sha256'],f'copy/decompression mismatch: {rel}')
 need(sha(src)==entry['sha256'],f'source drift during copy: {src}')
 file_index[rel]={'source_path':relroot(src),'archive_path':arcpath,'roles':entry['roles'],
  'alternate_archive_references':entry.get('alternate_archive_references',[]),
  'source_bytes':len(raw),'source_sha256':entry['sha256'],'archive_bytes':dst.stat().st_size,'archive_sha256':stored,'compression':compression}
# Verify original report-declared inputs and all copied source bytes after archive.
for path,h in verified.items():need(pathlib.Path(path).is_file() and sha(path)==h['sha256'],'reported input drift after archive: '+path)
for path,h in source_before.items():need(pathlib.Path(path).is_file() and sha(path)==h,'selected source drift after archive: '+path)
# Preserve root review facts from the actual independent review as source report, not rewritten.
rootfacts={'status':both['status'],'seed':both['seed'],'mode_count':len(both['modes']),'modes':both['modes'],
 'full512_product_lanes':both['full512_product_lanes'],'numerical_counts':both['numerical_counts'],
 'repeat_raw_jobs':both['repeat_raw_jobs'],'repeat_operand_reads':both['repeat_operand_reads'],'repeat_writes':both['repeat_writes'],
 'repeat_memory_responses':both['repeat_memory_responses'],'repeat_safe_rearms':both['repeat_safe_rearms'],
 'ew_numerical_composition_qualified':both['ew_numerical_composition_qualified'],'ddr_composition_qualified':both['ddr_composition_qualified'],
 'mapped_or_timing_qualified':both['mapped_or_timing_qualified'],'hardware_accessed':both['hardware_accessed'],
 'strict_verilator_compile_v1_status':vl1['status'],'strict_verilator_compile_v2_status':vl2['status'],
 'iverilog_mode_status':iv['status'],'verilator_mode_status':vl['status'],
 'scope':'Logical CMAC/shared dispatch only; 16 C32 kernels/512 products and nine modes in both simulators. Does not establish EW numerical alternation, DDR, physical, PCIe, RK, CDC or timing.'}
raw=(json.dumps(rootfacts,indent=2,sort_keys=True)+'\n').encode();(DEST/'root-review-facts.json').write_bytes(raw)
file_index['root-review-facts.json']={'source_path':'generated summary copied verbatim in values from both-simulator root review','archive_path':'root-review-facts.json','roles':['summary with evidence boundary'],
 'source_bytes':len(raw),'source_sha256':hashlib.sha256(raw).hexdigest(),'archive_bytes':len(raw),'archive_sha256':sha(DEST/'root-review-facts.json'),'compression':'none'}
# Construct index without an unindexed checksum sidecar.
source_total=sum(x['source_bytes'] for x in file_index.values());stored_total=sum(x['archive_bytes'] for x in file_index.values())
index={'schema':'full512-dual-dispatch-logical-evidence-v1','status':'PRESERVED_BOTH_SIMULATOR_NINE_MODE_LOGICAL_CMACK_DISPATCH_ONLY',
 'created_utc':utc(),'source_run_path':relroot(RUN),'root_review_path':relroot(BOTH_REVIEW),'root_review_sha256':sha(BOTH_REVIEW),
 'seed':'0x3588ad16','simulators':['iverilog','verilator'],'mode_count_per_simulator':9,'iverilog_source_fixture_input_count':70,
 'verilator_source_fixture_input_count':71,'shared_source_fixture_intersection_count':len(set(iv['source_and_fixture_hashes_before']) & set(vl['source_and_fixture_hashes_before'])),
 'private_v6_selected_frontend_count':48,'assertion_compatibility_module_count':2,'cmac_array_fixture_count':10,
 'full512_product_lanes':512,'c32_kernel_count':16,
 'compile_statuses':{'iverilog':ivc['status'],'verilator_strict_v1':'FAIL_STRICT_COMPILE_ONLY','verilator_reviewed_v2':vl2['status']},
 'dispatch_control_statuses':{'controller_root_review':control['status'],'dispatch_control':dispatch['status'],
  'old_public_negative_returncode':dispatch['pending_offer_old_public_negative']['run']['returncode'],'old_public_negative_expected_failure':True},
 'evidence_boundary':{'ew_numerical_composition_qualified':False,'ddr_composition_qualified':False,'ddr_model_used':False,
  'physical_ddr_qualified':False,'pcie_qualified':False,'rk_silicon_equivalence':False,'cdc_qualified':False,'timing_qualified':False,'hardware_accessed':False},
 'scope':'16 C32 kernels / 512 product lanes; both simulators passed all nine CMAC/shared-dispatch modes with seed 0x3588ad16. No EW numerical alternation/DDR model/physical/PCIe/RK/CDC/timing claim.',
 'source_hash_maps':{'iverilog_modes':len(iv['source_and_fixture_hashes_before']),'verilator_modes':len(vl['source_and_fixture_hashes_before']),
  'all_declared_report_hash_inputs_verified_before_and_after':len(verified)},
 'native_binaries_excluded':native_binaries,
 'excluded_native_artifacts':excluded_records,'dispatch_source_aliases':dispatch_aliases,
 'file_count':len(file_index),'source_bytes_total':source_total,'stored_bytes_total':stored_total,
 'compression_policy':'Text payloads >16384 bytes use deterministic gzip mtime=0 level 9; decompressed hashes/sizes are verified.',
 'files':file_index}
(DEST/'index.json').write_text(json.dumps(index,indent=2,sort_keys=True)+'\n')
# Final stored-data check. Intentionally no SHA256SUMS file is emitted.
for key,e in file_index.items():
 path=DEST/e['archive_path'];data=path.read_bytes()
 need(len(data)==e['archive_bytes'] and hashlib.sha256(data).hexdigest()==e['archive_sha256'],f'stored archive hash mismatch {key}')
 logical=gzip.decompress(data) if e['compression'].startswith('gzip') else data
 need(len(logical)==e['source_bytes'] and hashlib.sha256(logical).hexdigest()==e['source_sha256'],f'decompressed payload mismatch {key}')
need(not (DEST/'SHA256SUMS').exists() and not (DEST/'archive_SHA256SUMS').exists(),'checksum sidecar is prohibited in verification archive')
print(json.dumps({'status':index['status'],'archive':str(DEST),'index_sha256':sha(DEST/'index.json'),'files':len(file_index),
 'source_bytes':source_total,'stored_bytes':stored_total,'iverilog_source_fixture_inputs':len(iv['source_and_fixture_hashes_before']),
 'verilator_source_fixture_inputs':len(vl['source_and_fixture_hashes_before']),'private_v6_sources':48,
 'excluded_native_artifacts':len(excluded_records),'sha256_sidecar':False},indent=2))
