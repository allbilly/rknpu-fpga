"""Portable Tcl mocks for private dual-endpoint CDC helper extensions only."""
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

from tests.ddr.async_job.test_cdc_constraints import MOCK as JOB_CDC_MOCK
from tests.ddr.async_job.test_engine_observer import ENGINE_MOCK
from tests.ddr.board_shell.test_reset_bridge_board import MOCK as BOARD_MOCK
from tools.hardware.sample_ew import tcl_literal

ROOT=Path('/home/fedora/rknpu-fpga')
PRIVATE=ROOT/'build/full512-ddr-preparation/dual-cdc-source-v3'
JOB=PRIVATE/'job_cdc.tcl'
STATUS=PRIVATE/'status_cdc.tcl'
PERMIT=PRIVATE/'permit_cdc.tcl'
PUBLIC_JOB=ROOT/'fpga/ddr/async_job_cdc.tcl'
PUBLIC_STATUS=ROOT/'fpga/ddr/reset_status_cdc.tcl'

# Reuse the established engine-boundary pin/net mock and select the CMAC module
# for good_cmac. All other constant, direction, absent-net and driver faults
# remain the existing strict EW observer controls.
CMAC_ENGINE_MOCK=ENGINE_MOCK.replace(
    'return [expr {$::scenario eq "wrong_engine" ? "unrelated_module" : "rk_ew_async_engine"}]',
    'return [expr {$::scenario eq "wrong_engine" ? "unrelated_module" : (($::scenario eq "wrong_engine_cmac_module" || $::scenario eq "good") ? "rk_ew_async_engine" : "rk_cmac_async_engine")}]')

# Extend the reviewed board shell Tcl mock with exact endpoint/CMAC async
# hierarchy cells and the permit synchronizer. Reset-bank behavior remains the
# source existing mock; the added controls model only the newly selected path.
DUAL_MOCK=BOARD_MOCK+r'''
rename get_property board_get_property
proc get_property {key object} {
    if {$key eq "REF_NAME" && $object eq "platform/endpoint"} {
        if {$::scenario eq "wrong_endpoint_module"} {return unrelated_endpoint_module}
        if {$::scenario eq "old_ew_endpoint"} {return rk_jtag_ew_ddr_async}
        return rk_jtag_dual_ddr_async
    }
    if {$key eq "REF_NAME" && $object eq "platform/endpoint/engine/cmac"} {
        if {$::scenario eq "wrong_cmac_engine"} {return rk_ew_async_engine}
        return rk_cmac_async_engine
    }
    if {$key eq "REF_NAME" && [lsearch -exact [dual_status_cells] $object]>=0} {return FDRE}
    if {$key eq "ASYNC_REG" && [regexp {^(platform/endpoint/reset_owner/(reset[01]|fresh[01]|release[01])_sync_reg\[[0-2]\]|platform/endpoint/reset_owner/ui_domain\[[01]\]\.assertion_sync_reg\[[0-2]\]|platform/endpoint/sequence_sync_reg\[[0-2]\]|platform/endpoint/engine/cmac/permit_sync_reg\[[0-2]\])$} $object]} {
        if {$::scenario eq "missing_async_reg" && [string match {*sync_reg\[1\]} $object]} {return 0}
        return 1
    }
    return [board_get_property $key $object]
}
rename get_cells board_get_cells
proc dual_status_cells {} {
    set cells {}
    foreach d {0 1} {
        lappend cells "platform/endpoint/c${d}_ui_status_reg"
        foreach stem [list "reset${d}_sync" "fresh${d}_sync" "release${d}_sync"] {
            for {set i 0} {$i<3} {incr i} {lappend cells "platform/endpoint/reset_owner/${stem}_reg\[$i\]"}
        }
        lappend cells "platform/endpoint/reset_owner/ui_domain\[$d\].fresh_reg"
        lappend cells "platform/endpoint/reset_owner/ui_domain\[$d\].clients_rst_n_reg"
        lappend cells "platform/endpoint/reset_owner/assertion_seen_reg\[$d\]"
        for {set i 0} {$i<3} {incr i} {lappend cells "platform/endpoint/reset_owner/ui_domain\[$d\].assertion_sync_reg\[$i\]"}
    }
    lappend cells platform/endpoint/sequence_complete_registered_reg
    for {set i 0} {$i<3} {incr i} {lappend cells "platform/endpoint/sequence_sync_reg\[$i\]"}
    for {set i 0} {$i<3} {incr i} {lappend cells "platform/endpoint/engine/cmac/permit_sync_reg\[$i\]"}
    lappend cells platform/endpoint/engine/cmac/permit_registered_reg
    if {$::scenario eq "depth"} {lappend cells platform/endpoint/reset_owner/reset0_sync_reg\[3\]}
    if {$::scenario eq "permit_depth"} {lappend cells platform/endpoint/engine/cmac/permit_sync_reg\[3\]}
    return $cells
}
proc get_cells {args} {
    if {[lsearch -exact $args -of_objects]>=0} {
        set pin [lindex $args [expr {[lsearch -exact $args -of_objects]+1}]]
        if {[regexp {^PIN:(.*)/C$} $pin -> cell] && [lsearch -exact [dual_status_cells] $cell]>=0} {return [list $cell]}
        return [board_get_cells {*}$args]
    }
    if {[lsearch -exact $args -hier]>=0} {return [dual_status_cells]}
    set last [lindex $args end];set name [lindex $last 0]
    if {$name in {platform/endpoint platform/endpoint/reset_owner platform/endpoint/engine/cmac}} {return [list $name]}
    if {[lsearch -exact [dual_status_cells] $name]>=0} {return [list $name]}
    if {[regexp {^platform/endpoint/reset_owner/ui_domain\[[01]\]\.(reset_pipe_reg\[[01]\]|local_rst_n_reg|permit_sync_reg\[[0-2]\])$} $name]} {return [list $name]}
    return [board_get_cells {*}$args]
}
rename get_clocks board_get_clocks
proc get_clocks {args} {
    if {[lsearch -exact $args -of_objects]>=0} {
        set pin [lindex $args [expr {[lsearch -exact $args -of_objects]+1}]]
        set name [string range $pin 4 end]
        if {[regexp {c0_ui_status_reg/C|ui_domain\[0\]\.assertion_sync_reg\[[0-2]\]/C|sequence_sync_reg\[[0-2]\]/C} $name]} {return [list CLOCK:clk_pll_i]}
        if {[regexp {c1_ui_status_reg/C|ui_domain\[1\]\.assertion_sync_reg\[[0-2]\]/C} $name]} {return [list CLOCK:clk_pll_i_1]}
        if {[regexp {ui_domain\[0\]\.(fresh|clients_rst_n)_reg/C} $name]} {return [list CLOCK:clk_pll_i]}
        if {[regexp {ui_domain\[1\]\.(fresh|clients_rst_n)_reg/C} $name]} {return [list CLOCK:clk_pll_i_1]}
        if {[regexp {engine/cmac/permit_registered_reg/C} $name]} {
            if {$::scenario eq "permit_clock_mismatch"} {return [list CLOCK:sys_clock]}
            return [list CLOCK:clk_pll_i]
        }
        if {[regexp {engine/cmac/permit_sync_reg\[[0-2]\]/C} $name]} {return [list CLOCK:sys_clock]}
        if {[regexp {reset_owner/assertion_seen_reg\[[01]\]/C|sequence_complete_registered_reg/C} $name]} {return [list CLOCK:sys_clock]}
        if {$::scenario eq "clock_mismatch" && [regexp {reset0_sync_reg\[1\]/C} $name]} {return [list CLOCK:clk_pll_i]}
        return [list CLOCK:sys_clock]
    }
    return [board_get_clocks {*}$args]
}
rename all_fanin board_all_fanin
proc all_fanin {args} {
    set pin [lindex $args end];set name [string range $pin 4 end]
    if {$name eq "platform/endpoint/c0_ui_clk_sync_rst"} {return [list PIN:platform/endpoint/c0_ui_status_reg/C]}
    if {$name eq "platform/endpoint/c1_ui_clk_sync_rst"} {return [list PIN:platform/endpoint/c1_ui_status_reg/C]}
    if {[regexp {^(.*)_reg\[([0-3])\]/D$} $name -> stem i]} {
        if {$i eq "0"} {
            if {[regexp {reset_owner/reset([01])_sync$} $stem -> d]} {set prev "platform/endpoint/c${d}_ui_status_reg"} elseif {[regexp {reset_owner/fresh([01])_sync$} $stem -> d]} {set prev "platform/endpoint/reset_owner/ui_domain\[$d\].fresh_reg"} elseif {[regexp {reset_owner/release([01])_sync$} $stem -> d]} {set prev "platform/endpoint/reset_owner/ui_domain\[$d\].clients_rst_n_reg"} elseif {[regexp {reset_owner/ui_domain\[([01])\]\.assertion_sync$} $stem -> d]} {set prev "platform/endpoint/reset_owner/assertion_seen_reg\[$d\]"} elseif {$stem eq "platform/endpoint/sequence_sync"} {set prev platform/endpoint/sequence_complete_registered_reg} elseif {$stem eq "platform/endpoint/engine/cmac/permit_sync"} {set prev platform/endpoint/engine/cmac/permit_registered_reg} else {error "unknown mock chain $stem"}
        } else {
            set prior [expr {$i-1}];set prev "${stem}_reg\[$prior\]"
        }
        set result [list "PIN:${prev}/C"]
        if {$::scenario eq "wrong_fanin" && $i==1} {lappend result PIN:rogue_source/C}
        if {$::scenario eq "permit_wrong_fanin" && $stem eq "platform/endpoint/engine/cmac/permit_sync" && $i==1} {lappend result PIN:rogue_source/C}
        return $result
    }
    return [board_all_fanin {*}$args]
}
rename get_timing_paths board_get_timing_paths
proc get_timing_paths {args} {
    set fi [lsearch -exact $args -from];set ti [lsearch -exact $args -to];set di [lsearch -exact $args -delay_type]
    set start [lindex $args [expr {$fi+1}]];set end [lindex $args [expr {$ti+1}]]
    set delay [expr {$di<0 ? "first" : [lindex $args [expr {$di+1}]]}]
    set sn [string range $start 4 end];set en [string range $end 4 end]
    set exception "";set slack 1.0;set req 20.0
    if {$delay eq "first"} {
        set exception "False Path";set slack "";set req ""
        if {$::scenario eq "permit_first_cut_missing"} {set exception "";set slack 1.0;set req 20.0}
        if {$::scenario eq "permit_first_wrong_endpoint"} {set en wrong/endpoint}
    } else {
        set req [expr {$delay eq "max" ? 20.0 : 0.0}]
        set slack [expr {$delay eq "max" ? 1.0 : 0.1}]
        if {$::scenario eq "permit_later_cut"} {set exception "False Path";set slack "";set req ""}
        if {$::scenario eq "permit_later_fail"} {set slack -0.01}
        if {$::scenario eq "permit_later_wrong_endpoint"} {set sn wrong/source}
    }
    incr ::path_serial;set p "PATH:$::path_serial"
    set ::path_info($p) [dict create exception $exception slack $slack requirement $req required_time $req start $start end $end]
    if {$::scenario eq "permit_first_wrong_endpoint" && $delay eq "first"} {dict set ::path_info($p) end PIN:wrong/endpoint}
    if {$::scenario eq "permit_later_wrong_endpoint" && $delay ne "first"} {dict set ::path_info($p) start PIN:wrong/source}
    return [list $p]
}
rename get_property dual_base_get_property
proc get_property {key object} {
    if {[string match PATH:* $object]} {
        set info $::path_info($object)
        switch -- $key {
            EXCEPTION {return [dict get $info exception]}
            SLACK {return [dict get $info slack]}
            REQUIREMENT {return [dict get $info requirement]}
            REQUIRED_TIME {return [dict get $info required_time]}
            STARTPOINT_PIN {return [dict get $info start]}
            ENDPOINT_PIN {return [dict get $info end]}
        }
    }
    return [dual_base_get_property $key $object]
}
proc get_waivers {} {return {}}
'''


def run_tcl(source_text, body, helper_paths):
    with tempfile.TemporaryDirectory() as directory:
        p=Path(directory)/'mock.tcl'
        p.write_text(source_text+'\n'+''.join('source '+tcl_literal(x)+'\n' for x in helper_paths)+body+'\n')
        return subprocess.run([shutil.which('tclsh'),str(p)],capture_output=True,text=True,timeout=30)

@unittest.skipUnless(shutil.which('tclsh'),'Tcl interpreter required')
class PrivateJobHelperTests(unittest.TestCase):
    def invoke_engine(self,scenario,helper,profile):
        mock=CMAC_ENGINE_MOCK.replace('__SCENARIO__',tcl_literal(scenario))
        body='''
set prefix [rk_job_prefix engine/job_crossing]
set payloads [rk_job_payloads $prefix PROFILE]
puts "RESULT [llength [lindex [lindex $payloads 0] 1]] [llength [lindex [lindex $payloads 0] 2]] [llength [lindex [lindex $payloads 1] 1]] [llength [lindex [lindex $payloads 1] 2]]"
puts PASS_JOB_PROFILE
'''.replace('PROFILE',profile)
        return run_tcl(mock,body,[helper])

    def test_rejected_legacy_cmac_engine_e1_e8_profile_is_not_used_as_a_success_case(self):
        result=self.invoke_engine('good_cmac',JOB,'cmac_engine_e1_e8')
        self.assertNotEqual(result.returncode,0,result.stdout)
        self.assertIn('Unsupported job result mapping profile',result.stderr)
        self.assertNotIn('PASS_JOB_PROFILE',result.stdout)

    def test_old_engine_profiles_and_full8_contract_are_unchanged(self):
        ew_private=self.invoke_engine('good',JOB,'ew_engine_e1_e8')
        ew_public=self.invoke_engine('good',PUBLIC_JOB,'ew_engine_e1_e8')
        self.assertEqual(ew_private.returncode,0,ew_private.stdout+ew_private.stderr)
        self.assertEqual(ew_private.stdout,ew_public.stdout)
        self.assertIn('RESULT 64 64 37 37',ew_private.stdout)
        def invoke_full8(helper):
            body='''
set p [rk_job_payloads [rk_job_prefix {}] full8]
puts "RESULT [llength [lindex [lindex $p 0] 1]] [llength [lindex [lindex $p 0] 2]] [llength [lindex [lindex $p 1] 1]] [llength [lindex [lindex $p 1] 2]]"
'''
            return run_tcl('set ::scenario good\n'+JOB_CDC_MOCK,body,[helper])
        full8_private=invoke_full8(JOB)
        full8_public=invoke_full8(PUBLIC_JOB)
        self.assertEqual(full8_private.returncode,0,full8_private.stdout+full8_private.stderr)
        self.assertEqual(full8_private.stdout,full8_public.stdout)
        self.assertIn('RESULT 64 64 41 41',full8_private.stdout)
        unknown=self.invoke_engine('good',JOB,'unknown')
        self.assertNotEqual(unknown.returncode,0)
        self.assertIn('Unsupported job result mapping profile',unknown.stderr)

    def test_full8_constraint_exception_set_matches_public_helper(self):
        body='''
rk_job_cdc_constrain {} source_clock destination_clock full8
foreach change $changes {puts $change}
puts PASS_JOB_CDC
'''
        def invoke(helper):
            return run_tcl('set ::scenario good\n'+JOB_CDC_MOCK,body,[helper])
        private=invoke(JOB);public=invoke(PUBLIC_JOB)
        self.assertEqual(private.returncode,0,private.stdout+private.stderr)
        self.assertEqual(private.stdout,public.stdout)
        self.assertIn('PASS_JOB_CDC',private.stdout)

@unittest.skipUnless(shutil.which('tclsh'),'Tcl interpreter required')
class PrivateStatusHelperTests(unittest.TestCase):
    def invoke(self,scenario,helper,body):
        mock=DUAL_MOCK.replace('__SCENARIO__',tcl_literal(scenario))
        return run_tcl(mock,body,[helper])

    def inventory_body(self):
        return '''
set inventory [rk_status_inventory platform/endpoint sys_clock clk_pll_i clk_pll_i_1]
puts "INVENTORY [llength $inventory]"
rk_status_cdc_constrain platform/endpoint sys_clock clk_pll_i clk_pll_i_1
foreach change $changes {puts $change}
puts PASS_STATUS_CDC
'''

    def test_dual_endpoint_accepts_same_nine_chains_and_only_first_d_cuts(self):
        result=self.invoke('good',STATUS,self.inventory_body())
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        self.assertIn('INVENTORY 9',result.stdout)
        self.assertEqual(sum(x.startswith('FALSE ') for x in result.stdout.splitlines()),9)
        self.assertEqual(sum(x.startswith('PROPERTY DONT_TOUCH TRUE ') for x in result.stdout.splitlines()),9)
        cuts=[x.replace('{','').replace('}','').split() for x in result.stdout.splitlines() if x.startswith('FALSE ')]
        self.assertTrue(all(len(x)==5 and x[1]=='-from' and x[2].endswith('/C') and x[3]=='-to' and x[4].endswith('/D') for x in cuts),cuts)
        self.assertTrue(all('_reg[0]/D' in x[4] for x in cuts),cuts)
        self.assertFalse(any('_reg[1]/D' in x[4] or '_reg[2]/D' in x[4] or '/CLR' in x[4] for x in cuts),cuts)
        self.assertIn('PASS_STATUS_CDC',result.stdout)

    def test_old_ew_status_inventory_and_constraints_match_public_helper(self):
        body=self.inventory_body()
        private=self.invoke('old_ew_endpoint',STATUS,body)
        public=self.invoke('old_ew_endpoint',PUBLIC_STATUS,body)
        self.assertEqual(private.returncode,0,private.stdout+private.stderr)
        self.assertEqual(private.stdout,public.stdout)
        self.assertIn('INVENTORY 9',private.stdout)

    def test_status_inventory_failures_are_prevalidated_without_mutations(self):
        cases=(('wrong_endpoint_module','Wrong status endpoint module'),
               ('wrong_fanin','Status chain contains restart logic, a bus or another source'),
               ('depth','Changed status synchronizer depth'),
               ('missing_async_reg','Missing source ASYNC_REG property'),
               ('clock_mismatch','Wrong status register clock'))
        for scenario,message in cases:
            with self.subTest(scenario=scenario):
                body='''
set code [catch {rk_status_cdc_constrain platform/endpoint sys_clock clk_pll_i clk_pll_i_1} message]
puts "RESULT $code $message MUTATIONS [llength $changes]"
'''
                result=self.invoke(scenario,STATUS,body)
                self.assertEqual(result.returncode,0,result.stdout+result.stderr)
                self.assertIn('RESULT 1 '+message+' MUTATIONS 0',result.stdout)

@unittest.skipUnless(shutil.which('tclsh'),'Tcl interpreter required')
class PrivatePermitHelperTests(unittest.TestCase):
    def invoke(self,scenario,body):
        mock=DUAL_MOCK.replace('__SCENARIO__',tcl_literal(scenario))
        return run_tcl(mock,body,[STATUS,PERMIT])

    def test_registered_ui_to_sys_permit_has_only_first_d_cut(self):
        result=self.invoke('good','''
rk_cmac_permit_constrain platform/endpoint clk_pll_i sys_clock
foreach change $changes {puts $change}
puts PASS_PERMIT_CONSTRAINT
''')
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        false=[x for x in result.stdout.splitlines() if x.startswith('FALSE ')]
        props=[x for x in result.stdout.splitlines() if x.startswith('PROPERTY DONT_TOUCH TRUE ')]
        self.assertEqual(len(false),1,false)
        self.assertEqual(len(props),1,props)
        self.assertIn('permit_registered_reg/C',false[0])
        self.assertIn('permit_sync_reg[0]/D',false[0])
        self.assertNotIn('permit_sync_reg[1]/D',false[0])
        self.assertNotIn('permit_sync_reg[2]/D',false[0])
        self.assertIn('PASS_PERMIT_CONSTRAINT',result.stdout)

    def test_permit_rejects_bad_inventory_before_mutation(self):
        cases=(('wrong_endpoint_module','Wrong CMAC permit endpoint'),
               ('wrong_cmac_engine','Wrong CMAC permit engine'),
               ('permit_wrong_fanin','Status chain contains restart logic, a bus or another source'),
               ('permit_depth','Changed status synchronizer depth'),
               ('missing_async_reg','Missing source ASYNC_REG property'),
               ('permit_clock_mismatch','Wrong status register clock'))
        for scenario,message in cases:
            with self.subTest(scenario=scenario):
                result=self.invoke(scenario,'set code [catch {rk_cmac_permit_constrain platform/endpoint clk_pll_i sys_clock} message]\nputs "RESULT $code $message MUTATIONS [llength $changes]"')
                self.assertEqual(result.returncode,0,result.stdout+result.stderr)
                self.assertIn('RESULT 1 '+message+' MUTATIONS 0',result.stdout)

    def test_later_permit_paths_remain_active_with_exact_max_and_min_budgets(self):
        with tempfile.TemporaryDirectory() as directory:
            output=Path(directory)/'reports';output.mkdir()
            body='''
rk_cmac_permit_constrain platform/endpoint clk_pll_i sys_clock
rk_cmac_permit_audit platform/endpoint clk_pll_i sys_clock '''+tcl_literal(output)+'''
puts PASS_PERMIT_AUDIT
'''
            result=self.invoke('good',body)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            rows=(output/'cmac_permit_cdc.tsv').read_text().splitlines()
            self.assertEqual(sum(x.startswith('TIMED\t') for x in rows),4,rows)
            self.assertEqual(sum(x.startswith('TIMED\t') and x.split('\t')[3]=='max' and x.split('\t')[4]=='20.0' and float(x.split('\t')[5])>=0 for x in rows),2,rows)
            self.assertEqual(sum(x.startswith('TIMED\t') and x.split('\t')[3]=='min' and x.split('\t')[4]=='0.0' and float(x.split('\t')[5])>=0 for x in rows),2,rows)
            self.assertIn('PASS_PERMIT_AUDIT',result.stdout)

    def test_permit_audit_rejects_cut_failing_or_wrong_endpoint_later_paths(self):
        for scenario,message in (('permit_later_cut','CMAC permit later stage is cut, loosened or failing'),
                                 ('permit_later_fail','CMAC permit later stage is cut, loosened or failing'),
                                 ('permit_later_wrong_endpoint','CMAC permit later stage is cut, loosened or failing'),
                                 ('permit_first_cut_missing','First status path is not an explicit untimed false path'),
                                 ('permit_first_wrong_endpoint','First status path is not an explicit untimed false path')):
            with self.subTest(scenario=scenario),tempfile.TemporaryDirectory() as directory:
                output=Path(directory)/'reports';output.mkdir()
                body='''
rk_cmac_permit_constrain platform/endpoint clk_pll_i sys_clock
set code [catch {rk_cmac_permit_audit platform/endpoint clk_pll_i sys_clock '''+tcl_literal(output)+'''} message]
puts "RESULT $code $message"
'''
                result=self.invoke(scenario,body)
                self.assertEqual(result.returncode,0,result.stdout+result.stderr)
                self.assertIn('RESULT 1 '+message,result.stdout)
                self.assertNotIn('PASS_PERMIT_AUDIT',result.stdout)

if __name__=='__main__':unittest.main()
