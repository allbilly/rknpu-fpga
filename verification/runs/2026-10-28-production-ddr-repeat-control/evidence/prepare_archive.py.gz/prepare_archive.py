#!/usr/bin/env python3
"""Preserve selected source/text evidence for production auditor v14 and v13 parent history."""
from __future__ import annotations
import builtins, datetime, gzip, hashlib, json, pathlib, re, shutil, sys, symtable

ROOT=pathlib.Path('/home/fedora/rknpu-fpga')
AUDITORS=ROOT/'build/production-model-auditors'
V14=AUDITORS/'current-v14'; WS=V14/'workspace'; V13=AUDITORS/'current-v13'; WS13=V13/'workspace'
BASE=ROOT/'build/production-ddr-repeat-control-archive-v1'; GLOBAL_REPORT=BASE/'packer-global-bindings.json'
DEST=ROOT/'verification/runs/2026-10-28-production-ddr-repeat-control'
PACKER=pathlib.Path(__file__).resolve(); BLOCK=1024*1024
TEXT_SUFFIXES={'.log','.json','.txt','.hex','.jsonl','.partial','.rpt','.tsv','.csv'}

def need(ok,msg):
    if not ok: raise RuntimeError(msg)
def sha(path):
    h=hashlib.sha256()
    with pathlib.Path(path).open('rb') as f:
        for b in iter(lambda:f.read(BLOCK),b''):h.update(b)
    return h.hexdigest()
def load(path):return json.loads(pathlib.Path(path).read_text())
def repo_rel(path):
    p=pathlib.Path(path).resolve()
    try:return p.relative_to(ROOT).as_posix()
    except ValueError:return str(p)
def is_text(path):
    with pathlib.Path(path).open('rb') as f:
        for b in iter(lambda:f.read(BLOCK),b''):
            if b'\0' in b or any(x<32 and x not in (9,10,12,13) for x in b):return False
    return True
def copy_payload(src,dst,compress):
    src=pathlib.Path(src);dst=pathlib.Path(dst);dst.parent.mkdir(parents=True,exist_ok=True)
    hs=hashlib.sha256();source_bytes=0
    with src.open('rb') as inf,dst.open('wb') as rawout:
        if compress:
            with gzip.GzipFile(filename='',mode='wb',fileobj=rawout,compresslevel=9,mtime=0) as zout:
                for block in iter(lambda:inf.read(BLOCK),b''):
                    hs.update(block);source_bytes+=len(block);zout.write(block)
        else:
            for block in iter(lambda:inf.read(BLOCK),b''):
                hs.update(block);source_bytes+=len(block);rawout.write(block)
    return hs.hexdigest(),source_bytes,sha(dst),dst.stat().st_size

def hash_payload(path,encoding):
    h=hashlib.sha256();size=0
    with pathlib.Path(path).open('rb') as inf:
        if encoding=='gzip-mtime0-level9':
            with gzip.GzipFile(fileobj=inf,mode='rb') as source:
                for block in iter(lambda:source.read(BLOCK),b''):h.update(block);size+=len(block)
        else:
            for block in iter(lambda:inf.read(BLOCK),b''):h.update(block);size+=len(block)
    return h.hexdigest(),size

def global_scan(path):
    table=symtable.symtable(pathlib.Path(path).read_text(),str(path),'exec')
    top_defined={s.get_name() for s in table.get_symbols() if s.is_assigned() or s.is_imported() or s.is_namespace()}
    allowed=set(dir(builtins))|{'__file__','__name__','__package__','__spec__','__builtins__','__doc__','__annotations__'}
    errors=[]
    def visit(scope):
        for symbol in scope.get_symbols():
            if symbol.is_global() and symbol.is_referenced() and symbol.get_name() not in top_defined and symbol.get_name() not in allowed:
                errors.append({'scope':scope.get_name(),'line':scope.get_lineno(),'name':symbol.get_name()})
        for child in scope.get_children():visit(child)
    visit(table)
    return errors

global_errors=global_scan(PACKER)
global_report={'status':'PASS_STDLIB_SYMTABLE_GLOBAL_BINDINGS' if not global_errors else 'FAIL_UNRESOLVED_GLOBAL_BINDINGS',
               'packer_path':repo_rel(PACKER),'packer_sha256':sha(PACKER),'unresolved_globals':global_errors}
GLOBAL_REPORT.write_text(json.dumps(global_report,indent=2,sort_keys=True)+'\n')
if '--check-globals-only' in sys.argv:
    print(json.dumps(global_report,indent=2,sort_keys=True))
    raise SystemExit(0 if not global_errors else 1)
need(not global_errors,'archive packer has unresolved global names: '+repr(global_errors))
need(not DEST.exists(),f'archive destination must be fresh: {DEST}')
prod=load(V14/'report.json'); review=load(V14/'root-review.json'); agent=load(V14/'agent-review.json'); launch=load(V14/'launch.json')
prev=load(V13/'report.json'); prev_review=load(V13/'root-review.json'); prev_launch=load(V13/'launch.json')
need(prod['status']=='PASS_PRIVATE_COMPLETE_PRODUCTION_MAKE_TEST_V14_ONLY','v14 producer is not terminal PASS')
need(review['status']=='PASS_ROOT_V14_SOURCE_NATIVE_AND_COMPLETE_HOST_RECEIPT_REVIEW_ONLY','independent v14 review is not PASS')
need(prod['source_inputs']==prod['copied_inputs'] and len(prod['source_inputs'])==1095,'v14 source/copy closure changed')
need(review['source_sha256']==prod['source_revision_manifest']['sha256'] and
     review['recursive_source_sha256']==prod['private_copy_manifest_sha256'] and
     review['complete_source_files']==1095,'v14 source review binding mismatch')
need(review['producer_sha256']==sha(V14/'report.json') and
     launch['run_report_sha256']==sha(V14/'report.json'),'v14 producer report hash not bound by review/launch')
need(agent['status']=='PASS_AGENT_V14_SOURCE_NATIVE_AND_COMPLETE_HOST_RECEIPT_REVIEW_ONLY' and
     agent['producer_sha256']==sha(V14/'report.json') and agent['source_sha256']==review['source_sha256'] and
     agent['recursive_source_sha256']==review['recursive_source_sha256'] and
     agent['complete_source_files']==1095 and agent['software_ddr_control_methods']==89 and
     agent['ddr_model_audit_methods']==17,'v14 agent review source/control binding changed')
need(review['software_ddr_control_methods']==89 and review['dual_control_commands']==6,'v14 DDR/dual-control coverage changed')
need(review['numerical_or_ddr_composition_qualified_by_default_make'] is False and review['hardware_accessed'] is False,'v14 scope widened')
need(prod['hardware_accessed'] is False and prod['vivado_executed'] is False and
     launch['hardware_accessed'] is False and launch['vivado_executed'] is False and
     launch['flash_written'] is False,'v14 producer/launch scope widened')
need(launch['systemd_active_state']=='inactive' and launch['systemd_result']=='success' and launch['no_owned_processes_remaining'],
     'v14 scope not terminal-success or process cleanup incomplete')
need(launch['source_unchanged'] and launch['copy_unchanged'],'v14 source/copy integrity not preserved')
need(launch['systemd_invocation_id'] and all(x['pass'] for x in launch['admission_samples']),
     'v14 launch admission/provenance missing')
need(len(launch['admission_samples'])==3 and launch['admission_sample_count']==3 and
     launch['systemd_active_state']=='inactive' and launch['systemd_result']=='success',
     'v14 exact fresh resource samples or terminal scope metadata changed')
need(all(c['status']=='PASS' and c['returncode']==0 for c in prod['commands']),'v14 command failure not preserved')
need(prev['status']=='PASS_PRIVATE_COMPLETE_PRODUCTION_MAKE_TEST_V13_ONLY' and
     prev_review['status']=='PASS_INDEPENDENT_V13_SOURCE_NATIVE_AND_COMPLETE_HOST_RECEIPT_REVIEW_ONLY' and
     prev_launch['status']=='PASS_PRIVATE_COMPLETE_PRODUCTION_MAKE_TEST_V13_ONLY',
     'v13 parent history is not terminal PASS')
need(prev_review['source_sha256']==prev['source_revision_manifest']['sha256'] and
     prev_review['complete_source_files']==1095,'v13 parent history binding changed')
need(prev['source_inputs']==prev['copied_inputs'] and len(prev['source_inputs'])==1095 and
     prev_review['producer_sha256']==sha(V13/'report.json') and
     prev_review['recursive_source_sha256']==prev['private_copy_manifest_sha256'],
     'v13 preserved parent source/report closure changed')

sources={}
def add(path,role,expected=None,dest_hint=None,compress=True):
    p=pathlib.Path(path).resolve();need(p.is_file(),f'missing selected file: {p}')
    actual=sha(p)
    if expected is not None:need(actual==expected,f'hash mismatch: {p}')
    need(is_text(p),f'refusing non-text archive payload: {p}')
    key=str(p)
    if key in sources:
        need(sources[key]['sha256']==actual,'same source changed during selection')
        if role not in sources[key]['roles']:sources[key]['roles'].append(role)
        return
    if dest_hint is None:
        try:dest_hint='workspace/'+p.relative_to(WS).as_posix()
        except ValueError:dest_hint='evidence/'+repo_rel(p)
    sources[key]={'path':p,'sha256':actual,'bytes':p.stat().st_size,'roles':[role],
                  'archive_path':dest_hint,'compress':bool(compress and p.stat().st_size>16384)}

# Preserve the exact 1,095-file current source copy that the PASS v14 runner hashed.
for relpath,expected in sorted(prod['source_inputs'].items()):
    add(WS/relpath,'exact private v14 workspace input from source_inputs/copy_inputs',expected)

# Producer, independent review, launch metadata and actual build logs.
for p,role in [
    (V14/'report.json','v14 private complete make-test producer report'),
    (V14/'root-review.json','independent root v14 source/native/receipt review'),
    (V14/'agent-review.json','v14 agent source/native/receipt review'),
    (V14/'agent_review_v14.py','v14 agent reviewer implementation'),
    (V14/'root_review.py','independent root v14 reviewer implementation'),
    (V14/'run.py','v14 private production runner'),
    (V14/'collect_admission.py','v14 resource admission collector'),
    (V14/'launch.json','v14 argv/PIDs/cgroup/admission/terminal metadata'),
    (V14/'admission.json','three actual v14 resource admission samples'),
    (GLOBAL_REPORT,'stdlib symtable global-binding scan of archive packer'),
    (V14/'generated_check.stdout.log','generated-check stdout'),
    (V14/'generated_check.stderr.log','generated-check stderr'),
    (V14/'production_test.stdout.log','serial make test stdout'),
    (V14/'production_test.stderr.log','serial make test stderr')]:add(p,role)

# Keep exact v13 source closure and terminal receipts as preserved parent history.
for relpath,expected in sorted(prev['source_inputs'].items()):
    add(WS13/relpath,'exact private v13 workspace source/history input',expected,dest_hint='history/current-v13/workspace/'+relpath)
for p,role in [(V13/'report.json','parent v13 producer history'),
                (V13/'root-review.json','parent v13 independent review history'),
                (V13/'root_review_root.py','parent v13 root reviewer implementation history'),
                (V13/'root_review.py','parent v13 reviewer implementation history'),
                (V13/'run.py','parent v13 production runner history'),
                (V13/'launch.json','parent v13 launch history'),
                (V13/'admission.json','parent v13 admission history'),
                (V13/'generated_check.stdout.log','parent v13 generated-check stdout'),
                (V13/'generated_check.stderr.log','parent v13 generated-check stderr'),
                (V13/'production_test.stdout.log','parent v13 make-test stdout'),
                (V13/'production_test.stderr.log','parent v13 make-test stderr')]:
    add(p,role,dest_hint='history/current-v13/'+p.name)

# The five exact native/core reports are re-bound to the independent v14 review.
for relpath,facts in review['native_reports'].items():
    report_path=WS/'build'/relpath
    report_data=load(report_path)
    need(report_data.get('status')==facts['status'] and
         (not facts.get('tests') or len(report_data.get('tests',[]))==facts['tests']) and
         sha(report_path)==facts['sha256'],f"native/core report differs from v14 root review: {relpath}")
    add(report_path,f"v14 reviewed native/core report {relpath}",facts['sha256'])
# Generated compiler trees, simulators and object files remain excluded.
for rel_dir in ('build/rtl','build/iverilog','build/cmac_iverilog','build/cmac_verilator'):
    base=WS/rel_dir
    if not base.exists():continue
    for p in sorted(base.rglob('*')):
        if not p.is_file() or any(part.startswith('obj') for part in p.relative_to(base).parts):continue
        if p.suffix.lower() in TEXT_SUFFIXES:add(p,f'{rel_dir} textual native report/log/readback')

# Full host JTAG simulator reports and artifact-mapped textual logs/captures.
for h in review['host']:
    report=pathlib.Path(h['path']).resolve()
    need(sha(report)==h['sha256'],f'host report hash differs from root review: {report}')
    d=load(report);need(d['status']=='PASS' and len(d.get('tests',[]))==15,'host report is not a 15-case PASS')
    add(report,f"complete {h['simulator']} 15-case host-JTAG report",h['sha256'])
    for relpath,expected in d.get('artifacts',{}).get('files',{}).items():
        p=WS/relpath
        if p.suffix.lower() in TEXT_SUFFIXES:add(p,f"{h['simulator']} 15-case host-JTAG observed capture/log",expected)

# Shared registered memory report plus all text-only logs/reports from it.
registered_root=WS/'build/tinystories-registered-memory'
registered_reports=[p for p in registered_root.glob('*/report.json') if p.is_file()]
need(len(registered_reports)==1,'Expected exactly one v14 registered-memory report')
registered=registered_reports[0].parent
registered_report=load(registered_reports[0])
need(registered_report.get('status')=='PASS_SHARED_REGISTERED_MEMORY_BOTH_SIMULATORS',
     'v14 registered-memory report is not both-simulator PASS')
for p in sorted(registered.rglob('*')):
    if p.is_file() and p.suffix.lower() in TEXT_SUFFIXES:add(p,'v14 TinyStories shared registered-memory native report/log')
# Dual CSR/dispatcher six-command report and its text logs.
dual_root=WS/'build/ddr-dual-controls'
dual_reports=[p for p in dual_root.glob('*/report.json') if p.is_file()]
need(len(dual_reports)==1,'Expected exactly one v14 dual-control report')
dual=dual_reports[0].parent
dual_report=load(dual/'report.json')
need(dual_report['status']=='PASS_DUAL_CONTROL_BENCHES_ONLY' and len(dual_report['commands'])==6,'dual-control report changed')
need(sha(dual/'report.json')==review['dual_control_report_sha256'],'dual-control report hash differs from v14 root review')
for p in sorted(dual.rglob('*')):
    if p.is_file() and p.suffix.lower() in TEXT_SUFFIXES:add(p,'v14 six-command dual CSR/dispatcher control report/log')

make_test=prod['commands'][1]
make_test_text=pathlib.Path(make_test['stderr_log']).read_text(errors='replace')
summaries=[int(value) for value in re.findall(r'^Ran (\d+) tests? in ',make_test_text,re.M)]
need(len(summaries)>=9 and sum(summaries[-9:])==89 and summaries[-1]==17,
     'v14 default make did not execute the exact89-method DDR controls including17 DDR model-audit tests')
need('tests/tinystories' in pathlib.Path(make_test['stdout_log']).read_text(errors='replace') and
     'Ran 61 tests' in make_test_text,'v14 TinyStories 61-method group is not present in actual make logs')
need('tests/ddr/full512_image' in pathlib.Path(make_test['stdout_log']).read_text(errors='replace') and
     'Ran 14 tests' in make_test_text,'v14 full512 image controls are not present in actual make logs')

# Preserve V13 native/core reports and host-JTAG receipts as separate history.
for relpath,facts in prev_review['native_reports'].items():
    report_path=WS13/'build'/relpath
    report_data=load(report_path)
    need(report_data.get('status')==facts['status'] and sha(report_path)==facts['sha256'],
         'v13 historical native report differs from its review: '+relpath)
    add(report_path,'v13 parent-history native/core report '+relpath,facts['sha256'],
        dest_hint='history/current-v13/native/'+relpath)
for h in prev_review['host']:
    report_path=pathlib.Path(h['path']).resolve()
    need(sha(report_path)==h['sha256'],'v13 host receipt changed: '+str(report_path))
    data=load(report_path)
    need(data.get('status')=='PASS' and len(data.get('tests',[]))==15,
         'v13 parent host report is not a complete 15-case PASS')
    add(report_path,'v13 parent-history '+h['simulator']+' 15-case host report',h['sha256'],
        dest_hint='history/current-v13/host/'+h['simulator']+'/report.json')
    for relpath,expected in data.get('artifacts',{}).get('files',{}).items():
        artifact=WS13/relpath
        if artifact.suffix.lower() in TEXT_SUFFIXES:
            add(artifact,'v13 parent-history '+h['simulator']+' host capture/log',expected,
                dest_hint='history/current-v13/host/'+h['simulator']+'/'+relpath)
for rel_dir in ('build/rtl','build/iverilog','build/cmac_iverilog','build/cmac_verilator',
                'build/vectors','build/dma_vectors','build/cmac_vectors','build/fp16_product_vectors'):
    hist=WS13/rel_dir
    if not hist.exists():continue
    for path in sorted(hist.rglob('*')):
        if not path.is_file() or any(part.startswith('obj') for part in path.relative_to(hist).parts):continue
        if path.suffix.lower() in TEXT_SUFFIXES:
            add(path,'v13 parent-history '+rel_dir+' textual report/log/vector',
                dest_hint='history/current-v13/'+rel_dir+'/'+path.relative_to(hist).as_posix())
registered13=WS13/'build/tinystories-registered-memory'
registered13_reports=[path for path in registered13.glob('*/report.json') if path.is_file()]
need(len(registered13_reports)==1,'Expected exactly one v13 registered-memory report')
need(load(registered13_reports[0]).get('status')=='PASS_SHARED_REGISTERED_MEMORY_BOTH_SIMULATORS',
     'v13 parent registered-memory receipt changed')
for path in sorted(registered13_reports[0].parent.rglob('*')):
    if path.is_file() and path.suffix.lower() in TEXT_SUFFIXES:
        add(path,'v13 parent-history registered-memory report/log',
            dest_hint='history/current-v13/registered-memory/'+path.relative_to(registered13).as_posix())
dual13_root=WS13/'build/ddr-dual-controls'
dual13_reports=[path for path in dual13_root.glob('*/report.json') if path.is_file()]
need(len(dual13_reports)==1,'Expected exactly one v13 dual-control report')
dual13=dual13_reports[0].parent
dual13_report=load(dual13/'report.json')
need(dual13_report.get('status')=='PASS_DUAL_CONTROL_BENCHES_ONLY' and
     len(dual13_report.get('commands',[]))==6 and
     sha(dual13/'report.json')==prev_review['dual_control_report_sha256'],
     'v13 parent dual-control receipt changed')
for path in sorted(dual13.rglob('*')):
    if path.is_file() and path.suffix.lower() in TEXT_SUFFIXES:
        add(path,'v13 parent-history six-command dual control report/log',
            dest_hint='history/current-v13/dual-control/'+path.relative_to(dual13).as_posix())

# Preserve generated textual vector inputs and expected data used by the native
# suites. They are deterministic test data, not source RTL or binary images.
for rel_dir in ('build/vectors','build/dma_vectors','build/cmac_vectors','build/fp16_product_vectors'):
    base=WS/rel_dir
    if not base.exists():continue
    for p in sorted(base.rglob('*')):
        if p.is_file() and p.suffix.lower() in TEXT_SUFFIXES:add(p,'generated textual native test vector/expected data')

# Include this exact archive producer as evidence; its copy lives inside the
# archive while the executable packer itself remains outside the destination.
add(PACKER,'archive producer source',dest_hint='evidence/prepare_archive.py')

# Inventory every unselected private workspace build file, with exact hash and
# a concrete exclusion reason. No compiled artifact is copied into verification.
selected_paths={str(e['path'].resolve()) for e in sources.values()}
excluded=[]
for p in sorted((WS/'build').rglob('*')):
    if not p.is_file() or str(p.resolve()) in selected_paths:continue
    relp=p.relative_to(WS).as_posix();parts=set(p.relative_to(WS/'build').parts);suf=p.suffix.lower()
    if suf in {'.so','.vvp','.o','.a','.gch','.dcp','.bit','.elf','.exe','.dll','.bin'} or p.name in {'sim','csr.vvp','dispatch.vvp'}:
        reason='compiled object, simulator, image/checkpoint or binary fixture excluded; source reports retain invocation and hash coverage'
    elif any(x.startswith('obj') for x in parts) or suf in {'.cpp','.h','.mk','.d'}:
        reason='generated native compiler intermediates excluded; exact RTL source and compiler versions are archived'
    else:
        reason='generated build output outside selected native/core/host/dual report and text-vector scope'
    excluded.append({'source_path':relp,'bytes':p.stat().st_size,'sha256':sha(p),'reason':reason})

selected_paths_v13={str(e['path'].resolve()) for e in sources.values() if str(e['path'].resolve()).startswith(str(WS13.resolve())+'/')}
excluded_v13=[]
for p in sorted((WS13/'build').rglob('*')):
    if not p.is_file() or str(p.resolve()) in selected_paths_v13:continue
    relp=p.relative_to(WS13).as_posix();parts=set(p.relative_to(WS13/'build').parts);suf=p.suffix.lower()
    if suf in {'.so','.vvp','.o','.a','.gch','.dcp','.bit','.elf','.exe','.dll','.bin'} or p.name in {'sim','csr.vvp','dispatch.vvp'}:
        reason='compiled object, simulator, image/checkpoint or binary fixture excluded from preserved v13 parent history'
    elif any(x.startswith('obj') for x in parts) or suf in {'.cpp','.h','.mk','.d'}:
        reason='generated native compiler intermediates excluded; exact v13 RTL/source and tool versions are archived'
    else:
        reason='v13 generated build output outside selected native/core/host/dual report and text-vector scope'
    excluded_v13.append({'source_path':relp,'bytes':p.stat().st_size,'sha256':sha(p),'reason':reason})

# Record host tool executables without bundling them.
excluded_tools=[]
for name in ('python3','make','iverilog','vvp','verilator','c++','g++','tclsh'):
    found=shutil.which(name);need(found is not None,'host tool missing for exclusion inventory: '+name)
    p=pathlib.Path(found).resolve();need(p.is_file(),'tool executable missing: '+str(p))
    excluded_tools.append({'name':name,'source_path':str(p),'bytes':p.stat().st_size,'sha256':sha(p),
                           'reason':'host tool binary excluded; exact version is preserved in run/version reports'})
vivado=pathlib.Path('/home/fedora/vivado/2026.1/Vivado/bin/vivado')
if vivado.is_file():
    excluded_tools.append({'name':'vivado','source_path':str(vivado.resolve()),'bytes':vivado.stat().st_size,'sha256':sha(vivado),
                           'reason':'Vivado binary excluded; v14 did not invoke Vivado'})

# Recheck every selected source after inventory, then deterministic copy.
for key,e in sources.items():need(sha(e['path'])==e['sha256'],'selected source drift before archive: '+key)
if '--preflight-only' in sys.argv:
    print(json.dumps({'status':'PASS_ARCHIVE_PREFLIGHT_ONLY','selected_payloads':len(sources),
                      'selected_source_bytes':sum(e['bytes'] for e in sources.values()),
                      'v14_private_source_count':len(prod['source_inputs']),
                      'v13_parent_source_count':len(prev['source_inputs']),
                      'global_bindings_status':global_report['status'],
                      'destination_created':DEST.exists()},indent=2))
    raise SystemExit(0)
DEST.mkdir(parents=True)
files=[];stored_by_source={}
for key,e in sorted(sources.items(),key=lambda kv:kv[1]['archive_path']):
    src=e['path'];relout=e['archive_path'];compress=e['compress']
    if compress:relout += '.gz'
    dst=DEST/relout
    actual,source_bytes,stored_hash,stored_bytes=copy_payload(src,dst,compress)
    need(actual==e['sha256'] and source_bytes==e['bytes'],'source changed during archive copy: '+key)
    item={'source_path':repo_rel(src),'archive_path':relout,'roles':e['roles'],
          'source_sha256':actual,'source_bytes':source_bytes,'stored_sha256':stored_hash,
          'stored_bytes':stored_bytes,'encoding':'gzip-mtime0-level9' if compress else 'identity'}
    files.append(item);stored_by_source[key]=item
# Re-read/decompress every copied payload and compare source hash/size.
for item in files:
    stored=DEST/item['archive_path']
    need(sha(stored)==item['stored_sha256'],'stored archive hash mismatch')
    encoding=item['encoding']
    observed,raw_bytes=hash_payload(stored,encoding)
    need(observed==item['source_sha256'] and raw_bytes==item['source_bytes'],'archive decode mismatch: '+item['archive_path'])
# All selected original source hashes must still match after the copy.
for key,e in sources.items():need(sha(e['path'])==e['sha256'],'selected source changed after archive copy: '+key)

# Explicitly cover every source input and every root-reviewed report. The
# coverage path is taken from the materialized file row after the optional
# .gz suffix has been decided, never reconstructed from a logical name.
coverage=[]
def cover(label,path,expected,role):
    p=pathlib.Path(path).resolve();key=str(p)
    need(key in stored_by_source,f'coverage target was not archived: {p}')
    item=stored_by_source[key]
    need(item['source_sha256']==expected==sha(p),f'coverage source hash mismatch: {p}')
    coverage.append({'label':label,'source_path':repo_rel(p),'source_sha256':expected,
                     'source_bytes':p.stat().st_size,'role':role,
                     'archive_path':item['archive_path'],'archive_sha256':item['stored_sha256'],
                     'archive_bytes':item['stored_bytes'],'encoding':item['encoding']})

for relpath,expected in sorted(prod['source_inputs'].items()):
    cover('private_source:'+relpath,WS/relpath,expected,'exact v14 private workspace source/copy input')
for relpath,expected in sorted(prev['source_inputs'].items()):
    cover('history_v13_source:'+relpath,WS13/relpath,expected,'exact preserved v13 private source/history input')
cover('v14:producer_report',V14/'report.json',review['producer_sha256'],'v14 producer report bound by root review')
cover('v14:independent_root_review',V14/'root-review.json',sha(V14/'root-review.json'),'independent v14 review')
cover('v14:agent_review',V14/'agent-review.json',sha(V14/'agent-review.json'),'v14 agent source/native/receipt review')
cover('v14:packer_global_bindings',GLOBAL_REPORT,sha(GLOBAL_REPORT),'stdlib symtable global-binding check before archive copy')
for relpath,facts in sorted(review['native_reports'].items()):
    cover('v14:native_report:'+relpath,WS/'build'/relpath,facts['sha256'],'root-reviewed native/core report')
for h in review['host']:
    report_path=pathlib.Path(h['path']).resolve()
    cover('v14:host_report:'+h['simulator'],report_path,h['sha256'],'root-reviewed host JTAG report')
    report_data=load(report_path)
    for relpath,expected in sorted(report_data.get('artifacts',{}).get('files',{}).items()):
        artifact=WS/relpath
        if artifact.suffix.lower() in TEXT_SUFFIXES and str(artifact.resolve()) in stored_by_source:
            cover('v14:host_artifact:'+h['simulator']+':'+relpath,artifact,expected,
                  'included text host-JTAG capture/log')
dual_path=dual/'report.json'
cover('v14:dual_control_report',dual_path,review['dual_control_report_sha256'],
      'six-command dual-control report bound by root review')
for label,path in [('v14:launch',V14/'launch.json'),('v14:admission',V14/'admission.json'),
                   ('v13:parent_report',V13/'report.json'),('v13:parent_review',V13/'root-review.json')]:
    cover(label,path,sha(path),'included current/parent provenance receipt')
for relpath,facts in sorted(prev_review['native_reports'].items()):
    cover('v13:native_report:'+relpath,WS13/'build'/relpath,facts['sha256'],'preserved v13 reviewed native/core report')
for h in prev_review['host']:
    report_path=pathlib.Path(h['path']).resolve()
    cover('v13:host_report:'+h['simulator'],report_path,h['sha256'],'preserved v13 reviewed host report')
    report_data=load(report_path)
    for relpath,expected in sorted(report_data.get('artifacts',{}).get('files',{}).items()):
        artifact=WS13/relpath
        if artifact.suffix.lower() in TEXT_SUFFIXES and str(artifact.resolve()) in stored_by_source:
            cover('v13:host_artifact:'+h['simulator']+':'+relpath,artifact,expected,
                  'included preserved v13 host-JTAG capture/log')
cover('v13:dual_control_report',dual13/'report.json',prev_review['dual_control_report_sha256'],
      'preserved v13 reviewed six-command dual-control report')
cover('v13:registered_memory_report',registered13_reports[0],sha(registered13_reports[0]),
      'preserved v13 both-simulator registered-memory report')
cover('v14:root_review_script',V14/'root_review.py',sha(V14/'root_review.py'),'v14 independent root review implementation')
cover('v14:agent_review_script',V14/'agent_review_v14.py',sha(V14/'agent_review_v14.py'),'v14 agent review implementation')
cover('v14:generated_check_stdout',V14/'generated_check.stdout.log',sha(V14/'generated_check.stdout.log'),'actual generated-check stdout')
cover('v14:generated_check_stderr',V14/'generated_check.stderr.log',sha(V14/'generated_check.stderr.log'),'actual generated-check stderr')
cover('v14:make_test_stdout',V14/'production_test.stdout.log',sha(V14/'production_test.stdout.log'),'actual serial make-test stdout')
cover('v14:make_test_stderr',V14/'production_test.stderr.log',sha(V14/'production_test.stderr.log'),'actual serial make-test stderr')
actual_archive_paths={item['archive_path'] for item in files}
for ref in coverage:
    need(ref['archive_path'] in actual_archive_paths,
         'coverage archive_path does not name the actual stored file: '+ref['archive_path'])
    payload=DEST/ref['archive_path']
    need(payload.is_file() and sha(payload)==ref['archive_sha256'],
         'coverage points to missing or mismatched stored payload: '+ref['archive_path'])

index={'schema':1,'status':'PASS_PRODUCTION_DDR_REPEAT_CONTROL_V14_SOURCE_AND_TEXT_ARCHIVE',
       'scope':{'evidence_scope':'Exact current-v14 private 1,095-file source copy, native/core/host/dual reports, logs, text vectors, repeated-BOS DDR-model controls, and agent/root reviews; exact current-v13 private source and terminal receipts preserved as parent history.',
                'source_revision_sha256':prod['source_revision_manifest']['sha256'],
                'full_recursive_source_sha256':prod['full_recursive_source_manifest']['sha256'],
                'source_inputs':1095,'parent_v13_source_inputs':1095,
                'private_make_test':'PASS; generated-check PASS; serial make test PASS in 6GiB/2CPU/no-swap/256-task scope',
                'tinystories_test_methods':61,'software_ddr_control_methods':89,'dual_control_commands':6,
                'full512_image_template_controls':14,'full512_image_bitstream_emitted':False,
                'hardware_accessed':False,'vivado_executed':False,'bitstream_emitted':False,'flash_written':False,
                'physical_ddr_qualified':False,'full512_ddr_hardware_qualified':False,
                'preserved_parent_history':'Exact current-v13 private source, producer/root-review/launch/admission/logs, native/core/host reports and text captures; V6 route failure history remains outside this archive'},
       'file_count':len(files),'source_bytes':sum(x['source_bytes'] for x in files),
       'stored_bytes':sum(x['stored_bytes'] for x in files),'encoding_policy':'Text payloads larger than 16 KiB use deterministic gzip level 9 with mtime=0; other payloads are identity encoded. Archive paths record the actual stored filename including .gz.',
       'files':files,'coverage_references':coverage,
       'excluded_workspace_build_outputs':excluded,'excluded_workspace_file_count':len(excluded),
       'excluded_workspace_bytes':sum(x['bytes'] for x in excluded),
       'excluded_parent_v13_build_outputs':excluded_v13,'excluded_parent_v13_build_file_count':len(excluded_v13),
       'excluded_parent_v13_build_bytes':sum(x['bytes'] for x in excluded_v13),
       'excluded_host_tool_binaries':excluded_tools,
       'packer_path':repo_rel(PACKER),'packer_sha256':sha(PACKER),
       'producer_report_sha256':sha(V14/'report.json'),'independent_review_sha256':sha(V14/'root-review.json'),'agent_review_sha256':sha(V14/'agent-review.json'),
       'launch_sha256':sha(V14/'launch.json'),'admission_sha256':sha(V14/'admission.json'),
       'parent_v13_report_sha256':sha(V13/'report.json'),'parent_v13_review_sha256':sha(V13/'root-review.json'),
       'parent_v13_launch_sha256':sha(V13/'launch.json'),'packer_global_bindings_sha256':sha(GLOBAL_REPORT),
       'agent_review_implementation_sha256':sha(V14/'agent_review_v14.py'),
       'root_review_implementation_sha256':sha(V14/'root_review.py'),
       'parent_v13_recursive_source_sha256':prev['private_copy_manifest_sha256']}
index_path=DEST/'index.json';index_path.write_text(json.dumps(index,indent=2,sort_keys=True)+'\n')
# Exact archive inventory after index exists; index is the sole metadata sidecar.
actual_files={p.relative_to(DEST).as_posix() for p in DEST.rglob('*') if p.is_file()}
expected_files={x['archive_path'] for x in files}|{'index.json'}
need(actual_files==expected_files,'archive contains extras or omits selected evidence')
print(json.dumps({'status':index['status'],'archive':repo_rel(DEST),'file_count':len(files),
                  'source_bytes':index['source_bytes'],'stored_bytes':index['stored_bytes'],
                  'excluded_workspace_file_count':len(excluded),'excluded_workspace_bytes':index['excluded_workspace_bytes'],
                  'index_sha256':sha(index_path),'packer_sha256':sha(PACKER)},indent=2))
