#!/usr/bin/env python3
"""Deterministic source/text receipt archive for V15 DDR capacity-pattern controls."""
import builtins,datetime,gzip,hashlib,json,pathlib,re,shutil,symtable,sys
ROOT=pathlib.Path('/home/fedora/rknpu-fpga'); AUDITORS=ROOT/'build/production-model-auditors'
V15=AUDITORS/'current-v15';WS=V15/'workspace';V14=AUDITORS/'current-v14'
V14_INDEX=ROOT/'verification/runs/2026-10-28-production-ddr-repeat-control/index.json'
BASE=ROOT/'build/production-ddr-capacity-plan-archive-v1'
GLOBAL=BASE/'packer-global-bindings.json';DEST=ROOT/'verification/runs/2026-10-28-production-ddr-capacity-plan'
PACKER=pathlib.Path(__file__).resolve();BLOCK=1<<20
TEXT_SUFFIXES={'.log','.txt','.json','.jsonl','.tsv','.rpt','.hex','.partial','.csv'}
TEXT_SUFFIXES={'.log','.json','.txt','.hex','.jsonl','.partial','.rpt','.tsv','.csv'}
def need(ok,msg):
 if not ok:raise RuntimeError(msg)
def sha(path):
 h=hashlib.sha256()
 with pathlib.Path(path).open('rb') as f:
  for b in iter(lambda:f.read(BLOCK),b''):h.update(b)
 return h.hexdigest()
def load(path):return json.loads(pathlib.Path(path).read_text())
def repo_rel(path):
 p=pathlib.Path(path).resolve()
 try:return p.relative_to(ROOT).as_posix()
 except ValueError:return str(p)
def is_text(path):
 with pathlib.Path(path).open('rb') as f:
  for b in iter(lambda:f.read(BLOCK),b''):
   if b'\0' in b or any(x<32 and x not in (9,10,12,13) for x in b):return False
 return True
def global_scan(path):
 table=symtable.symtable(pathlib.Path(path).read_text(),str(path),'exec')
 defined={s.get_name() for s in table.get_symbols() if s.is_assigned() or s.is_imported() or s.is_namespace()}
 allowed=set(dir(builtins))|{'__file__','__name__','__package__','__spec__','__builtins__','__doc__','__annotations__'}
 errors=[]
 def visit(scope):
  for s in scope.get_symbols():
   if s.is_global() and s.is_referenced() and s.get_name() not in defined and s.get_name() not in allowed:
    errors.append({'scope':scope.get_name(),'line':scope.get_lineno(),'name':s.get_name()})
  for child in scope.get_children():visit(child)
 visit(table);return errors
def copy_payload(src,dst,encoding):
 src=pathlib.Path(src);dst=pathlib.Path(dst);dst.parent.mkdir(parents=True,exist_ok=True)
 h=hashlib.sha256();n=0
 with src.open('rb') as inf,dst.open('wb') as raw:
  if encoding=='gzip-mtime0-level9':
   with gzip.GzipFile(filename='',mode='wb',fileobj=raw,compresslevel=9,mtime=0) as out:
    for b in iter(lambda:inf.read(BLOCK),b''):h.update(b);n+=len(b);out.write(b)
  else:
   for b in iter(lambda:inf.read(BLOCK),b''):h.update(b);n+=len(b);raw.write(b)
 return h.hexdigest(),n,sha(dst),dst.stat().st_size
def decoded_hash(path,encoding):
 h=hashlib.sha256();n=0
 with pathlib.Path(path).open('rb') as raw:
  stream=gzip.GzipFile(fileobj=raw,mode='rb') if encoding=='gzip-mtime0-level9' else raw
  for b in iter(lambda:stream.read(BLOCK),b''):h.update(b);n+=len(b)
 return h.hexdigest(),n
errs=global_scan(PACKER)
global_receipt={'status':'PASS_STDLIB_SYMTABLE_GLOBAL_BINDINGS' if not errs else 'FAIL_UNRESOLVED_GLOBAL_BINDINGS',
                'packer_path':repo_rel(PACKER),'packer_sha256':sha(PACKER),'unresolved_globals':errs}
GLOBAL.write_text(json.dumps(global_receipt,indent=2,sort_keys=True)+'\n')
if '--check-globals-only' in sys.argv:
 print(json.dumps(global_receipt,indent=2,sort_keys=True));raise SystemExit(0 if not errs else 1)
need(not errs,'Unresolved archive-packer globals: '+repr(errs))
need(not DEST.exists(),'Archive destination must be fresh')
prod=load(V15/'report.json');review=load(V15/'root-review.json');agent=load(V15/'agent-review.json');launch=load(V15/'launch.json');admission=load(V15/'admission.json')
parent=load(V14/'report.json');parent_review=load(V14/'root-review.json');parent_agent=load(V14/'agent-review.json');parent_index=load(V14_INDEX)
need(prod['status']=='PASS_PRIVATE_COMPLETE_PRODUCTION_MAKE_TEST_V15_ONLY','V15 producer is not PASS')
need(review['status']=='PASS_ROOT_V15_SOURCE_NATIVE_AND_COMPLETE_HOST_RECEIPT_REVIEW_ONLY','V15 root review is not PASS')
need(agent['status']=='PASS_AGENT_V15_SOURCE_NATIVE_AND_COMPLETE_HOST_RECEIPT_REVIEW_ONLY','V15 agent review is not PASS')
need(prod['source_inputs']==prod['copied_inputs'] and len(prod['source_inputs'])==1098,'V15 source/copy closure changed')
need(review['producer_sha256']==sha(V15/'report.json') and agent['producer_sha256']==sha(V15/'report.json') and
     launch['run_report_sha256']==sha(V15/'report.json'),'V15 report hash binding changed')
need(review['complete_source_files']==1098 and agent['complete_source_files']==1098 and
     review['recursive_source_sha256']==prod['private_copy_manifest_sha256'],'V15 source review binding changed')
expected_added=['tests/ddr/capacity/test_pattern.py','tools/ddr/capacity_pattern.py','tools/ddr/prepare_capacity_test.py']
need(review['v14_to_v15_added']==expected_added and review['v14_to_v15_changed']==[] and
     agent['v14_to_v15_added']==expected_added and agent['v14_to_v15_changed']==[],'V15 source delta changed')
expected_hashes={'tests/ddr/capacity/test_pattern.py':'8b2bf034503c3bca44128fb3097325206f5fecbd27558c2f178acde7d0cf25ca',
 'tools/ddr/capacity_pattern.py':'3131740f6304895e5fb5e38696a10724dcf06d8b1e14ef5549b5481632153a69',
 'tools/ddr/prepare_capacity_test.py':'cc2b5a36db4897dd9cde172a7c60318c4228c3709acbe40fc17d446908ab2e9e'}
need({p:prod['source_inputs'][p] for p in expected_hashes}==expected_hashes,'Changed V15 capacity source hashes')
need(review['software_ddr_control_methods']==89 and agent['software_ddr_control_methods']==89 and
     review['ddr_model_audit_methods']==17 and agent['ddr_model_audit_methods']==17,'Default DDR control corpus changed')
need(agent['supplemental_capacity_pattern_methods']==7 and agent['supplemental_is_physical_capacity_evidence'] is False,
     'Supplemental capacity controls incorrectly claim physical coverage')
need(parent['status']=='PASS_PRIVATE_COMPLETE_PRODUCTION_MAKE_TEST_V14_ONLY' and
     parent_review['status']=='PASS_ROOT_V14_SOURCE_NATIVE_AND_COMPLETE_HOST_RECEIPT_REVIEW_ONLY' and
     parent_agent['status']=='PASS_AGENT_V14_SOURCE_NATIVE_AND_COMPLETE_HOST_RECEIPT_REVIEW_ONLY',
     'Preserved V14 parent history is not terminal PASS')
need(parent_index['status']=='PASS_PRODUCTION_DDR_REPEAT_CONTROL_V14_SOURCE_AND_TEXT_ARCHIVE' and
     parent_index['scope']['source_inputs']==1095,'V14 parent archive index/source scope changed')
need(launch['systemd_active_state']=='inactive' and launch['systemd_result']=='success' and
     launch['no_owned_processes_remaining'] and launch['source_unchanged'] and launch['copy_unchanged'],
     'V15 launch/source/process terminal receipt changed')
need(admission['status']=='RESOURCE_GATE_PASS_FOR_PRODUCTION_V15' and len(admission['last_three_pass'])==3 and
     all(x['pass'] for x in admission['last_three_pass']),'V15 admission samples changed')
need([x['argv'] for x in prod['commands']]==[['make','generated-check'],['make','test'],
  ['python3','-m','unittest','discover','-s','tests/ddr/capacity','-p','test*.py','-v']],
  'V15 command list/order changed')
for c in prod['commands']:
 need(c['status']=='PASS' and c['returncode']==0 and c['seconds']<c['timeout_seconds'] and
      sha(c['stdout_log'])==c['stdout_sha256'] and sha(c['stderr_log'])==c['stderr_sha256'],
      'V15 command log/status changed: '+c['name'])
need(review['hardware_accessed'] is False and prod['hardware_accessed'] is False and
     prod['vivado_executed'] is False and prod['flash_written'] is False and
     agent['supplemental_is_physical_capacity_evidence'] is False,
     'V15 source/control review scope widened')
dual_reports=list((WS/'build/ddr-dual-controls').glob('*/report.json'))
need(len(dual_reports)==1 and sha(dual_reports[0])==review['dual_control_report_sha256'],
     'V15 dual control report differs from root review')
dual_data=load(dual_reports[0])
need(dual_data['status']=='PASS_DUAL_CONTROL_BENCHES_ONLY' and len(dual_data['commands'])==6 and
     dual_data['control_models_selected'] is True and dual_data['numerical_qualified'] is False,
     'V15 dual-control receipt scope changed')

sources={}
def add(path,role,expected=None,dest_hint=None,allow_binary_data=False):
 p=pathlib.Path(path).resolve();need(p.is_file(),'Missing selected archive file: '+str(p));h=sha(p)
 if expected is not None:need(h==expected,'Selected source hash mismatch: '+str(p))
 text=is_text(p)
 if not text:need(allow_binary_data,'Unexpected non-text archive input: '+str(p))
 key=str(p)
 if dest_hint is None:
  try:dest_hint='workspace/'+p.relative_to(WS).as_posix()
  except ValueError:dest_hint='evidence/'+repo_rel(p)
 if key in sources:
  need(sources[key]['source_sha256']==h,'Selected source changed under alias')
  if role not in sources[key]['roles']:sources[key]['roles'].append(role)
  return
 encoding='identity' if allow_binary_data else 'gzip-mtime0-level9' if p.stat().st_size>16384 else 'identity'
 sources[key]={'path':p,'source_sha256':h,'source_bytes':p.stat().st_size,'roles':[role],
               'archive_path':dest_hint,'encoding':encoding,'kind':'data' if allow_binary_data else 'text'}
# Exact current V15 source closure (all1098 inputs), no source regeneration or rebuild.
for relpath,h in sorted(prod['source_inputs'].items()):
 need(sha(ROOT/relpath)==h,'Live V15 source differs from frozen producer map: '+relpath)
 add(WS/relpath,'exact private V15 source/copy input',h)
# Producer, reviewers, launch/admission, and complete command logs.
for p,role in [(V15/'report.json','V15 production producer report'),(V15/'agent-review.json','V15 agent source/native/control review'),
 (V15/'root-review.json','V15 root independent source/native/control review'),(V15/'agent_review_v15.py','V15 agent reviewer implementation'),
 (V15/'root_review.py','V15 root reviewer implementation'),(V15/'run.py','V15 private runner'),(V15/'launch.json','V15 argv/PID/cgroup/admission/terminal metadata'),
 (V15/'admission.json','V15 three passing admission samples'),(V15/'collect_admission.py','V15 admission collector source'),
 (V15/'generated_check.stdout.log','generated-check stdout'),(V15/'generated_check.stderr.log','generated-check stderr'),
 (V15/'production_test.stdout.log','serial make-test stdout'),(V15/'production_test.stderr.log','serial make-test stderr'),
 (V15/'capacity_controls.stdout.log','supplemental seven-method capacity control stdout'),
 (V15/'capacity_controls.stderr.log','supplemental seven-method capacity control stderr')]:add(p,role)
# Parent V14 history references the already archived complete source copy; avoid copying its 1095 payload files again.
for p,role in [(V14/'report.json','parent V14 producer/source manifest history'),(V14/'root-review.json','parent V14 root review history'),
 (V14/'agent-review.json','parent V14 agent review history'),(V14_INDEX,'parent V14 complete archive index/source payload reference')]:add(p,role)
# Rebind the current root-reviewed native/core and host reports.
for relpath,facts in review['native_reports'].items():
 q=WS/'build'/relpath;data=load(q)
 need(data['status']==facts['status'] and sha(q)==facts['sha256'] and
      (not facts.get('tests') or len(data.get('tests',[]))==facts['tests']),'Native report mismatch: '+relpath)
 add(q,'V15 root-reviewed native/core report '+relpath,facts['sha256'])
for h in review['host']:
 q=pathlib.Path(h['path']).resolve();need(sha(q)==h['sha256'],'Host report differs from V15 root review')
 data=load(q);need(data['status']=='PASS' and len(data.get('tests',[]))==15,'Host report is not full 15-case PASS')
 add(q,'V15 root-reviewed '+h['simulator']+' host-JTAG report',h['sha256'])
 for relpath,expected in data.get('artifacts',{}).get('files',{}).items():
  artifact=WS/relpath
  if artifact.is_file() and artifact.suffix.lower() in {'.log','.txt','.json','.jsonl','.tsv','.rpt','.hex','.partial','.csv'}:
   add(artifact,'V15 '+h['simulator']+' host capture/text artifact',expected)
# Include all text-only model/dual reports and logs, but no compiler binaries/intermediates.
for rel_dir in ('build/rtl','build/iverilog','build/cmac_iverilog','build/cmac_verilator','build/vectors','build/dma_vectors',
                'build/cmac_vectors','build/fp16_product_vectors','build/tinystories-registered-memory','build/ddr-dual-controls'):
 base=WS/rel_dir
 if not base.exists():continue
 for q in sorted(base.rglob('*')):
  if q.is_file() and q.suffix.lower() in {'.log','.txt','.json','.jsonl','.tsv','.rpt','.hex','.partial','.csv'}:
   if any(part.startswith('obj') for part in q.relative_to(base).parts):continue
   add(q,'V15 '+rel_dir+' text report/log/vector')
# Preserve exact V14 source hash history in its producer manifest; no duplicate parent source payloads.
# Source-bound software-only capacity plan contract: archive the prepared contract/outputs via source+test and literal actual unittest logs.
capacity_contract={'path':'tools/ddr/prepare_capacity_test.py','sha256':expected_hashes['tools/ddr/prepare_capacity_test.py'],
 'pattern_source_path':'tools/ddr/capacity_pattern.py','pattern_source_sha256':expected_hashes['tools/ddr/capacity_pattern.py'],
 'default_base':0,'default_size_bytes':2147483648,'default_seed':0x3588c350,'line_bytes':64,'lines':33554432,
 'trials':2,'operations':134217728,'verified_read_bytes':4294967296,
 'ordering':'each trial writes the full range before any reads; second-trial writes descend; reads ascend',
 'plan_only':True,'operation_records_materialized':False,'hardware_executed':False,'physical_capacity_qualified':False,
 'controller_retirement_and_ecc_witness_required_separately':True,'supplemental_test_methods':7,
 'evidence_source':'V15 separate unittest stdout/stderr and frozen source test; not a generated physical run receipt'}
contract_bytes=(json.dumps(capacity_contract,indent=2,sort_keys=True)+'\n').encode()
contract_path=BASE/'capacity-plan-contract.json'
if contract_path.exists():need(contract_path.read_bytes()==contract_bytes,'Capacity contract metadata changed')
else:contract_path.write_bytes(contract_bytes)
add(contract_path,'V15 software capacity-plan contract metadata',hashlib.sha256(contract_bytes).hexdigest(),dest_hint='evidence/capacity-plan-contract.json')
for path,role,dest in [(PACKER,'archive packer source','evidence/prepare_archive.py'),
                       (GLOBAL,'stdlib global-binding check receipt','evidence/packer-global-bindings.json'),
                       (BASE/'run_archive.py','archive runner source','evidence/run_archive.py'),
                       (BASE/'verify_archive.py','independent archive rehash source','evidence/verify_archive.py')]:
 add(path,role,dest_hint=dest)
make_test=prod['commands'][1];make_text=pathlib.Path(make_test['stderr_log']).read_text(errors='replace')
unit_summaries=[int(n) for n in re.findall(r'^Ran (\d+) tests? in ',make_text,re.M)]
need(len(unit_summaries)>=9 and sum(unit_summaries[-9:])==89 and unit_summaries[-1]==17,
     'Actual make test does not contain unchanged 89 DDR host controls/17 model-audit tests')
need('Ran 61 tests' in make_text and 'Ran 14 tests' in make_text,'Actual default TinyStories/full512 test groups missing')
cap=prod['commands'][2];captext=pathlib.Path(cap['stdout_log']).read_text()+pathlib.Path(cap['stderr_log']).read_text()
need('Ran 7 tests' in captext and 'OK' in captext,'Actual supplemental capacity control did not pass seven methods')
# Include build-side V14 archive index only; its coverage points back to an already preserved sibling archive.
# Source and build outputs not selected into payload are hash inventoried with explicit exclusion reason.
selected={str(v['path'].resolve()) for v in sources.values()}
excluded=[]
for q in sorted((WS/'build').rglob('*')):
 if not q.is_file() or str(q.resolve()) in selected:continue
 rel=q.relative_to(WS).as_posix();parts=set(q.relative_to(WS/'build').parts);suffix=q.suffix.lower()
 if suffix in {'.so','.vvp','.o','.a','.gch','.dcp','.bit','.elf','.exe','.dll','.bin'} or q.name in {'sim','csr.vvp','dispatch.vvp'}:
  reason='compiled object/simulator/image/checkpoint/binary fixture excluded; exact source, invocation, reports and output hashes are retained'
 elif any(part.startswith('obj') for part in parts) or suffix in {'.cpp','.h','.mk','.d'}:
  reason='generated native compiler intermediate excluded; source and tool versions are in the archive'
 else:reason='build output outside selected report/log/vector scope'
 excluded.append({'source_path':rel,'bytes':q.stat().st_size,'sha256':sha(q),'reason':reason})
excluded_tools=[]
for name in ('python3','make','iverilog','vvp','verilator','c++','g++','tclsh'):
 found=shutil.which(name);need(found,'Missing host executable '+name);p=pathlib.Path(found).resolve()
 excluded_tools.append({'name':name,'source_path':str(p),'bytes':p.stat().st_size,'sha256':sha(p),'reason':'tool executable excluded; actual version appears in V15 run reports/logs'})
vivado=pathlib.Path('/home/fedora/vivado/2026.1/Vivado/bin/vivado')
if vivado.is_file():excluded_tools.append({'name':'vivado','source_path':str(vivado.resolve()),'bytes':vivado.stat().st_size,'sha256':sha(vivado),'reason':'Vivado binary excluded; V15 did not invoke Vivado'})
# Capacity contract source and all selected V15 sources are rechecked immediately before any copy.
for entry in sources.values():need(sha(entry['path'])==entry['source_sha256'],'Source changed before archive copy: '+str(entry['path']))
if '--preflight-only' in sys.argv:
 print(json.dumps({'status':'PASS_V15_ARCHIVE_PREFLIGHT_ONLY','payload_count':len(sources),'source_bytes':sum(x['source_bytes'] for x in sources.values()),
  'current_source_files':len(prod['source_inputs']),'v14_source_payloads_duplicated':False,
  'capacity_plan_contract':capacity_contract,'destination_created':DEST.exists()},indent=2));raise SystemExit(0)
DEST.mkdir(parents=True)
files=[];by_source={}
for key,entry in sorted(sources.items(),key=lambda x:x[1]['archive_path']):
 rel=entry['archive_path'];enc=entry['encoding']
 if enc=='gzip-mtime0-level9':rel+='.gz'
 path=DEST/rel;source_sha,source_bytes,stored_sha,stored_bytes=copy_payload(entry['path'],path,enc)
 need(source_sha==entry['source_sha256'] and source_bytes==entry['source_bytes'],'Source changed during copy: '+key)
 row={'source_path':repo_rel(entry['path']),'archive_path':rel,'roles':entry['roles'],'kind':entry['kind'],
  'source_sha256':source_sha,'source_bytes':source_bytes,'stored_sha256':stored_sha,'stored_bytes':stored_bytes,'encoding':enc}
 files.append(row);by_source[key]=row
for row in files:
 path=DEST/row['archive_path'];need(sha(path)==row['stored_sha256'],'Stored payload changed')
 digest,size=decoded_hash(path,row['encoding']);need(digest==row['source_sha256'] and size==row['source_bytes'],'Decode/origin mismatch')
 source=pathlib.Path(row['source_path']);source=source if source.is_absolute() else ROOT/source
 need(sha(source)==row['source_sha256'],'Origin changed after archive copy')
# Coverage binds all V15 sources/receipts, reports, captures and parent history files to actual stored names.
coverage=[]
def cover(label,path,expected,role):
 p=pathlib.Path(path).resolve();key=str(p);need(key in by_source,'Coverage source not archived: '+key)
 row=by_source[key];need(row['source_sha256']==expected==sha(p),'Coverage hash mismatch: '+key)
 coverage.append({'label':label,'source_path':repo_rel(p),'source_sha256':expected,'source_bytes':p.stat().st_size,'role':role,
  'archive_path':row['archive_path'],'archive_sha256':row['stored_sha256'],'archive_bytes':row['stored_bytes'],'encoding':row['encoding']})
for rel,h in sorted(prod['source_inputs'].items()):cover('V15_source:'+rel,WS/rel,h,'exact V15 1098-file private source/copy input')
for label,path in [('V15_producer',V15/'report.json'),('V15_agent_review',V15/'agent-review.json'),('V15_root_review',V15/'root-review.json'),
 ('V15_launch',V15/'launch.json'),('V15_admission',V15/'admission.json'),('V15_capacity_stdout',V15/'capacity_controls.stdout.log'),
 ('V15_capacity_stderr',V15/'capacity_controls.stderr.log'),('V14_parent_report',V14/'report.json'),
 ('V14_parent_root_review',V14/'root-review.json'),('V14_parent_agent_review',V14/'agent-review.json'),('V14_parent_archive_index',V14_INDEX)]:
 cover(label,path,sha(path),'current or parent receipt')
for relpath,facts in review['native_reports'].items():
 path=WS/'build'/relpath
 cover('V15_native:'+relpath,path,facts['sha256'],'root-reviewed native/core report')
for host in review['host']:
 path=pathlib.Path(host['path']).resolve();cover('V15_host_report:'+host['simulator'],path,host['sha256'],'root-reviewed host report')
 data=load(path)
 for rel,h in data.get('artifacts',{}).get('files',{}).items():
  item=WS/rel
  if item.suffix.lower() in TEXT_SUFFIXES and str(item.resolve()) in by_source:cover('V15_host_artifact:'+host['simulator']+':'+rel,item,h,'included text host-JTAG capture')
cover('V15_dual_control_report',next((WS/'build/ddr-dual-controls').glob('*/report.json')),review['dual_control_report_sha256'],'six-command dual control report')
cover('capacity_pattern_source',WS/'tools/ddr/capacity_pattern.py',expected_hashes['tools/ddr/capacity_pattern.py'],'source-only deterministic plan/verifier')
cover('capacity_prepare_source',WS/'tools/ddr/prepare_capacity_test.py',expected_hashes['tools/ddr/prepare_capacity_test.py'],'offline JSON plan CLI')
cover('capacity_tests_source',WS/'tests/ddr/capacity/test_pattern.py',expected_hashes['tests/ddr/capacity/test_pattern.py'],'seven software contract controls')
cover('capacity_plan_contract',contract_path,sha(contract_path),'frozen source-derived software-only plan contract; physical=false')
for c in coverage:need((DEST/c['archive_path']).is_file() and sha(DEST/c['archive_path'])==c['archive_sha256'],'Missing coverage archive path '+c['archive_path'])
index={'schema':1,'status':'PASS_PRODUCTION_DDR_CAPACITY_PLAN_V15_SOURCE_AND_TEXT_ARCHIVE',
 'scope':{'evidence_scope':'V15 full default software/control regression plus a supplemental seven-method deterministic DDR capacity-plan/verifier suite. The suite creates no operation stream and does not perform physical DDR access or qualify capacity.',
  'v15_source_files':1098,'v14_parent_source_files_copied':False,
  'default_software_ddr_control_methods':89,'supplemental_capacity_pattern_methods':7,
  'capacity_plan_contract':capacity_contract,'capacity_plan_physical_capacity_qualified':False,
  'hardware_accessed':False,'vivado_executed':False,'flash_written':False,'physical_capacity_qualified':False,
  'preserved_parent_history':'V14 producer/root/agent reports with complete source hashes and V14 archive index; V14 source payloads remain in the sibling archive.'},
 'file_count':len(files),'source_bytes':sum(x['source_bytes'] for x in files),'stored_bytes':sum(x['stored_bytes'] for x in files),
 'encoding_policy':'Text payloads larger than16KiB use deterministic gzip level9/mtime0; smaller text identity. No compiled tool/image/checkpoint binaries included.',
 'files':files,'coverage_references':coverage,'excluded_workspace_build_outputs':excluded,'excluded_workspace_file_count':len(excluded),
 'excluded_workspace_bytes':sum(x['bytes'] for x in excluded),'excluded_host_tool_binaries':excluded_tools,
 'producer_report_sha256':sha(V15/'report.json'),'agent_review_sha256':sha(V15/'agent-review.json'),'root_review_sha256':sha(V15/'root-review.json'),
 'launch_sha256':sha(V15/'launch.json'),'admission_sha256':sha(V15/'admission.json'),
 'parent_v14_report_sha256':sha(V14/'report.json'),'parent_v14_root_review_sha256':sha(V14/'root-review.json'),
 'parent_v14_agent_review_sha256':sha(V14/'agent-review.json'),'parent_v14_archive_index_sha256':sha(V14_INDEX),
 'packer_path':repo_rel(PACKER),'packer_sha256':sha(PACKER),'global_binding_receipt_sha256':sha(GLOBAL)}
idx=DEST/'index.json';idx.write_text(json.dumps(index,indent=2,sort_keys=True)+'\n')
actual={p.relative_to(DEST).as_posix() for p in DEST.rglob('*') if p.is_file()}
need(actual=={x['archive_path'] for x in files}|{'index.json'},'Archive inventory contains unlisted/missing files')
print(json.dumps({'status':index['status'],'archive':repo_rel(DEST),'payload_count':len(files),'source_bytes':index['source_bytes'],
 'stored_bytes':index['stored_bytes'],'coverage_references':len(coverage),'v15_sources':1098,'parent_v14_source_payloads':0,
 'supplemental_capacity_methods':7,'physical_capacity_qualified':False,'index_sha256':sha(idx),'packer_sha256':sha(PACKER)},indent=2))
