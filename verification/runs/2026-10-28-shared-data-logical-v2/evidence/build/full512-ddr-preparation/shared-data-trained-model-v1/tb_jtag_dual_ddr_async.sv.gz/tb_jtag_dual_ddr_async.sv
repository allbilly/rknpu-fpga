// SPDX-License-Identifier: MIT
`timescale 1ns/1ps
// Raw public frames -> real EW RTL -> AXI/UI/MC logic with encoded DRAM model.
// Training, pads, clocks and actual FPGA operation are outside this test.
module tb_jtag_dual_ddr_async;
  localparam logic [31:0] BASE=32'h10000000;
  localparam logic [32:0] BYTES=33'd1048576;
  logic sys_clk,c0_ui_clk,c1_ui_clk;
  initial begin sys_clk=0;c0_ui_clk=0;c1_ui_clk=0;end
  always #10 sys_clk=~sys_clk;
  always #3.75 c0_ui_clk=~c0_ui_clk;
  always #4.25 c1_ui_clk=~c1_ui_clk;
  logic cfg_reset,reset_req_valid;
  wire reset_req_ready,mig_sys_rst_n,sys_clients_rst_n,c0_clients_rst_n,c1_clients_rst_n;
  wire c0_aresetn,c1_aresetn,sequence_busy,sequence_complete,admission_blocked,sequence_fault;
  wire [7:0] sequence_fault_code;
  logic c0_ui_clk_sync_rst,c1_ui_clk_sync_rst,c0_trained;
  logic lose_calibration=0;
  // An external loss override changes the actual input before the next launch
  // edge; it never forces DUT state or merely queues a later model update.
  wire c0_init_calib_complete=c0_trained&&!lose_calibration;
  integer bringup0,bringup1;
  always @(posedge c0_ui_clk) begin
    if(!mig_sys_rst_n)begin bringup0<=0;c0_ui_clk_sync_rst<=1;c0_trained<=0;end
    else begin
      if(bringup0<40)bringup0<=bringup0+1;
      if(bringup0>=12)c0_ui_clk_sync_rst<=0;
      if(bringup0>=24)c0_trained<=1;
    end
  end
  always @(posedge c1_ui_clk) begin
    if(!mig_sys_rst_n)begin bringup1<=0;c1_ui_clk_sync_rst<=1;end
    else begin
      if(bringup1<40)bringup1<=bringup1+1;
      if(bringup1>=15)c1_ui_clk_sync_rst<=0;
    end
  end
  logic req_valid=0;
  wire req_ready,rsp_valid,irq,fault,init_complete,init_active,memory_ready;
  wire job_owned,job_active,job_retired;
  logic [603:0] req=0;
  wire [511:0] rsp_data;
  wire [7:0] rsp_status,fault_code;
  wire [15:0] rsp_seq;
  wire [3:0] m_axi_awid,m_axi_arid,m_axi_bid,m_axi_rid;
  wire [30:0] m_axi_awaddr,m_axi_araddr;
  wire [7:0] m_axi_awlen,m_axi_arlen;
  wire [2:0] m_axi_awsize,m_axi_arsize,m_axi_awprot,m_axi_arprot;
  wire [1:0] m_axi_awburst,m_axi_arburst,m_axi_bresp,m_axi_rresp;
  wire m_axi_awlock,m_axi_arlock,m_axi_awvalid,m_axi_awready,m_axi_wlast,m_axi_wvalid,m_axi_wready;
  wire m_axi_bvalid,m_axi_bready,m_axi_arvalid,m_axi_arready,m_axi_rlast,m_axi_rvalid,m_axi_rready;
  wire [3:0] m_axi_awcache,m_axi_arcache,m_axi_awqos,m_axi_arqos;
  wire [511:0] m_axi_wdata,m_axi_rdata;
  wire [63:0] m_axi_wstrb;
  wire [31:0] m_axi_ctrl_awaddr,m_axi_ctrl_wdata,m_axi_ctrl_araddr,m_axi_ctrl_rdata;
  wire m_axi_ctrl_awvalid,m_axi_ctrl_awready,m_axi_ctrl_wvalid,m_axi_ctrl_wready;
  wire m_axi_ctrl_bvalid,m_axi_ctrl_bready,m_axi_ctrl_arvalid,m_axi_ctrl_arready;
  wire m_axi_ctrl_rvalid,m_axi_ctrl_rready,c0_interrupt;
  wire model_ctrl_arready,model_ctrl_rvalid,model_ctrl_arvalid,model_ctrl_rready;
  logic stall_ctrl=0;
  assign m_axi_ctrl_arready=model_ctrl_arready&&!stall_ctrl;
  assign m_axi_ctrl_rvalid=model_ctrl_rvalid&&!stall_ctrl;
  assign model_ctrl_arvalid=m_axi_ctrl_arvalid&&!stall_ctrl;
  assign model_ctrl_rready=m_axi_ctrl_rready&&!stall_ctrl;
  wire [1:0] m_axi_ctrl_bresp,m_axi_ctrl_rresp;
  rk_jtag_dual_ddr_async #(.BASE(BASE),.BYTES(BYTES),.TIMEOUT_CYCLES(2048),.MAX_TASKS(4),
    .RESET_WAIT_TIMEOUT_CYCLES(1024)) dut(.*);

  logic inj_ue_next_rmw=0,hold_phy_write_full=0,drop_read_return=0;
  wire [31:0] write_commit_count,read_return_count,pending_writes;
  wire inj_ue_fired;
  rk_mig_logic_model #(.BASE(BASE),.BYTES(1048576)) memory_model (
    .clk(c0_ui_clk),.rst(c0_ui_clk_sync_rst),.aresetn(c0_aresetn),
    .calib_complete(c0_init_calib_complete),.interrupt(c0_interrupt),
    .m_axi_ctrl_arready(model_ctrl_arready),.m_axi_ctrl_rvalid(model_ctrl_rvalid),
    .m_axi_ctrl_arvalid(model_ctrl_arvalid),.m_axi_ctrl_rready(model_ctrl_rready),.*
  );

  integer commands,init_aw,init_w,job_aw,retired_count,dma_launches,fabric_claims;
  integer data_ar_count,read64_packets,read64_axi_reads;
  logic old_irq,inj_seen;
  logic [30:0] final_job_aw,final_job_ar;
  always @(posedge c0_ui_clk) begin
    if(!c0_clients_rst_n)begin
      init_aw<=0;init_w<=0;job_aw<=0;retired_count<=0;
      old_irq<=0;inj_seen<=0;final_job_aw<=0;final_job_ar<=0;
      dma_launches<=0;fabric_claims<=0;
      data_ar_count<=0;
    end else begin
      if(m_axi_arvalid&&m_axi_arready)data_ar_count<=data_ar_count+1;
      old_irq<=irq;
      if(inj_ue_fired)inj_seen<=1;
      if(dut.dma_start_valid&&dut.dma_start_ready)dma_launches<=dma_launches+1;
      if(dut.job_begin&&dut.job_begin_ready)fabric_claims<=fabric_claims+1;
      if(init_active&&m_axi_awvalid&&m_axi_awready)begin
        if({1'b0,m_axi_awaddr}!==BASE+32'(init_aw*64))$fatal(1,"Initialization address sequence");
        init_aw<=init_aw+1;
      end
      if(init_active&&m_axi_wvalid&&m_axi_wready)begin
        if(m_axi_wdata!==0||m_axi_wstrb!==64'hffffffffffffffff||m_axi_wlast!==1)
          $fatal(1,"Initialization must write complete zero/ECC beats");
        init_w<=init_w+1;
      end
      if(job_active&&m_axi_awvalid&&m_axi_awready)begin
        final_job_aw<=m_axi_awaddr;job_aw<=job_aw+1;
      end
      if(job_active&&m_axi_arvalid&&m_axi_arready)final_job_ar<=m_axi_araddr;
      if(job_retired)begin
        if(pending_writes!==0||final_job_ar!==final_job_aw||job_aw==0)
          $fatal(1,"Job retired before actual writes/exact-address fence");
        retired_count<=retired_count+1;
      end
      if(irq&&!old_irq&&!fault&&pending_writes!==0)$fatal(1,"Successful IRQ while PHY writes pending");
    end
  end

  logic [31:0] csr_base;
  logic [15:0] sequence_id;
  task automatic command(input logic[7:0]op,input logic[31:0]address,input logic[511:0]data,
    output logic[511:0]result,input logic[7:0]status=0,input logic[3:0]strobes=15);
    integer guard,reads_before;
    guard=0;while(!req_ready)begin @(negedge c0_ui_clk);guard=guard+1;if(guard>5000)$fatal(1,"Frame admission stalled");end
    reads_before=data_ar_count;
    @(negedge c0_ui_clk);sequence_id=sequence_id==16'hffff ? 16'd1 : sequence_id+1;
    req={32'h4f54504a,sequence_id,op,strobes,address,data};req_valid=1;
    @(negedge c0_ui_clk);req_valid=0;req='0;guard=0;
    while(!rsp_valid)begin @(negedge c0_ui_clk);guard=guard+1;if(guard>20000)$fatal(1,"Frame response stalled op%0d",op);end
    if(rsp_seq!==sequence_id||rsp_status!==status)$fatal(1,"Frame error op%0d status%h expected%h",op,rsp_status,status);
    if(op==3&&status==0)begin
      if(data_ar_count-reads_before!=1)$fatal(1,"READ64 must use exactly one physical AXI read, got%0d",data_ar_count-reads_before);
      read64_packets=read64_packets+1;read64_axi_reads=read64_axi_reads+data_ar_count-reads_before;
    end
    result=rsp_data;if(status!=0&&result!==0)$fatal(1,"Error leaked payload");
    commands=commands+1;@(negedge c0_ui_clk);
  endtask
  task automatic register_command(input logic[7:0]op,input logic[31:0]offset,
    input logic[511:0]data,output logic[511:0]result,input logic[7:0]status=0,
    input logic[3:0]strobes=15);
    command(op,offset<32'h100 ? csr_base+offset : offset,data,result,status,strobes);
  endtask
  logic [511:0] value,upload_line,expected_line;
  logic [31:0] address;
  integer fd,observed,polls;
/* verilator lint_off INCABSPATH */
`include `RK_DDR_LINE_IMAGE_HEADER
/* verilator lint_on INCABSPATH */
  task automatic report_boot_state(input string phase);
    $display("DDR_BOOT phase=%s time=%0t sys_reset=%b mig_sys_rst_n=%b sys_clients_rst_n=%b c0_clients_rst_n=%b c1_clients_rst_n=%b c0_ui_sync_rst=%b c1_ui_sync_rst=%b c0_trained=%b seq_busy=%b seq_complete=%b seq_fault=%b seq_fault_code=%02h admission_blocked=%b req_ready=%b fault=%b fault_code=%02h init_active=%b init_complete=%b memory_ready=%b init_aw=%0d init_w=%0d commits=%0d pending=%0d",
      phase,$time,cfg_reset,mig_sys_rst_n,sys_clients_rst_n,c0_clients_rst_n,c1_clients_rst_n,
      c0_ui_clk_sync_rst,c1_ui_clk_sync_rst,c0_trained,sequence_busy,sequence_complete,
      sequence_fault,sequence_fault_code,admission_blocked,req_ready,fault,fault_code,
      init_active,init_complete,memory_ready,init_aw,init_w,write_commit_count,pending_writes);
    $fflush();
  endtask
  // Optional progress independent of the main stimulus coroutine: distinguish
  // slow advancing simulation from a frame wait or initialization fault.
  bit boot_tick_enabled;
  integer boot_tick_cycles;
  initial boot_tick_cycles=0;
  initial boot_tick_enabled=$test$plusargs("DDR_BOOT_TICK");
  always @(posedge c0_ui_clk) begin
    if(!c0_clients_rst_n)boot_tick_cycles<=0;
    else if(boot_tick_enabled)begin
      boot_tick_cycles<=boot_tick_cycles+1;
      if((boot_tick_cycles%1024)==0)begin
        report_boot_state("independent_ui_tick");
        $display("DDR_BUS tick=%0d req_valid=%b rsp_valid=%b rsp_status=%02h ctrl_AW=%b/%b ctrl_W=%b/%b ctrl_B=%b/%b ctrl_AR=%b/%b ctrl_R=%b/%b mem_AW=%b/%b mem_W=%b/%b mem_B=%b/%b mem_AR=%b/%b mem_R=%b/%b",
          boot_tick_cycles,req_valid,rsp_valid,rsp_status,m_axi_ctrl_awvalid,m_axi_ctrl_awready,
          m_axi_ctrl_wvalid,m_axi_ctrl_wready,m_axi_ctrl_bvalid,m_axi_ctrl_bready,
          m_axi_ctrl_arvalid,m_axi_ctrl_arready,m_axi_ctrl_rvalid,m_axi_ctrl_rready,
          m_axi_awvalid,m_axi_awready,m_axi_wvalid,m_axi_wready,m_axi_bvalid,m_axi_bready,
          m_axi_arvalid,m_axi_arready,m_axi_rvalid,m_axi_rready);
        $fflush();
      end
    end
  end
  task automatic expect_reg(input logic[31:0]off,input logic[31:0]expected);
    register_command(1,off,0,value);if(value!=={480'b0,expected})$fatal(1,"Register%h got%h expected%h",off,value,expected);
  endtask
  task automatic await_initialization;
    polls=0;
    while(!init_complete&&!fault)begin
      @(negedge c0_ui_clk);polls=polls+1;
      if(polls%100000==0)report_boot_state("initializing");
      if(polls>2000000)$fatal(1,"Init timeout");
    end
    if(fault||!memory_ready||c0_aresetn!==1'b1||c1_aresetn!==1'b1||
       init_aw!=16384||init_w!=16384||write_commit_count!=16384||pending_writes!=0)
      $fatal(1,"Incomplete hardware initialization aw%0d w%0d committed%0d",init_aw,init_w,write_commit_count);
  endtask

  integer engine_writes,phase,prior_writes,prior_launches,prior_claims,prior_retire;
  integer actual_upload_lines;
  string directory,output_directory;
  always @(posedge c0_ui_clk)begin
    if(!c0_clients_rst_n)engine_writes<=0;
    else if(dut.engine_req_valid&&dut.engine_req_ready&&dut.engine_req_write)
      engine_writes<=engine_writes+1;
  end
  task automatic phase_log(input string state_name);
    $display("TRAINED_DDR phase=%0d stage=%s time=%0t uploaded_lines=%0d engine_writes=%0d phy_returns=%0d",
             phase,state_name,$time,actual_upload_lines,engine_writes,read_return_count);
    $fflush();
  endtask
  task automatic trained_upload(input string name,input integer count,input logic initialized_zero);
    logic [31:0] previous;
    ddr_image_open({directory,"/",name},count,fd);previous=0;
    for(integer line=0;line<count;line=line+1)begin
      ddr_image_read(fd,line,previous,address,upload_line);previous=address;
      // Initial zero lines are already written/fenced by the actual controller.
      // Every delta line is transferred, including explicit zero padding.
      if(!initialized_zero||upload_line!==0)begin
        command(4,address,upload_line,value);actual_upload_lines=actual_upload_lines+1;
      end
    end
    ddr_image_finish(fd);
  endtask
  task automatic trained_check(input string name,input string capture_name);
    logic [31:0] previous;
    ddr_image_open({directory,"/",name},1408,fd);previous=0;
    observed=$fopen({output_directory,"/",capture_name},"w");
    if(observed==0)$fatal(1,"Missing complete BO capture target");
    for(integer line=0;line<1408;line=line+1)begin
      ddr_image_read(fd,line,previous,address,expected_line);previous=address;
      command(3,address,0,value);
      $fdisplay(observed,"%08h %0128h",address,value);
      if(value!==expected_line)$fatal(1,"Trained full DDR BO mismatch at%h",address);
    end
    ddr_image_finish(fd);$fclose(observed);
  endtask
  task automatic stage_trained(input logic [31:0] amount,input logic [31:0] job_tag);
    register_command(2,32'h10,512'h100e0000,value);
    register_command(2,32'h14,{480'b0,amount},value);
    register_command(2,32'h18,{480'b0,job_tag},value);
  endtask
  task automatic await_trained(input logic [31:0] job_tag,input logic [31:0] tasks);
    polls=0;value=0;
    while(!value[2])begin
      register_command(1,8,0,value);polls=polls+1;
      if(polls>100000)$fatal(1,"Trained DDR result watchdog");
    end
    if(value[1]||value[3]||value[5]||value[6]||!irq||fault||!job_owned||!job_retired&&retired_count==prior_retire)
      $fatal(1,"Trained job did not retain a successful retired result");
    expect_reg(32'h1c,job_tag);expect_reg(32'h20,tasks);expect_reg(32'h24,0);
    if(engine_writes-prior_writes!=32||dma_launches-prior_launches!=1||
       fabric_claims-prior_claims!=1||retired_count-prior_retire!=1||pending_writes!=0)
      $fatal(1,"Trained job bypassed exact writes/launch/fence/ECC retirement");
  endtask
  task automatic ack_trained;
    register_command(2,32'h0c,512'd2,value);
    polls=0;
    while(job_owned||!memory_ready||dut.control_owned)begin
      @(negedge c0_ui_clk);polls=polls+1;
      if(polls>100)$fatal(1,"Trained ACK did not release both owners");
    end
    if(irq||fault)$fatal(1,"Trained ACK left result/fault active");
  endtask
  initial begin
    cfg_reset=1;reset_req_valid=0;c0_ui_clk_sync_rst=1;c1_ui_clk_sync_rst=1;
    c0_trained=0;bringup0=0;bringup1=0;commands=0;sequence_id=0;
    read64_packets=0;read64_axi_reads=0;actual_upload_lines=0;phase=-1;csr_base=0;
    if(!$value$plusargs("DIRECTORY=%s",directory)||
       !$value$plusargs("OUTPUT_DIRECTORY=%s",output_directory))$fatal(1,"Missing static trained-vector paths");
    repeat(5)@(negedge sys_clk);cfg_reset=0;
    polls=0;while(!req_ready)begin
      @(negedge c0_ui_clk);polls=polls+1;
      if(polls>10000)$fatal(1,"Trained endpoint boot admission timeout");
    end
    expect_reg(0,32'h524b4144);expect_reg(4,32'h10000);
    csr_base=32'h100;expect_reg(0,32'h524b4344);expect_reg(4,32'h10000);
    command(3,BASE,0,value,2);await_initialization();
    if(!reset_req_ready)$fatal(1,"Joint epoch reset owner is not idle after initialization");
    phase_log("initialized");
    command(3,BASE,0,value);if(value!==0)$fatal(1,"First initialized DDR line differs");
    command(3,BASE+32'hfffc0,0,value);if(value!==0)$fatal(1,"Last initialized DDR line differs");
    command(4,BASE+32'hfffc0,0,value);
    trained_upload("initial.txt",1408,1'b1);
    if(actual_upload_lines!=265)$fatal(1,"Changed complete trained initial upload inventory");
    for(phase=0;phase<3;phase=phase+1)begin
      if(phase==1)begin csr_base=0;trained_upload("ew_delta.txt",9,1'b0);end
      else begin
        csr_base=32'h100;
        if(phase==2)trained_upload("repeat_delta.txt",11,1'b0);
      end
      phase_log("uploaded");
      stage_trained(phase==1 ? 32'd22 : 32'd45,32'habc00001+32'(phase));
      prior_writes=engine_writes;prior_launches=dma_launches;
      prior_claims=fabric_claims;prior_retire=retired_count;
      register_command(2,32'h0c,512'd1,value);phase_log("submitted");
      // The other bank cannot stage, submit or ACK while this owner is held.
      command(2,csr_base==0 ? 32'h110 : 32'h10,512'h100e0000,value,2);
      command(2,csr_base==0 ? 32'h10c : 32'h0c,512'd1,value,2);
      command(2,csr_base==0 ? 32'h10c : 32'h0c,512'd2,value,2);
      command(3,BASE+32'h10000,0,value,2);
      await_trained(32'habc00001+32'(phase),phase==1 ? 32'd2 : 32'd1);
      phase_log("retired");
      if(phase==0)trained_check("cmac_expected.txt","cmac-actual.txt");
      else if(phase==1)trained_check("ew_expected.txt","ew-actual.txt");
      else trained_check("repeat_expected.txt","repeat-actual.txt");
      phase_log("readback_before_ack");ack_trained();phase_log("acknowledged");
    end
    if(inj_seen||engine_writes!=96||dut.engine.cmac.engine.rearm_count!=2||
       actual_upload_lines!=285||dma_launches!=3||fabric_claims!=3||retired_count!=3||
       read64_packets!=4226||read64_axi_reads!=4226||read_return_count!=27614)
      $fatal(1,"Trained alternation traffic, ownership or numerical rearm inventory differs");
    $display("PASS trained_tile_dual_ddr cmac_jobs=2 ew_tasks=2 engine_writes=96 rearm=2 checked_bo_lines=4224 phy_user_returns=27614 read64_packets=4226 read64_axi_reads=4226 scope=actual_AXI_UI_MC_modeled_PHY");
    $finish;
  end
  initial begin repeat(100000000)@(posedge c0_ui_clk);$fatal(1,"Trained joined DDR cycle watchdog");end
endmodule
