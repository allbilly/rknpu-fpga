`timescale 1ns/1ps
module tb_capacity_sweep;
  logic clk=0; always #5 clk=~clk;
  logic joint_rst_n,start_valid; logic start_ready;
  logic [31:0] seed; logic initialization_complete,calibration_complete,ecc_monitor_healthy,owner_exclusive;
  logic busy,done,fault; logic [7:0] fault_code; logic trial;
  logic [31:0] completed_writes,completed_reads;
  logic [30:0] mismatch_address; logic [511:0] mismatch_expected,mismatch_actual;
  logic line_valid,line_ready,line_write,line_rsp_valid,line_rsp_ready,line_rsp_error;
  logic [30:0] line_address; logic [511:0] line_wdata,line_rdata;
  logic retire_valid,retire_ready,retire_rsp_valid,retire_rsp_ready,retire_rsp_ok;
  logic [30:0] retire_last_write_address;
  logic [31:0] retire_ecc_status,retire_ecc_onoff,retire_ecc_irq_mask;
  localparam logic [30:0] BASE=0;
  localparam logic [31:0] SPAN=256;
  localparam integer LINES=4;
  localparam logic [30:0] LAST=31'd192;
  logic [511:0] mem[0:3];
  logic alias_mode;
  logic [31:0] test_seed;
  integer expected_writes,expected_reads,fence_count,total_line_ops;

  rk_ddr_capacity_sweep #(.BASE_ADDR(BASE),.SPAN_BYTES(SPAN),.TIMEOUT_CYCLES(20)) dut(.*);

  function automatic logic [511:0] reference_pattern(input logic [30:0] address,
      input logic [31:0] seed_value,input logic trial_value);
    logic [31:0] line_index,salt;
    integer lane;
    begin
      line_index={7'b0,address[30:6]};
      for(lane=0;lane<16;lane=lane+1) begin
        salt=lane*32'h9e3779b9;
        reference_pattern[lane*32 +: 32]=line_index ^ seed_value ^ salt ^ {32{trial_value}};
      end
    end
  endfunction

  function automatic integer backing_slot(input logic [30:0] address);
    if (alias_mode) backing_slot=address[7:7];
    else backing_slot=address[7:6];
  endfunction

  task automatic fail(input string message);
    $display("FAIL_SWEEP %s",message);$fatal(1);
  endtask

  task automatic reset_dut;
    integer i;
    begin
      @(negedge clk);joint_rst_n=0;start_valid=0;line_ready=0;line_rsp_valid=0;line_rsp_error=0;
      line_rdata='0;retire_ready=0;retire_rsp_valid=0;retire_rsp_ok=1;
      retire_ecc_status=0;retire_ecc_onoff=1;retire_ecc_irq_mask=3;
      initialization_complete=1;calibration_complete=1;ecc_monitor_healthy=1;owner_exclusive=1;
      seed=0;alias_mode=0;
      repeat(3) @(posedge clk);
      @(negedge clk);joint_rst_n=1;
      for(i=0;i<4;i=i+1)mem[i]='0;
      expected_writes=0;expected_reads=0;fence_count=0;total_line_ops=0;
      repeat(1) @(posedge clk);#1;
      if(start_ready!==1'b1 || fault!==1'b0 || done!==1'b0)fail("reset release state incorrect");
    end
  endtask

  task automatic begin_sweep(input logic [31:0] seed_value);
    begin
      test_seed=seed_value;
      @(negedge clk);seed=seed_value;start_valid=1;
      if(start_ready!==1'b1)fail("start_ready not offered in idle");
      @(posedge clk);#1;
      if(busy!==1'b1 || fault!==1'b0)fail("start did not activate sweep");
      @(negedge clk);start_valid=0;seed=~seed_value; // Prove the seed was captured on the start handshake.
    end
  endtask

  task automatic wait_line;
    integer n;
    begin
      n=0;
      while(line_valid!==1'b1 && n<80)begin @(negedge clk);n=n+1;end
      if(line_valid!==1'b1)fail("timed out waiting for line request");
    end
  endtask

  task automatic transact_line(input logic write_expected,input logic trial_expected,
      input logic [30:0] address_expected,input integer stall_cycles,input integer response_delay,
      input logic response_error,input logic corrupt_response);
    logic [30:0] saved_address;
    logic [511:0] saved_data,read_payload;
    logic saved_write;
    integer n,slot;
    begin
      wait_line();
      saved_address=line_address;saved_data=line_wdata;saved_write=line_write;
      if(saved_address!==address_expected || saved_write!==write_expected || trial!==trial_expected)
        fail($sformatf("request order/metadata mismatch got write=%b trial=%b address=%h expected write=%b trial=%b address=%h",
          saved_write,trial,saved_address,write_expected,trial_expected,address_expected));
      if(saved_data!==reference_pattern(address_expected,test_seed,trial_expected))
        fail($sformatf("write/read request payload mismatch at %h",address_expected));
      if(retire_valid!==1'b0)fail("fence offered concurrently with line request");
      line_ready=0;
      for(n=0;n<stall_cycles;n=n+1)begin
        @(posedge clk);#1;
        if(line_valid!==1'b1 || line_address!==saved_address || line_wdata!==saved_data || line_write!==saved_write)
          fail("line request/payload changed while READY stalled");
      end
      @(negedge clk);line_ready=1;
      @(posedge clk);#1;
      line_ready=0;
      if(line_valid!==1'b0)fail("accepted request remained asserted");
      slot=backing_slot(saved_address);
      if(saved_write)mem[slot]=saved_data;
      else begin
        read_payload=mem[slot];
        if(corrupt_response)read_payload[9]=~read_payload[9];
      end
      if(line_rsp_ready!==1'b1)fail("response-ready did not follow accepted request");
      repeat(response_delay)@(posedge clk);
      @(negedge clk);line_rsp_valid=1;line_rsp_error=response_error;
      line_rdata=saved_write ? '0 : read_payload;
      if(line_rsp_ready!==1'b1)fail("line response not ready");
      @(posedge clk);#1;
      @(negedge clk);line_rsp_valid=0;line_rsp_error=0;line_rdata='0;
      total_line_ops=total_line_ops+1;
      if(response_error || (!saved_write && read_payload!==reference_pattern(saved_address,test_seed,trial_expected)))begin
        // The RTL intentionally retains counters only for successful comparisons.
      end else if(saved_write)expected_writes=expected_writes+1;
      else expected_reads=expected_reads+1;
      if(completed_writes!==expected_writes || completed_reads!==expected_reads)
        fail($sformatf("counter mismatch writes=%0d/%0d reads=%0d/%0d",completed_writes,expected_writes,completed_reads,expected_reads));
    end
  endtask

  task automatic retire_fence(input logic [30:0] expected_last_write,
      input logic bad_ok,input logic [31:0] bad_status,input logic [31:0] bad_onoff,
      input logic [31:0] bad_mask,input logic drop_ecc_health);
    integer n;
    begin
      n=0;
      while(retire_valid!==1'b1 && n<80)begin @(negedge clk);n=n+1;end
      if(retire_valid!==1'b1)fail("timed out waiting for retirement fence");
      if(retire_last_write_address!==expected_last_write)
        fail($sformatf("fence last-write address=%h expected=%h",retire_last_write_address,expected_last_write));
      if(line_valid!==1'b0)fail("line traffic overlapped retirement fence");
      retire_ready=0;
      repeat(2)begin
        @(posedge clk);#1;
        if(retire_valid!==1'b1 || retire_last_write_address!==expected_last_write)
          fail("retirement request changed under READY stall");
      end
      @(negedge clk);retire_ready=1;
      @(posedge clk);#1;retire_ready=0;
      if(retire_valid!==1'b0 || retire_rsp_ready!==1'b1)fail("retirement response phase not entered");
      if(line_valid!==1'b0)fail("line traffic overlapped retirement response");
      repeat(2)@(posedge clk);
      @(negedge clk);retire_rsp_valid=1;retire_rsp_ok=bad_ok ? 1'b0 : 1'b1;
      retire_ecc_status=bad_status;retire_ecc_onoff=bad_onoff;retire_ecc_irq_mask=bad_mask;
      if(drop_ecc_health)ecc_monitor_healthy=0;
      if(retire_rsp_ready!==1'b1)fail("retirement response not ready");
      @(posedge clk);#1;
      @(negedge clk);retire_rsp_valid=0;retire_rsp_ok=1;retire_ecc_status=0;
      retire_ecc_onoff=1;retire_ecc_irq_mask=3;
      if(drop_ecc_health)begin
        if(fault!==1'b1 || fault_code!==1 || done!==1'b0)fail("same-edge final health loss did not beat done");
      end else if(bad_ok || bad_status!=0 || bad_onoff!=1 || bad_mask!=3)begin
        if(fault!==1'b1 || fault_code!==3 || done!==1'b0)fail("invalid retirement/ECC witness not rejected");
      end else begin
        if(fault!==1'b0)fail("valid retirement witness faulted");
        fence_count=fence_count+1;
      end
    end
  endtask

  task automatic write_pass(input logic trial_value);
    integer i,line_index;
    logic [30:0] addr,lastwrite;
    begin
      for(i=0;i<LINES;i=i+1)begin
        line_index=trial_value ? (LINES-1-i) : i;addr=BASE+line_index*64;
        transact_line(1'b1,trial_value,addr,(i%3)+1,(i%2)+1,1'b0,1'b0);
      end
      lastwrite=trial_value ? BASE : LAST;
      retire_fence(lastwrite,1'b0,0,1,3,1'b0);
    end
  endtask

  task automatic read_pass(input logic trial_value,input logic final_health_drop);
    integer i;
    logic [30:0] addr,lastwrite;
    begin
      for(i=0;i<LINES;i=i+1)begin
        addr=BASE+i*64;
        transact_line(1'b0,trial_value,addr,(i%2)+1,(i%3)+1,1'b0,1'b0);
      end
      lastwrite=trial_value ? BASE : LAST;
      retire_fence(lastwrite,1'b0,0,1,3,final_health_drop);
    end
  endtask

  task automatic full_sweep(input logic [31:0] seed_value,input logic final_health_drop);
    begin
      begin_sweep(seed_value);
      write_pass(1'b0);read_pass(1'b0,1'b0);
      write_pass(1'b1);read_pass(1'b1,final_health_drop);
      if(!final_health_drop)begin
        if(done!==1'b1 || busy!==1'b0 || fault!==1'b0 || completed_writes!==8 || completed_reads!==8 || fence_count!==4)
          fail("complete sweep result/counters/fence count incorrect");
      end
    end
  endtask

  task automatic expect_fault(input logic [7:0] code_value);
    begin
      repeat(2)@(posedge clk);#1;
      if(fault!==1'b1 || fault_code!==code_value || done!==1'b0 || busy!==1'b0)
        fail($sformatf("fault mismatch got fault=%b code=%0d done=%b busy=%b expected=%0d",fault,fault_code,done,busy,code_value));
    end
  endtask

  task automatic write_trial0_only;
    integer i;
    begin
      for(i=0;i<LINES;i=i+1)transact_line(1'b1,1'b0,i*64,(i%2)+1,1,1'b0,1'b0);
    end
  endtask

  task automatic startup_health_fault(input integer bad_signal);
    begin
      reset_dut();
      case(bad_signal)
        0:initialization_complete=0;
        1:calibration_complete=0;
        2:ecc_monitor_healthy=0;
        3:owner_exclusive=0;
        default:fail("bad startup health test selector");
      endcase
      @(negedge clk);seed=32'h3588c350;start_valid=1;
      @(posedge clk);#1;start_valid=0;
      expect_fault(1);
      if(line_valid!==1'b0 || completed_writes!==0 || completed_reads!==0)fail("startup health fault issued traffic");
    end
  endtask

  task automatic active_health_fault(input integer stage);
    begin
      reset_dut();begin_sweep(32'h3588c350);
      if(stage>=1)write_pass(1'b0);
      if(stage>=2)read_pass(1'b0,1'b0);
      if(stage>=3)write_pass(1'b1);
      wait_line();
      case(stage)
        0:initialization_complete=0; // trial-0 write request
        1:calibration_complete=0;    // trial-0 read request
        2:ecc_monitor_healthy=0;     // trial-1 write request
        3:owner_exclusive=0;         // trial-1 read request
        default:fail("bad active health test selector");
      endcase
      @(posedge clk);#1;expect_fault(1);
      if(line_valid!==1'b1)fail("pending request not retained after health fault");
      drain_pending_line();
    end
  endtask

  task automatic drain_pending_line;
    logic [30:0] a;
    logic [511:0] d;
    begin
      a=line_address;d=line_wdata;
      repeat(2)begin @(posedge clk);#1;if(line_valid!==1 || line_address!==a || line_wdata!==d)fail("faulted request lost stable payload");end
      @(negedge clk);line_ready=1;@(posedge clk);#1;line_ready=0;
      if(line_rsp_ready!==1'b1)fail("faulted accepted request did not permit late response drain");
      repeat(2)@(posedge clk);
      @(negedge clk);line_rsp_valid=1;line_rsp_error=0;line_rdata='0;
      @(posedge clk);#1;@(negedge clk);line_rsp_valid=0;
      if(line_valid!==1'b0 || line_rsp_ready!==1'b1 || fault!==1'b1)fail("late fault response was not drained/quarantined");
      repeat(5)begin @(posedge clk);#1;if(line_valid!==1'b0)fail("new traffic issued while quarantined");end
    end
  endtask

  task automatic drain_pending_response;
    begin
      if(line_valid!==1'b0 || line_rsp_ready!==1'b1)fail("timed-out response state not quarantined");
      repeat(2)@(posedge clk);
      @(negedge clk);line_rsp_valid=1;line_rsp_error=0;line_rdata='0;
      @(posedge clk);#1;@(negedge clk);line_rsp_valid=0;
      if(line_valid!==1'b0 || line_rsp_ready!==1'b1 || fault!==1'b1)fail("late response was not drained/quarantined");
      repeat(5)begin @(posedge clk);#1;if(line_valid!==1'b0)fail("new traffic issued after timeout");end
    end
  endtask

  task automatic mismatch_alias;
    integer i;
    begin
      reset_dut();alias_mode=1;begin_sweep(32'h3588c350);
      for(i=0;i<LINES;i=i+1)transact_line(1'b1,1'b0,i*64,1,1,1'b0,1'b0);
      retire_fence(LAST,1'b0,0,1,3,1'b0);
      transact_line(1'b0,1'b0,0,1,1,1'b0,1'b0);
    end
  endtask

  initial begin : test
    integer i;
    joint_rst_n=0;start_valid=0;seed=0;initialization_complete=1;calibration_complete=1;
    ecc_monitor_healthy=1;owner_exclusive=1;line_ready=0;line_rsp_valid=0;line_rsp_error=0;
    line_rdata='0;retire_ready=0;retire_rsp_valid=0;retire_rsp_ok=1;
    retire_ecc_status=0;retire_ecc_onoff=1;retire_ecc_irq_mask=3;alias_mode=0;

    // Complete exact two-trial write/read sequence with four fresh ECC fences.
    reset_dut();full_sweep(32'h00000000,1'b0);
    $display("PASS_SWEEP_SEED_ZERO writes=%0d reads=%0d",completed_writes,completed_reads);
    reset_dut();full_sweep(32'h3588c350,1'b0);
    $display("PASS_SWEEP_NORMAL writes=%0d reads=%0d fences=%0d",completed_writes,completed_reads,fence_count);

    // A fake address decoder aliases adjacent lines: all writes retire, first read detects it.
    mismatch_alias();
    if(fault!==1 || fault_code!==4 || mismatch_address!==0 ||
       mismatch_expected!==reference_pattern(0,32'h3588c350,1'b0) ||
       mismatch_actual!==mem[0])fail("alias readback mismatch capture incorrect");
    $display("PASS_SWEEP_ALIAS_MISMATCH address=%h",mismatch_address);

    // Modified response bytes capture all expected/actual bits.
    reset_dut();begin_sweep(32'h3588c350);write_trial0_only();retire_fence(LAST,1'b0,0,1,3,1'b0);
    transact_line(1'b0,1'b0,0,1,1,1'b0,1'b1);
    expect_fault(4);
    if(mismatch_address!==0 || mismatch_expected!==reference_pattern(0,32'h3588c350,1'b0) ||
       mismatch_actual!== (mem[0] ^ (512'b1<<9)))fail("modified-byte expected/actual capture incorrect");
    $display("PASS_SWEEP_MODIFIED_READ address=%h",mismatch_address);

    // AXI-like line response error is distinct from data mismatch.
    reset_dut();begin_sweep(32'h3588c350);transact_line(1'b1,1'b0,0,1,1,1'b1,1'b0);expect_fault(5);
    $display("PASS_SWEEP_LINE_ERROR");

    // Unsolicited line response while a request is pending faults and then drains.
    reset_dut();begin_sweep(32'h3588c350);wait_line();
    @(negedge clk);line_rsp_valid=1;line_rdata='0;
    @(posedge clk);#1;line_rsp_valid=0;expect_fault(2);
    if(line_valid!==1'b1)fail("unsolicited-response quarantine lost pending line");
    drain_pending_line();$display("PASS_SWEEP_UNSOLICITED_LINE_RESPONSE");

    // Unsolicited retirement response is a separate fault code.
    reset_dut();begin_sweep(32'h3588c350);wait_line();
    @(negedge clk);retire_rsp_valid=1;
    @(posedge clk);#1;retire_rsp_valid=0;expect_fault(3);
    if(line_valid!==1'b1)fail("premature retirement response did not quarantine line");
    drain_pending_line();$display("PASS_SWEEP_UNSOLICITED_RETIRE_RESPONSE");

    // Each field of the fresh retirement/ECC witness is mandatory.
    for(i=0;i<4;i=i+1)begin
      reset_dut();begin_sweep(32'h3588c350);write_trial0_only();
      case(i)
        0:retire_fence(LAST,1'b1,0,1,3,1'b0);
        1:retire_fence(LAST,1'b0,32'h1,1,3,1'b0);
        2:retire_fence(LAST,1'b0,0,0,3,1'b0);
        3:retire_fence(LAST,1'b0,0,1,1,1'b0);
      endcase
      if(fault!==1 || fault_code!==3)fail("retirement/ECC witness mutation accepted");
    end
    $display("PASS_SWEEP_RETIREMENT_ECC_FIELDS");

    // Startup interlocks and active health drops in each of four ordered phases.
    for(i=0;i<4;i=i+1)startup_health_fault(i);
    for(i=0;i<4;i=i+1)active_health_fault(i);
    $display("PASS_SWEEP_HEALTH_INTERLOCKS");

    // A final health loss on the same response edge as the last fence beats done.
    reset_dut();full_sweep(32'h3588c350,1'b1);expect_fault(1);
    if(done!==1'b0 || completed_writes!==8 || completed_reads!==8 || fence_count!==3)
      fail("same-edge final health failure did not dominate success");
    $display("PASS_SWEEP_FINAL_HEALTH_DOMINATES_DONE");

    // Dropped response reaches bounded timeout, late response drains, and no next traffic issues.
    reset_dut();begin_sweep(32'h3588c350);wait_line();
    @(negedge clk);line_ready=1;@(posedge clk);#1;line_ready=0;
    if(line_rsp_ready!==1'b1)fail("response timeout setup lost response-ready");
    repeat(25)@(posedge clk);#1;expect_fault(6);line_rdata='0;drain_pending_response();
    $display("PASS_SWEEP_DROPPED_RESPONSE_TIMEOUT");

    // Stalled request reaches timeout, remains stable and can be explicitly drained after quarantine.
    reset_dut();begin_sweep(32'h3588c350);wait_line();line_ready=0;
    repeat(25)@(posedge clk);#1;expect_fault(6);drain_pending_line();
    $display("PASS_SWEEP_STALLED_REQUEST_TIMEOUT");

    // Four-state unknown start seed is simulator-only and must fault before any line traffic.
`ifndef VERILATOR
    reset_dut();@(negedge clk);seed=32'hxxxxxxxx;start_valid=1;
    @(posedge clk);#1;start_valid=0;expect_fault(1);
    if(line_valid!==1'b0 || completed_writes!==0 || completed_reads!==0)fail("unknown seed issued traffic");
    $display("PASS_SWEEP_UNKNOWN_SEED_FOUR_STATE");
`else
    $display("PASS_SWEEP_UNKNOWN_SEED_FOUR_STATE=NOT_APPLICABLE_TWO_STATE");
`endif

    // Joint reset clears quarantine and starts a clean second run.
    reset_dut();full_sweep(32'hffffffff,1'b0);
    $display("PASS_SWEEP_JOINT_RESET_NEW_RUN");
    $display("PASS_SWEEP_CONTROLLER behavioral_cases=PASS");$finish;
  end
endmodule
