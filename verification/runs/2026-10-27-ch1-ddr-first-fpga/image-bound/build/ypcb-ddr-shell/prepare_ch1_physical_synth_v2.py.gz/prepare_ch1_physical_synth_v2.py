#!/usr/bin/python3
"""Freeze a fresh CH1 source-synthesis package for root Tcl review; never launches Vivado."""
import datetime,hashlib,json,shutil
from pathlib import Path
ROOT=Path('/home/fedora/rknpu-fpga')
PROFILE=ROOT/'build/ypcb-ddr-shell/ch1-source-v1'
PROFILE_REPORT=PROFILE/'report.json'
ROUTE_HELPERS=ROOT/'build/ypcb-ddr-shell/snapshot-route-v3'
ROUTE_REPORT=ROUTE_HELPERS/'report.json'
OUT=ROOT/'build/ypcb-ddr-shell/ch1-physical-synth-v2'
SELF=Path(__file__).resolve()
RUNNER=ROOT/'build/ypcb-ddr-shell/run_ch1_physical_synth.py'
PART='xc7k480tffg1156-2'
TOP='ypcb_ddr_ew_top'
MIG_XDC_SHA='5ea42669bed59d09cfad5c25a08aec20e0824d48895071ecd2acfbff8261b6fc'
BOARD_XDC_SHA='18f8b2bdd853c991df4395a40ca184b7ee4618f035b19f9e073423f071d11a15'

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def require(ok,msg):
 if not ok:raise ValueError(msg)
def tcl(path):return '[encoding convertfrom utf-8 [binary format H* {'+str(path).encode().hex()+'}]]'

require(not OUT.exists(),'Fresh CH1 synthesis package directory required')
profile=json.loads(PROFILE_REPORT.read_text())
route=json.loads(ROUTE_REPORT.read_text())
require(profile.get('status')=='PREPARED_EXPLICIT_PHYSICAL_CHANNEL_SNAPSHOT_SOURCE_ONLY','Wrong selected-channel source package')
require(profile.get('selected_physical_channel')==1 and profile.get('logical_ui0_physical_channel')==1 and profile.get('logical_ui1_physical_channel')==0,
        'CH1 mapping must retain logical UI0 on physical channel 1 and UI1 on physical channel 0')
require(profile.get('both_mig_controllers_retained') is True and profile.get('endpoint_and_diagnostic_names_are_logical_roles') is True,
        'Selected profile must retain both MIG controllers and logical endpoint/diagnostic names')
require(profile.get('top')==TOP and profile.get('part')==PART,'Wrong top/part in CH1 profile')
require(profile.get('stub_selected_for_real_design') is False and profile.get('logical_contract_schema')==3,
        'Require real schema-3 logical endpoint sources')
require(route.get('status')=='PASS_DDR_ROUTED_CHECKPOINT_ONLY_REQUIRES_CDC_WARNING_ELECTRICAL_AND_PHYSICAL_REVIEW',
        'Expected source-provenanced helper package only; route checkpoint is not an input')

# Verify every original profile input and copied artifact before creating output.
source_inputs=dict(profile['source_inputs'])
for rel,expected in profile['artifacts'].items():
    path=PROFILE/rel
    require(path.is_file() and sha(path)==expected,'Changed source-profile artifact: '+str(path))
    source_inputs[str(path.resolve())]=expected
for source,expected in source_inputs.items():require(Path(source).is_file() and sha(source)==expected,'Changed source input: '+source)
for rel,expected in profile['artifacts'].items():require(sha(PROFILE/rel)==expected,'Changed CH1 profile artifact: '+rel)
real=[Path(p).resolve() for p in profile['real_hdl_sources']]
require(len(real)==len(set(real))==122,'Exactly 122 distinct real HDL inputs required')
require(all(str(p) in source_inputs and sha(p)==source_inputs[str(p)] for p in real),'Unbound or changed real HDL input')
require(sha(PROFILE/'mig-original.xdc')==MIG_XDC_SHA and sha(PROFILE/'board.xdc')==BOARD_XDC_SHA,'Changed electrical XDC source')

# Freeze the exact five review helpers: mailbox from CH1 source profile; four
# unchanged CDC/reset helpers from the reviewed source-only route package.
helper_sources={
 'mailbox_ui':Path(profile['constraint_helpers']['mailbox_ui']),
 'reset_status':ROUTE_HELPERS/'reset_status_cdc.tcl',
 'board_reset':ROUTE_HELPERS/'reset_bridge_board_cdc.tcl',
 'job_crossing':ROUTE_HELPERS/'async_job_cdc.tcl',
 'memory_crossing':ROUTE_HELPERS/'async_mem_cdc.tcl',
}
helper_route_keys={'reset_status':'reset_status_cdc.tcl','board_reset':'reset_bridge_board_cdc.tcl',
                   'job_crossing':'async_job_cdc.tcl','memory_crossing':'async_mem_cdc.tcl'}
for key,path in helper_sources.items():
 require(path.is_file(),f'Missing {key} helper: {path}')
 if key in helper_route_keys:
  require(sha(path)==route['artifacts'][helper_route_keys[key]],f'Changed reviewed helper {path}')

OUT.mkdir(parents=True)
copy_inputs={str(PROFILE_REPORT):sha(PROFILE_REPORT),str(ROUTE_REPORT):sha(ROUTE_REPORT),str(SELF):sha(SELF)}
require(RUNNER.is_file(),'Bounded runner script is missing')
copy_inputs[str(RUNNER)]=sha(RUNNER)
for source,expected in source_inputs.items():copy_inputs[source]=expected
source_map=[]
# Copy all 122 HDL inputs to a numbered, immutable source bundle. The selected
# platform/top wrappers are the exact channel-1 source files from the profile.
for idx,original in enumerate(real):
 dest=OUT/'source'/'hdl'/f'{idx:03d}'/original.name;dest.parent.mkdir(parents=True,exist_ok=True)
 shutil.copyfile(original,dest)
 require(sha(dest)==source_inputs[str(original)],'Source drift during CH1 freeze: '+str(original))
 source_map.append((idx,original,dest,sha(dest)))
 copy_inputs[str(dest)]=sha(dest)
for name in ('mig-original.xdc','board.xdc'):
 original=PROFILE/name;dest=OUT/'source'/name
 shutil.copyfile(original,dest);require(sha(dest)==sha(original),'XDC source drift during freeze')
 copy_inputs[str(dest)]=sha(dest);source_map.append(('XDC',original,dest,sha(dest)))
helper_dir=OUT/'source'/'constraint-helpers';helper_dir.mkdir(parents=True)
helper_destinations={}
for key,original in helper_sources.items():
 dest=helper_dir/(key+'.tcl');shutil.copyfile(original,dest)
 require(sha(dest)==sha(original),f'Helper changed during copy: {key}')
 helper_destinations[key]=str(dest);copy_inputs[str(original)]=sha(original);copy_inputs[str(dest)]=sha(dest)
 source_map.append((f'HELPER:{key}',original,dest,sha(dest)))
shutil.copyfile(PROFILE/'platform.sv',OUT/'source'/'platform.sv')
shutil.copyfile(PROFILE/'top.sv',OUT/'source'/'top.sv')
for n in ('platform.sv','top.sv'):
 p=OUT/'source'/n;source_map.append((f'PROFILE:{n}',PROFILE/n,p,sha(p)))
 copy_inputs[str(p)]=sha(p)
# Keep the source-package producer receipt as a frozen, byte-identical audit input.
shutil.copyfile(PROFILE_REPORT,OUT/'source'/'ch1-source-report.json')
copy_inputs[str(OUT/'source/ch1-source-report.json')]=sha(OUT/'source/ch1-source-report.json')
shutil.copyfile(RUNNER,OUT/'run.py')
require(sha(OUT/'run.py')==sha(RUNNER),'Bounded runner changed during package freeze')
copy_inputs[str(OUT/'run.py')]=sha(OUT/'run.py')

# Record copied-source map in deterministic TSV.
with (OUT/'source-map.tsv').open('w') as f:
 f.write('index\toriginal_path\tfrozen_path\tsha256\n')
 for idx,orig,dest,h in source_map:f.write(f'{idx}\t{orig}\t{dest}\t{h}\n')

# Use the numbered source paths only, preserving the source report's ordering.
hdl_destinations=[dest for idx,orig,dest,h in source_map if isinstance(idx,int)]
require(len(hdl_destinations)==122,'Frozen Verilog file list must contain exactly 122 real HDL sources')

# Build a reviewable source-synthesis-only Tcl. The exact actual clock objects
# for logical UI0/UI1 are resolved from local reset-owner registers and checked
# against the corresponding physical MIG channel output pins before helpers.
lines=[
 'set_param general.maxThreads 2',
 'proc ch1_require {condition message} {if {!$condition} {error $message}}',
 'proc ch1_one {objects label} {ch1_require [expr {[llength $objects]==1}] "Expected exactly one $label"; return [lindex $objects 0]}',
 'proc ch1_finite {value} {return [expr {[string is double -strict $value] && ![catch {expr {abs(double($value))<Inf}} ok] && $ok}]}',
 'proc ch1_emit {f row} {puts $f [join $row "\\t"]; flush $f}',
 'puts "CH1_NATIVE_SYNTH_TOOL [version -short]"',
 'create_project -in_memory -part '+PART,
 'read_verilog -sv [list '+' '.join(map(tcl,hdl_destinations))+']',
 'read_xdc '+tcl(OUT/'source/mig-original.xdc'),
 'read_xdc '+tcl(OUT/'source/board.xdc'),
 'synth_design -top '+TOP+' -part '+PART+' -flatten_hierarchy none',
 'set_property CONFIG_VOLTAGE 1.8 [current_design]',
 'set_property CFGBVS GND [current_design]',
 'ch1_require [expr {[get_property TOP [current_design]] eq "'+TOP+'" && [get_property PART [current_design]] eq "'+PART+'"}] "Wrong synthesized top or part"',
 'ch1_require [expr {[get_property CONFIG_VOLTAGE [current_design]] == 1.8 && [get_property CFGBVS [current_design]] eq "GND"}] "Changed configuration 1.8/GND settings"',
 'ch1_require [expr {[llength [get_cells -quiet -hier -filter {IS_BLACKBOX == 1}]]==0}] "Unresolved source black box"',
 'source '+tcl(helper_destinations['reset_status']),
 'source '+tcl(helper_destinations['board_reset']),
 'source '+tcl(helper_destinations['job_crossing']),
 'source '+tcl(helper_destinations['memory_crossing']),
 'source '+tcl(helper_destinations['mailbox_ui']),
 'set endpoint platform/endpoint',
 'set sys_clock [rk_status_clock sys_clock 20.000]',
 'set ui0_local [rk_status_cell [format {%s/reset_owner/ui_domain[%d].local_rst_n_reg} $endpoint 0]]',
 'set ui1_local [rk_status_cell [format {%s/reset_owner/ui_domain[%d].local_rst_n_reg} $endpoint 1]]',
 'set ui0_reg_clock [ch1_one [get_clocks -quiet -of_objects [get_pins $ui0_local/C]] {logical UI0 reset-owner register clock}]',
 'set ui1_reg_clock [ch1_one [get_clocks -quiet -of_objects [get_pins $ui1_local/C]] {logical UI1 reset-owner register clock}]',
 'set physical_c1_ui_clock [ch1_one [get_clocks -quiet -of_objects [get_pins -quiet [list platform/mig/c1_ui_clk]]] {physical MIG c1 UI clock}]',
 'set physical_c0_ui_clock [ch1_one [get_clocks -quiet -of_objects [get_pins -quiet [list platform/mig/c0_ui_clk]]] {physical MIG c0 UI clock}]',
 'ch1_require [expr {$ui0_reg_clock eq $physical_c1_ui_clock}] "Logical UI0 is not sourced from physical MIG C1 UI clock"',
 'ch1_require [expr {$ui1_reg_clock eq $physical_c0_ui_clock}] "Logical UI1 is not sourced from physical MIG C0 UI clock"',
 'set ui0_clock [rk_status_clock [get_property NAME $ui0_reg_clock] 7.500]',
 'set ui1_clock [rk_status_clock [get_property NAME $ui1_reg_clock] 7.500]',
 'puts "CH1_CLOCK_BINDING SYS=[get_property NAME $sys_clock] UI0=[get_property NAME $ui0_clock] UI0_PIN=platform/mig/c1_ui_clk UI1=[get_property NAME $ui1_clock] UI1_PIN=platform/mig/c0_ui_clk"',
 'set f [open ch1_synthesis_facts.tsv w]',
 'ch1_emit $f [list DESIGN [get_property NAME [current_design]] TOP [get_property TOP [current_design]] PART [get_property PART [current_design]] CONFIG_VOLTAGE [get_property CONFIG_VOLTAGE [current_design]] CFGBVS [get_property CFGBVS [current_design]]]',
 'ch1_emit $f [list SYS_CLOCK [get_property NAME $sys_clock] [get_property PERIOD $sys_clock]]',
 'ch1_emit $f [list LOGICAL_UI0_CLOCK [get_property NAME $ui0_clock] [get_property PERIOD $ui0_clock] EXPECTED_PHYSICAL_PIN platform/mig/c1_ui_clk]',
 'ch1_emit $f [list LOGICAL_UI1_CLOCK [get_property NAME $ui1_clock] [get_property PERIOD $ui1_clock] EXPECTED_PHYSICAL_PIN platform/mig/c0_ui_clk]',
 'rk_ddr_host_cdc_constrain $ui0_clock',
 'rk_status_cdc_constrain $endpoint $sys_clock $ui0_clock $ui1_clock',
 'rk_job_cdc_constrain $endpoint/engine/job_crossing $ui0_clock $sys_clock ew_engine_e1_e8',
 'rk_mem_cdc_constrain $endpoint/engine/memory_crossing $sys_clock $ui0_clock',
 'rk_board_reset_constrain $endpoint startup platform_i_1 $sys_clock $ui0_clock $ui1_clock',
 'set pre_proof [rk_job_zero_error_codes $endpoint/engine/job_crossing/ ew_engine_e1_e8]',
 'ch1_require [expr {[llength $pre_proof]==4}] "Pre-opt strict high-error-bit proof must return four rows"',
 'set anchored_by_name [dict create]; set row_index 0; set observation_count 0',
 'foreach row $pre_proof {',
 '  lassign $row kind bit input from_net output to_net',
 '  ch1_require [expr {$kind eq "ZERO_CODE"}] "Unexpected pre-opt strict proof row"',
 '  foreach index {3 5} {',
 '    set net [lindex $row $index]; set name [get_property NAME $net]',
 '    ch1_require [expr {[get_property TYPE $net] eq "GROUND" && [get_property DRIVER_COUNT $net]==1}] "Pre-opt proof observation is not single-driver GROUND"',
 '    ch1_emit $f [list PREOPT_NET $row_index $bit $index $name [get_property TYPE $net] [get_property DRIVER_COUNT $net]]',
 '    dict set anchored_by_name $name $net; incr observation_count',
 '  }; incr row_index',
 '}',
 'ch1_require [expr {$row_index==4 && $observation_count==8 && [dict size $anchored_by_name]>0}] "Incomplete pre-opt eight-net observation"',
 'set anchor_names [lsort [dict keys $anchored_by_name]]',
 'foreach name $anchor_names {set net [dict get $anchored_by_name $name]; set_property KEEP TRUE $net; set_property DONT_TOUCH TRUE $net; ch1_emit $f [list ANCHOR_SET $name [get_property TYPE $net] [get_property DRIVER_COUNT $net] [get_property KEEP $net] [get_property DONT_TOUCH $net]]}',
 'opt_design',
 'set post_proof [rk_job_zero_error_codes $endpoint/engine/job_crossing/ ew_engine_e1_e8]',
 'ch1_require [expr {[llength $post_proof]==4}] "Post-opt strict high-error-bit proof must return four rows"',
 'set post_names [dict create]; set row_index 0; set observation_count 0',
 'foreach row $post_proof {',
 '  lassign $row kind bit input from_net output to_net',
 '  ch1_require [expr {$kind eq "ZERO_CODE"}] "Unexpected post-opt strict proof row"',
 '  foreach index {3 5} {',
 '    set net [lindex $row $index]; set name [get_property NAME $net]',
 '    ch1_require [expr {[get_property TYPE $net] eq "GROUND" && [get_property DRIVER_COUNT $net]==1}] "Post-opt proof observation is not single-driver GROUND"',
 '    dict set post_names $name $net; incr observation_count',
 '    ch1_emit $f [list POSTOPT_NET $row_index $bit $index $name [get_property TYPE $net] [get_property DRIVER_COUNT $net] [get_property KEEP $net] [get_property DONT_TOUCH $net]]',
 '    ch1_require [expr {[get_property KEEP $net] && [get_property DONT_TOUCH $net]}] "Lost retained constant anchor after opt_design"',
 '  }; incr row_index',
 '}',
 'ch1_require [expr {$row_index==4 && $observation_count==8 && [lsort [dict keys $post_names]] eq $anchor_names}] "Post-opt proof/anchor set differs"',
 'ch1_emit $f [list CONSTANT_ANCHOR_SET unique_count [llength $anchor_names] names [join $anchor_names {,}]]',
 'write_checkpoint post_opt_anchored.dcp',
 'write_verilog -mode funcsim post_opt_anchored.funcsim.v',
 'report_utilization -hierarchical -file utilization.rpt',
 'report_io -file io.rpt',
 'report_clocks -file clocks.rpt',
 'report_cdc -details -file cdc.rpt',
 'report_timing_summary -delay_type min_max -report_unconstrained -file unplaced_timing.rpt',
 'report_drc -file synthesis_drc.rpt',
 'puts PASS_CH1_REAL_SOURCE_SYNTHESIS_AND_OPT_ONLY_REQUIRES_ROUTE_REVIEW',
 'close $f',
 'exit'
]
(OUT/'synth.tcl').write_text('\n'.join(lines)+'\n')

# Hash all preserved payloads and Tcl; keep explicit no-launch boundary in
# preparation.json for the supervising root Tcl review.
artifacts={str(p.relative_to(OUT)):sha(p) for p in OUT.rglob('*') if p.is_file()}
manifest={'schema':'ch1-fresh-synthesis-preparation-v1','status':'READY_CH1_FRESH_SOURCE_SYNTHESIS_AND_OPT_ONLY_ROOT_TCL_REVIEW_REQUIRED',
 'source_profile':str(PROFILE_REPORT),'source_profile_sha256':sha(PROFILE_REPORT),'route_helper_package':str(ROUTE_REPORT),'route_helper_report_sha256':sha(ROUTE_REPORT),
 'selected_physical_channel':1,'logical_ui0_physical_channel':1,'logical_ui1_physical_channel':0,
 'top':TOP,'part':PART,'real_hdl_count':122,'real_hdl_sources':[str(p) for p in real],
 'source_inputs':copy_inputs,'source_map_path':str(OUT/'source-map.tsv'),'source_map_sha256':sha(OUT/'source-map.tsv'),
 'constraint_sources':[str(OUT/'source/mig-original.xdc'),str(OUT/'source/board.xdc')],
 'constraint_source_hashes':{'mig-original.xdc':sha(OUT/'source/mig-original.xdc'),'board.xdc':sha(OUT/'source/board.xdc')},
 'constraint_helpers':{k:{'source':str(helper_sources[k]),'source_sha256':sha(helper_sources[k]),'frozen_copy':v,'frozen_sha256':sha(v)} for k,v in helper_destinations.items()},
 'helper_count':5,'constant_anchor_policy':'Pre-opt helper proof: four ZERO_CODE rows; collect row indices 3/5 per row; require actual single-driver GROUND; deduplicate by NAME; set KEEP and DONT_TOUCH; post-opt repeat strict four-row/eight-observation proof and require unchanged anchor set.',
 'clock_policy':'SYS sys_clock 20.000 ns. Logical UI0 derived from endpoint reset-owner domain0 local_rst_n_reg/C and must equal actual clock on platform/mig/c1_ui_clk. Logical UI1 from domain1 register C and must equal platform/mig/c0_ui_clk. Both UI periods must be 7.500 ns; actual clock object names are printed into Tcl output.',
 'synthesis_policy':'Fresh read of all 122 HDL sources and unchanged MIG/board XDC; synth_design top ypcb_ddr_ew_top / xc7k480tffg1156-2, flatten none; apply five original helpers; anchor high error constant observations before opt_design; run synth_design plus opt_design only; no placement/route/bitstream/hardware; unplaced timing/DRC are reports, not strict hold acceptance.',
 'planned_resource_limits':{'memory_max_bytes':8589934592,'memory_swap_max_bytes':0,'cpu_quota_percent':200,'tasks_max':256,'timeout_seconds':1200,'host_min_mem_available_bytes':12884901888,'host_cpu_psi_some_avg10_max':5.0,'host_memory_psi_full_avg10_max':1.0},
 'synth_tcl_path':str(OUT/'synth.tcl'),'synth_tcl_sha256':sha(OUT/'synth.tcl'),
 'native_tool_launched':False,'vivado_executed':False,'synthesis_executed':False,'optimization_executed':False,
 'implementation_executed':False,'placement_executed':False,'routing_executed':False,'bitstream_emitted':False,'hardware_accessed':False,
 'run_entrypoint':str(OUT/'run.py'),'run_entrypoint_sha256':sha(OUT/'run.py'),
 'root_tcl_review_required_before_launch':True,'artifacts':artifacts,
 'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(OUT/'preparation.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print(manifest['status'],'hdl=122','helpers=5','tcl_sha256='+manifest['synth_tcl_sha256'],'vivado_not_launched')
