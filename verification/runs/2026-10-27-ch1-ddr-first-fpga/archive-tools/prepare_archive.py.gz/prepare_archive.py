#!/usr/bin/python3
"""Build a deterministic, selected-evidence archive of the first CH1 DDR trial."""
from __future__ import annotations
import ast,datetime,gzip,hashlib,io,json,pathlib,re,sys,traceback
ROOT=pathlib.Path('/home/fedora/rknpu-fpga')
TRIAL=ROOT/'build/fpga-bringup/ddr-ch1-first-v1'
IMAGE_REVIEW=TRIAL/'image-review.json'
WIRE_AUDIT=TRIAL/'independent-wire-audit-v2.json'
WIRE_AUDIT_V1=TRIAL/'independent-wire-audit-v1.json'
PHYS_REPORT=TRIAL/'physical-test/report.json'
PREP=ROOT/'build/ypcb-ddr-shell/ch1-physical-synth-v2/preparation.json'
BIT_REVIEW=ROOT/'build/ypcb-ddr-shell/ch1-image-bitfile-review-v1/root-review-facts.json'
CHECKER=pathlib.Path('/home/fedora/ypcb/local-overrides/projects-bonetto-soc/files/scripts/fedora-check-vivado-bitstream.py')
CONTROLS=[ROOT/'build/ddr-physical-preflight-controls-v1',ROOT/'build/ddr-physical-audit-controls-v1',ROOT/'build/ddr-physical-audit-controls-v2']
TEST_DIRS=[ROOT/'tests/ddr/physical_audit',ROOT/'tests/ddr/transport',ROOT/'tests/ddr/raw_test',ROOT/'tests/ddr/image',ROOT/'tests/ddr/channel_profile']
AUDITOR=ROOT/'tools/ddr/audit_physical.py'
DEST=ROOT/'verification/runs/2026-10-27-ch1-ddr-first-fpga'
BUILD=ROOT/'build/ch1-ddr-first-archive-v1'
PLAN=BUILD/'plan.json'
PACKER=pathlib.Path(__file__).resolve()
BIT_SHA='45bd540cfaf7327ad8db5ba4e3a7548a209db1aeba4423f37159a72287296339'
SOURCE_SHA='a2dfec2162c2df789e3510bd547429592341d8bebd59c835eb4cec1f5af451b7'
EXTERNAL_WRAPPERS={
 '/home/fedora/vivado/2026.1.1/Vivado_Lab/bin/vivado_lab':'2bfd474655a1e968e76f241664d295eed79fef99176954b95ff22ba8b1cbaba8',
 '/home/fedora/vivado/2026.1.1/Vivado_Lab/bin/hw_server':'69230a9e67cf54a8d2e35a3c5d60cda55bd96cb082d264c1f1ded34718db2687',
}

class ArchiveError(RuntimeError):pass
def need(ok,msg):
 if not ok:raise ArchiveError(msg)
def sha(path):
 h=hashlib.sha256()
 with pathlib.Path(path).open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def relroot(path):
 p=pathlib.Path(path).resolve()
 try:return p.relative_to(ROOT).as_posix()
 except ValueError:return str(p)
def json_file(path):
 try:return json.loads(pathlib.Path(path).read_text())
 except Exception as e:raise ArchiveError(f'cannot parse {path}: {e}')
def text_file(path):
 # Generated Xilinx HDL contains Windows-1252 copyright punctuation, so accept
 # non-UTF-8 high bytes while rejecting NUL and opaque control-byte streams.
 try:
  allowed={9,10,12,13}
  with pathlib.Path(path).open('rb') as f:
   for block in iter(lambda:f.read(1024*1024),b''):
    if b'\0' in block:return False
    if any((x<32 and x not in allowed) for x in block):return False
  return True
 except OSError:return False
def add_source(table,path,role,expected=None,archive_hint=None):
 path=pathlib.Path(path).resolve();need(path.is_file(),f'missing archive source: {path}')
 actual=sha(path)
 if expected is not None:need(actual==expected,f'source hash mismatch: {path} expected {expected}, got {actual}')
 need(text_file(path),f'refusing to archive non-text file as evidence/source: {path}')
 key=str(path)
 archive=archive_hint or ('external/'+path.as_posix().lstrip('/') if not path.is_relative_to(ROOT) else 'workspace/'+path.relative_to(ROOT).as_posix())
 if key in table:
  entry=table[key];need(entry['source_sha256']==actual,f'duplicate path changed during source selection: {path}')
  if role not in entry['roles']:entry['roles'].append(role)
  return
 table[key]={'source_path':relroot(path),'archive_path':archive,'source_sha256':actual,'source_bytes':path.stat().st_size,'roles':[role]}
def sha_after(entries):
 result={}
 for source,e in entries.items():
  p=pathlib.Path(source);need(p.is_file(),f'source disappeared before archive copy: {p}')
  actual=sha(p);need(actual==e['source_sha256'],f'source drift before copy: {p}')
  result[source]=actual
 return result

def tool_module_path(name):
 if not name.startswith('tools.'):return None
 parts=name.split('.')[1:]
 candidate=ROOT/'tools'/pathlib.Path(*parts)
 file=candidate.with_suffix('.py')
 package=candidate/'__init__.py'
 if file.is_file():return file
 if package.is_file():return package
 return None

def import_closure(initial):
 seen={};todo=list(initial)
 while todo:
  p=pathlib.Path(todo.pop()).resolve()
  if str(p) in seen:continue
  need(p.is_file(),f'missing requested Python source: {p}')
  seen[str(p)]=p
  try:tree=ast.parse(p.read_text())
  except SyntaxError:continue
  for node in ast.walk(tree):
   if isinstance(node,ast.Import):
    modules=[a.name for a in node.names]
   elif isinstance(node,ast.ImportFrom):
    base=node.module or ''
    modules=[base] if base else []
    if base.startswith('tools.'):
     basepath=ROOT/pathlib.Path(*base.split('.'))
     for alias in node.names:
      sub=basepath.parent/(alias.name+'.py')
      if sub.is_file():modules.append(base+'.'+alias.name)
   else:continue
   for mod in modules:
    q=tool_module_path(mod)
    if q is not None and str(q.resolve()) not in seen:todo.append(q)
 return [seen[k] for k in sorted(seen)]

need(not DEST.exists(),'archive destination must be fresh')
image=json_file(IMAGE_REVIEW);wire=json_file(WIRE_AUDIT);wire_v1=json_file(WIRE_AUDIT_V1);physical=json_file(PHYS_REPORT);prep=json_file(PREP);bit_review=json_file(BIT_REVIEW)
need(image.get('status')=='REVIEWED_EXPERIMENTAL_CH1_EW_DDR_IMAGE_FOR_VOLATILE_TRIAL','image review status changed')
need(len(image.get('bound_files',{}))==511,'expected exact 511 image-review-bound files')
need(image.get('source_sha256')==SOURCE_SHA and image.get('usr_access')=='a2dfec21','CH1 source tag/hash mismatch')
need(image.get('bitstream',{}).get('sha256')==BIT_SHA,'image-review bit SHA mismatch')
need(image.get('software_crc_validation')=='NOT_PERFORMED','source review CRC scope changed')
need(image.get('flash_authorized') is False and image.get('physical_ddr_qualified') is False and image.get('electrical_signoff') is False,'image review scope broadened')
need(wire.get('status')=='PASS_INDEPENDENT_PHYSICAL_CH1_SCRATCH_AND_RAW_SUB9_AUDIT','independent wire audit status changed')
need(wire_v1.get('status')=='FAIL_INDEPENDENT_CH1_PHYSICAL_AUDIT','historical failed v1 audit status not preserved')
need(physical.get('status')=='PASS_PHYSICAL_CH1_SCRATCH_AND_RAW_EW_REQUIRES_INDEPENDENT_WIRE_AUDIT','physical producer report status changed')
need(prep.get('selected_physical_channel')==1,'wrong physical CH1 source preparation')
need(bit_review.get('status')=='PASS_READONLY_BITFILE_STRUCTURE_REVIEW_ONLY' and bit_review.get('bit_sha256')==BIT_SHA,'independent bitfile review changed')
need(physical.get('hardware_programmed') is True and physical.get('flash_written') is False and len([x for x in physical.get('artifacts',{}) if x.startswith('load-') and x.endswith('/command.json')])==1,'physical trial is not exactly one volatile load')
need(wire.get('scratch_bytes')==768 and wire.get('complete_bo_bytes')==102400 and wire.get('tasks')==2,'physical wire facts changed')
need(wire.get('complete_readback_before_ack') is True and wire.get('submits')==1 and wire.get('acknowledgments')==1,'raw SUB9 transaction contract changed')
need(wire.get('software_crc_validation')=='NOT_PERFORMED' and wire.get('full_capacity_qualified') is False and wire.get('ecc_injection_qualified') is False and wire.get('full512_integrated') is False and wire.get('pcie_tested') is False and wire.get('rk_silicon_equivalence') is False and wire.get('electrical_signoff') is False,'physical qualification limits changed')

# Verify all 511 image-review inputs, including the exact excluded binary/tool
# paths, before choosing any archive file.
bound={str(pathlib.Path(k).resolve()):v for k,v in image['bound_files'].items()}
need(len(bound)==511,'image review paths are not unique after normalization')
bound_before={}
for path,expected in bound.items():
 p=pathlib.Path(path);need(p.is_file(),f'image-bound file missing: {p}');actual=sha(p)
 need(actual==expected,f'image-bound hash drift: {p}: {actual} != {expected}')
 bound_before[path]=actual
excluded_bound=[];included_bound=[]
for path,expected in sorted(bound.items()):
 p=pathlib.Path(path);reason=None
 if p.suffix.lower() in {'.dcp','.bit'}:reason='compiled checkpoint/bitfile excluded by archive scope'
 elif path in EXTERNAL_WRAPPERS:
  need(expected==EXTERNAL_WRAPPERS[path],f'external Vivado_Lab wrapper hash differs from pinned expected: {path}')
  reason='external Vivado_Lab wrapper binary excluded'
 if reason:excluded_bound.append({'source_path':relroot(p),'bytes':p.stat().st_size,'sha256':expected,'reason':reason})
 else:
  need(text_file(p),f'non-text unapproved bound artifact: {path}')
  included_bound.append(path)
need(len(excluded_bound)==6 and len(included_bound)==505,'bound-file exclusion count changed')
need({x['source_path'] for x in excluded_bound if x['reason']=='external Vivado_Lab wrapper binary excluded'}==set(EXTERNAL_WRAPPERS),'expected the two exact Vivado_Lab wrappers')

# Explicitly verify every used HDL/XDC from the fresh CH1 package is in the
# 511-file image-review map, rather than sourcing mutable public RTL.
used_hdl=[str(pathlib.Path(p).resolve()) for p in prep['real_hdl_sources']]
need(len(used_hdl)==122 and all(p in bound for p in used_hdl),'not all 122 actual-used HDL files are image-review bound')
for p in used_hdl:need(sha(pathlib.Path(p))==bound[p],f'actual-used HDL hash mismatch: {p}')
for rel in ('source/mig-original.xdc','source/board.xdc'):
 p=str((ROOT/'build/ypcb-ddr-shell/ch1-physical-synth-v2'/rel).resolve())
 need(p in bound,f'actual CH1 XDC not in image-review manifest: {p}')

# Source-group closure requested for portable replay controls.
required_paths=[TRIAL,CONTROLS[0],CONTROLS[1],CONTROLS[2]]
for p in required_paths:need(p.is_dir(),f'required evidence directory missing: {p}')
for p in TEST_DIRS:need(p.is_dir(),f'required test source directory missing: {p}')
need(AUDITOR.is_file(),'physical audit source missing')
checker_hash=sha(CHECKER);need(bound.get(str(CHECKER.resolve()))==checker_hash,'external bitstream checker is not bound exactly')

selected={}
for path in included_bound:add_source(selected,pathlib.Path(path),'image-review bound source/input',bound[path],
    ('external/'+pathlib.Path(path).as_posix().lstrip('/')) if not pathlib.Path(path).is_relative_to(ROOT) else 'image-bound/'+pathlib.Path(path).relative_to(ROOT).as_posix())
# Preserve the project’s own first-trial evidence directory recursively.
skipped_pycache=[];excluded_extra=[]
def walk_text_tree(base: pathlib.Path,archive_prefix: str,role: str):
 for p in sorted(base.rglob('*')):
  if not p.is_file():continue
  if '__pycache__' in p.parts or p.suffix=='.pyc':
   skipped_pycache.append(relroot(p));continue
  if p.resolve() in [pathlib.Path(x).resolve() for x in EXTERNAL_WRAPPERS]:
   excluded_extra.append({'source_path':relroot(p),'bytes':p.stat().st_size,'sha256':sha(p),'reason':'external Vivado_Lab wrapper excluded'});continue
  if p.suffix.lower() in {'.dcp','.bit'} and p.resolve() in {pathlib.Path(x).resolve() for x in bound}:
   continue
  if not text_file(p):
   excluded_extra.append({'source_path':relroot(p),'bytes':p.stat().st_size,'sha256':sha(p),'reason':'non-text compiled/binary artifact excluded'});continue
  arc=archive_prefix+'/'+p.relative_to(base).as_posix()
  add_source(selected,p,role,None,arc)
walk_text_tree(TRIAL,'trial','first CH1 physical trial receipt/trace/control/source text')
for d in CONTROLS:
 walk_text_tree(d,'controls/'+d.name,'offline physical-preflight/audit control receipt/source')
# Add specified Python sources plus their recursively imported local tools.*
# dependencies, preserving ordinary source only.
initial=[AUDITOR]
initial.extend([ROOT/'tools/ddr/interface.py',ROOT/'tools/tinystories/audit_scans.py'])
for d in TEST_DIRS:initial.extend([p for p in d.rglob('*.py') if p.is_file() and '__pycache__' not in p.parts])
source_closure=import_closure(initial)
for p in source_closure:
 rel=p.relative_to(ROOT).as_posix()
 add_source(selected,p,'physical audit/test source closure','' if False else None,'review-source/'+rel)
# Preserve licenses and third-party attribution used by exact-source handoff.
for p in (ROOT/'LICENSE',ROOT/'tests/vendor/xilinx-unisim/LICENSE'):
 if p.is_file():add_source(selected,p,'project/vendor license context',None,'review-source/'+p.relative_to(ROOT).as_posix())
# Explicitly include the external checker (already image-bound) under mandated path.
add_source(selected,CHECKER,'external Fedora YPCB bitstream checker source',checker_hash,
           'external/home/fedora/ypcb/local-overrides/projects-bonetto-soc/files/scripts/fedora-check-vivado-bitstream.py')

# Verify parent reports/artifacts referenced by trial reviews before copying.
for report_path,expected in ((IMAGE_REVIEW,sha(IMAGE_REVIEW)),(WIRE_AUDIT,sha(WIRE_AUDIT)),(PHYS_REPORT,sha(PHYS_REPORT))):
 need(report_path.is_file() and sha(report_path)==expected,'trial report changed during selection')
physical_artifacts=physical.get('artifacts',{})
for rel,expected in physical_artifacts.items():
 p=PHYS_REPORT.parent/rel;need(p.is_file() and sha(p)==expected,f'physical report artifact drift: {rel}')
# C1 DRC and source facts remain part of the selected bound manifest.

# Snapshot every added source before archive directory creation.
source_before=sha_after(selected)
# Verify generated summary facts against raw producer/auditor receipts.
raw_observed=TRIAL/'physical-test/raw-jobs/actual-bo.txt'
scan=wire['raw_scan_stats']
need(raw_observed.is_file() and raw_observed.stat().st_size==220800,'raw scan BO observation file size changed')
need(scan.get('scans')==24238 and scan.get('commands')==8078,'physical raw scan counts changed')
raw_job=next(x for x in physical['tests'] if x.get('status')=='PASS_RAW_CASE_READBACK_AND_ACK')
need(raw_job.get('tag')==1145328129 and raw_job.get('tasks')==2 and raw_job.get('checked_bo_bytes')==102400,'raw SUB9 producer facts changed')

def parse_native_drc(suffix):
 candidates=[pathlib.Path(path) for path in bound if pathlib.Path(path).name==suffix]
 need(len(candidates)==1,f'expected exactly one image-bound {suffix}')
 path=candidates[0];text=path.read_text(errors='replace');m=re.search(r'Checks found:\s*(\d+)',text)
 need(m is not None,f'missing DRC count in {suffix}')
 rules=[]
 for line in text.splitlines():
  if not line.startswith('|'):continue
  cols=[x.strip() for x in line.strip().strip('|').split('|')]
  if len(cols)>=4 and re.fullmatch(r'[A-Z0-9-]+(?:#[0-9]+)?',cols[0]) and cols[1] in {'Warning','Critical Warning','Error','Advisory','Info'}:
   try:count=int(cols[-1])
   except ValueError:continue
   rules.append({'rule':cols[0],'severity':cols[1],'description':cols[2],'checks':count})
 return {'path':relroot(path),'sha256':sha(path),'checks_found':int(m.group(1)),'rules':rules,
         'errors':sum(x['checks'] for x in rules if x['severity']=='Error'),
         'critical_warnings':sum(x['checks'] for x in rules if x['severity']=='Critical Warning'),
         'warnings':sum(x['checks'] for x in rules if x['severity']=='Warning')}
default_drc=parse_native_drc('default_drc.rpt');bit_drc=parse_native_drc('bitstream_drc.rpt')
need(default_drc['checks_found']==6 and bit_drc['checks_found']==6,'native DRC reports are not the reviewed six-warning inventories')
need(default_drc['errors']==0 and bit_drc['errors']==0,'native DRC contains errors')
logpaths=[pathlib.Path(path) for path in bound if pathlib.Path(path).name in {'stdout.log','vivado.log'} and 'ch1-image-v2' in path]
critical_warning_events=[{'path':relroot(path),'line':line} for path in logpaths for line in path.read_text(errors='replace').splitlines() if re.match(r'^\s*CRITICAL WARNING\s*:',line,re.I)]

# Build a reviewable plan before writing the archive.
excluded={'bound_files':excluded_bound,'additional_files':excluded_extra,'skipped_pycache':skipped_pycache}
source_selection=[{'source_path':x['source_path'],'archive_path':x['archive_path'],'source_sha256':x['source_sha256'],'source_bytes':x['source_bytes'],'roles':x['roles']} for x in sorted(selected.values(),key=lambda x:x['archive_path'])]
plan={'schema':'ch1-first-fpga-archive-plan-v1','status':'READY','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'image_review_path':relroot(IMAGE_REVIEW),'image_review_sha256':sha(IMAGE_REVIEW),'image_review_bound_count':len(bound),
 'image_review_bound_included':len(included_bound),'image_review_bound_excluded':excluded_bound,
 'actual_used_hdl_count':len(used_hdl),'actual_used_hdl_paths':used_hdl,
 'xdc_paths':[str((ROOT/'build/ypcb-ddr-shell/ch1-physical-synth-v2/source'/n).resolve()) for n in ('mig-original.xdc','board.xdc')],
 'selected_file_count':len(source_selection),'source_selection':source_selection,'excluded':excluded,
 'portable_scope':'First volatile CH1 physical DDR scratch + single raw SUB9 case with independent GPIO-wire audit. Textual evidence only; native image/checkpoints omitted.',
 'source_sha256':SOURCE_SHA,'bitstream_sha256':BIT_SHA,'no_hardware_replay_or_image_mutation':True}
PLAN.write_text(json.dumps(plan,indent=2,sort_keys=True)+'\n')
plan_sha=sha(PLAN)

# The source plan and packer are included as archive tooling/provenance.
add_source(selected,PLAN,'reproducible archive selection plan',plan_sha,'archive-tools/plan.json')
add_source(selected,PACKER,'reproducible archive builder source',None,'archive-tools/prepare_archive.py')
source_before=sha_after(selected)

# Generate a concise scope note; it explicitly avoids overclaiming.
readme=(
"First CH1 DDR volatile physical trial evidence archive.\n"
"Source tag: a2dfec21 (SHA256 a2dfec2162c2df789e3510bd547429592341d8bebd59c835eb4cec1f5af451b7).\n"
"Image SHA256: 45bd540cfaf7327ad8db5ba4e3a7548a209db1aeba4423f37159a72287296339. One volatile SRAM load, flash not written.\n"
"Observed: six 64-byte scratch addresses in two orders (768 bytes total), followed by one raw SUB9 job with 2 tasks and 102400-byte complete BO readback before ACK. The preserved native scan trace records 24238 scans / 8078 commands.\n"
"Scope limits: this does not qualify full-capacity DDR, ECC fault injection, full512 DDR, PCIe, RK silicon equivalence, or electrical signoff. Software CRC validation was NOT_PERFORMED. The archive is evidence preservation, not permission to program hardware.\n"
).encode()

DEST.mkdir(parents=True)
(DEST/'README.txt').write_bytes(readme)
file_index={'README.txt':{'source_path':'generated from trial receipts','archive_path':'README.txt','role':'scope and limitations',
 'source_bytes':len(readme),'source_sha256':hashlib.sha256(readme).hexdigest(),'archive_bytes':len(readme),
 'archive_sha256':hashlib.sha256(readme).hexdigest(),'compression':'none'}}
# Include the already-written plan itself in the archive index.
plan_bytes=PLAN.read_bytes()
if len(plan_bytes)>16384:
 archive_plan=DEST/'archive-tools/plan.json.gz';archive_plan.parent.mkdir(parents=True,exist_ok=True)
 with archive_plan.open('wb') as out:
  with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0,compresslevel=9) as gz:gz.write(plan_bytes)
 plan_archive='archive-tools/plan.json.gz';plan_compression='gzip_mtime0_level9'
else:
 archive_plan=DEST/'archive-tools/plan.json';archive_plan.parent.mkdir(parents=True,exist_ok=True);archive_plan.write_bytes(plan_bytes)
 plan_archive='archive-tools/plan.json';plan_compression='none'
file_index['archive-tools/plan.json']={'source_path':relroot(PLAN),'archive_path':plan_archive,'role':'reproducible package plan',
 'source_bytes':len(plan_bytes),'source_sha256':sha(PLAN),'archive_bytes':archive_plan.stat().st_size,'archive_sha256':sha(archive_plan),'compression':plan_compression}
# Copy each selected source. Large text is stored with deterministic gzip.
for srcstr,item in sorted(selected.items(),key=lambda kv:kv[1]['archive_path']):
 src=pathlib.Path(srcstr);need(sha(src)==item['source_sha256'],f'source changed before copy: {src}')
 rel=item['archive_path'];raw=src.read_bytes()
 if len(raw)>16384:
  archive_rel=rel+'.gz';dst=DEST/archive_rel;dst.parent.mkdir(parents=True,exist_ok=True)
  with dst.open('wb') as out:
   with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0,compresslevel=9) as gz:gz.write(raw)
  compression='gzip_mtime0_level9'
 else:
  archive_rel=rel;dst=DEST/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw);compression='none'
 stored=sha(dst)
 decoded=gzip.decompress(dst.read_bytes()) if compression.startswith('gzip') else dst.read_bytes()
 need(len(decoded)==len(raw) and hashlib.sha256(decoded).hexdigest()==item['source_sha256'],f'archive copy/decompress mismatch: {rel}')
 need(sha(src)==item['source_sha256'],f'source drift during archive copy: {src}')
 file_index[rel]={'source_path':item['source_path'],'archive_path':archive_rel,'roles':item['roles'],
  'source_bytes':len(raw),'source_sha256':item['source_sha256'],'archive_bytes':dst.stat().st_size,'archive_sha256':stored,'compression':compression}
# Rehash every 511-bound item, all other selected inputs, and all physical report artifacts after copy.
bound_after={p:sha(pathlib.Path(p)) for p in bound}
need(bound_after==bound_before,'one or more image-review-bound files drifted during archive copy')
source_after=sha_after(selected)
need(source_after==source_before,'one or more additional archive sources drifted during copy')
physical_artifacts_after={rel:sha(PHYS_REPORT.parent/rel) for rel in physical_artifacts}
need(physical_artifacts_after==physical_artifacts,'physical producer artifact changed during archive copy')

# Summarize root review facts directly from frozen producer/auditor reports.
load_count=sum(1 for x in physical.get('artifacts',{}) if x.startswith('load-') and x.endswith('/command.json'))
root_facts={'status':'PASS_PRESERVED_FIRST_CH1_VOLATILE_PHYSICAL_TRIAL_EVIDENCE_SCOPE_ONLY',
 'image_review_status':image['status'],'physical_producer_status':physical['status'],'independent_wire_audit_status':wire['status'],
 'historical_wire_audit_v1_status':wire_v1['status'],'historical_wire_audit_v1_error':wire_v1.get('error'),
 'source_tag':image['usr_access'],'source_sha256':image['source_sha256'],'image_sha256':image['bitstream']['sha256'],
 'selected_physical_channel':image['selected_physical_channel'],'volatile_configuration_loads':load_count,
 'flash_written':physical['flash_written'],'scratch_bytes':wire['scratch_bytes'],'scratch_addresses':physical['tests'][0]['addresses'],
 'scratch_trials_per_address_order_count':physical['tests'][0]['trials'],'raw_case':'capture_sub_9','raw_tasks':wire['tasks'],
 'raw_complete_bo_bytes':wire['complete_bo_bytes'],'complete_readback_before_ack':wire['complete_readback_before_ack'],
 'raw_submits':wire['submits'],'raw_acknowledgments':wire['acknowledgments'],
 'scan_count':wire['raw_scan_stats']['scans'],'command_count':wire['raw_scan_stats']['commands'],
 'default_drc':default_drc,'bitstream_drc':bit_drc,'critical_warning_event_count_in_emission_logs':len(critical_warning_events),
 'full_capacity_qualified':wire['full_capacity_qualified'],'ecc_injection_qualified':wire['ecc_injection_qualified'],
 'full512_integrated':wire['full512_integrated'],'pcie_tested':wire['pcie_tested'],
 'rk_silicon_equivalence':wire['rk_silicon_equivalence'],'electrical_signoff':wire['electrical_signoff'],
 'software_crc_validation':wire['software_crc_validation'],'hardware_accessed':physical['lease_acquired'],
 'scope':'One authorized volatile CH1 image load; small scratch check and one raw SUB9 complete BO readback before ACK. Not a full DDR/ECC/PCIe/RK/electrical signoff.'}
(DEST/'root-review-facts.json').write_text(json.dumps(root_facts,indent=2,sort_keys=True)+'\n')
file_index['root-review-facts.json']={'source_path':'generated from image-review, physical producer report, independent wire audit','archive_path':'root-review-facts.json',
 'role':'portable trial facts/limits','source_bytes':(DEST/'root-review-facts.json').stat().st_size,'source_sha256':sha(DEST/'root-review-facts.json'),
 'archive_bytes':(DEST/'root-review-facts.json').stat().st_size,'archive_sha256':sha(DEST/'root-review-facts.json'),'compression':'none'}
# Complete index; excluded binary/tool bindings include exact names, hashes, bytes and reasons.
source_bytes=sum(x['source_bytes'] for x in file_index.values());stored_bytes=sum(x['archive_bytes'] for x in file_index.values())
index={'schema':'ch1-ddr-first-fpga-selected-evidence-v1','status':'PRESERVED_FIRST_CH1_VOLATILE_PHYSICAL_TRIAL_EVIDENCE_SCOPE_ONLY',
 'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'image_review_path':relroot(IMAGE_REVIEW),'image_review_sha256':sha(IMAGE_REVIEW),
 'image_review_bound_count':511,'image_review_bound_included_count':len(included_bound),'image_review_bound_excluded':excluded_bound,
 'source_tag':SOURCE_SHA,'source_tag_usr_access':'a2dfec21','image_sha256':BIT_SHA,'native_scan_trace_path':'trial/physical-test/raw-jobs/native-scans.jsonl',
 'source_closure':{'actual_used_hdl_count':122,'actual_used_hdl_paths':[relroot(pathlib.Path(x)) for x in used_hdl],
                   'xdc_paths':[relroot(ROOT/'build/ypcb-ddr-shell/ch1-physical-synth-v2/source/mig-original.xdc'),relroot(ROOT/'build/ypcb-ddr-shell/ch1-physical-synth-v2/source/board.xdc')]},
 'scope_facts':root_facts,'scope_limitations':{'full_capacity_ddr':False,'ecc_injection':False,'full512_ddr':False,'pcie':False,
   'rk_silicon_equivalence':False,'electrical_signoff':False,'software_crc_validation':'NOT_PERFORMED','flash_written':False},
 'excluded_files':{'bound_inputs':excluded_bound,'additional_binary_files':excluded_extra,'skipped_pycache_paths':skipped_pycache},
 'compression_policy':'Text payloads larger than 16384 bytes use deterministic gzip mtime=0 level 9; source/stored hashes and sizes are recorded.',
 'file_count':len(file_index),'source_bytes_total':source_bytes,'stored_bytes_total':stored_bytes,'files':file_index}
(DEST/'index.json').write_text(json.dumps(index,indent=2,sort_keys=True)+'\n')
# Checksums for every indexed payload and index itself.
lines=[f"{e['archive_sha256']}  {e['archive_path']}" for _,e in sorted(file_index.items())]
lines.append(f"{sha(DEST/'index.json')}  index.json")
(DEST/'archive_SHA256SUMS').write_text('\n'.join(lines)+'\n')
# Final file-by-file rehash, decompression, and size audit.
for name,e in file_index.items():
 p=DEST/e['archive_path'];data=p.read_bytes();need(len(data)==e['archive_bytes'] and hashlib.sha256(data).hexdigest()==e['archive_sha256'],f'stored payload check failed {name}')
 raw=gzip.decompress(data) if e['compression'].startswith('gzip') else data
 need(len(raw)==e['source_bytes'] and hashlib.sha256(raw).hexdigest()==e['source_sha256'],f'decoded payload check failed {name}')
print(json.dumps({'status':index['status'],'archive':str(DEST),'index_sha256':sha(DEST/'index.json'),
 'files':index['file_count'],'source_bytes':source_bytes,'stored_bytes':stored_bytes,
 'bound_included':len(included_bound),'bound_excluded':len(excluded_bound),'additional_sources':len(selected),
 'actual_hdl_sources':len(used_hdl),'scan_count':wire['raw_scan_stats']['scans']},indent=2))
