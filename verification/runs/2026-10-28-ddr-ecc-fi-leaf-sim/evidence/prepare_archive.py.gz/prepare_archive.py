#!/usr/bin/env python3
"""Archive private FI_XOR leaf validation attempts v1-v10 plus root source/native reviews."""
import builtins,datetime,gzip,hashlib,json,pathlib,re,shutil,symtable,sys
from pathlib import Path
ROOT=pathlib.Path('/home/fedora/rknpu-fpga');BASE=ROOT/'build/ddr-ecc-fi-leaf-sim-archive-v1'
ATTEMPTS=ROOT/'build';DEST=ROOT/'verification/runs/2026-10-28-ddr-ecc-fi-leaf-sim'
ROOT_REVIEW=ROOT/'build/ddr-ecc-fi-leaf-root-review-v1.json';ROOT_REVIEWER=ROOT/'build/ddr-ecc-fi-leaf-root-review-v1.py'
OBLIGATION=ROOT/'build/full512-ddr-preparation/ecc-injection-contract-source-review-v1.json'
OBLIGATION_REVIEWER=ROOT/'build/full512-ddr-preparation/ecc-injection-contract-source-review-v1.py'
PREP=ROOT/'build/full512-ddr-preparation/shared-data-constrained-prep-v4/preparation.json'
LEAF=ROOT/'build/full512-ddr-preparation/shared-data-constrained-prep-v4/source/hdl/056/mig_7series_v4_2_fi_xor.v'
OBSERVATION=BASE/'v4-launch-observation.json';GLOBAL=BASE/'packer-global-bindings.json';PACKER=pathlib.Path(__file__).resolve();BLOCK=1<<20
TEXT_SUFFIXES={'.json','.jsonl','.log','.txt','.sv','.v','.py','.tcl','.csv','.tsv','.rpt','.hex','.md'}
def need(x,msg):
 if not x:raise RuntimeError(msg)
def sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for b in iter(lambda:f.read(BLOCK),b''):h.update(b)
 return h.hexdigest()
def load(p):return json.loads(pathlib.Path(p).read_text())
def repo_rel(p):
 q=pathlib.Path(p).resolve()
 try:return q.relative_to(ROOT).as_posix()
 except ValueError:return str(q)
def is_text(p):
 with pathlib.Path(p).open('rb') as f:
  for b in iter(lambda:f.read(BLOCK),b''):
   if b'\0' in b or any(c<32 and c not in (9,10,12,13) for c in b):return False
 return True
def global_scan(path):
 t=symtable.symtable(pathlib.Path(path).read_text(),str(path),'exec')
 defined={s.get_name() for s in t.get_symbols() if s.is_assigned() or s.is_imported() or s.is_namespace()}
 allowed=set(dir(builtins))|{'__file__','__name__','__package__','__spec__','__builtins__','__doc__','__annotations__'}
 errors=[]
 def visit(scope):
  for s in scope.get_symbols():
   if s.is_global() and s.is_referenced() and s.get_name() not in defined and s.get_name() not in allowed:
    errors.append({'scope':scope.get_name(),'line':scope.get_lineno(),'name':s.get_name()})
  for child in scope.get_children():visit(child)
 visit(t);return errors
def copy_payload(src,dst,enc):
 src=pathlib.Path(src);dst=pathlib.Path(dst);dst.parent.mkdir(parents=True,exist_ok=True);h=hashlib.sha256();n=0
 with src.open('rb') as inf,dst.open('wb') as raw:
  if enc=='gzip-mtime0-level9':
   with gzip.GzipFile(filename='',mode='wb',fileobj=raw,compresslevel=9,mtime=0) as z:
    for b in iter(lambda:inf.read(BLOCK),b''):h.update(b);n+=len(b);z.write(b)
  else:
   for b in iter(lambda:inf.read(BLOCK),b''):h.update(b);n+=len(b);raw.write(b)
 return h.hexdigest(),n,sha(dst),dst.stat().st_size
def decoded(path,enc):
 h=hashlib.sha256();n=0
 with pathlib.Path(path).open('rb') as raw:
  f=gzip.GzipFile(fileobj=raw,mode='rb') if enc=='gzip-mtime0-level9' else raw
  for b in iter(lambda:f.read(BLOCK),b''):h.update(b);n+=len(b)
 return h.hexdigest(),n
errs=global_scan(PACKER)
global_info={'status':'PASS_STDLIB_SYMTABLE_GLOBAL_BINDINGS' if not errs else 'FAIL_UNRESOLVED_GLOBAL_BINDINGS',
 'packer_path':repo_rel(PACKER),'packer_sha256':sha(PACKER),'unresolved_globals':errs}
GLOBAL.write_text(json.dumps(global_info,indent=2,sort_keys=True)+'\n')
if '--check-globals-only' in sys.argv:
 print(json.dumps(global_info,indent=2,sort_keys=True));raise SystemExit(0 if not errs else 1)
need(not errs,'Archive packer has unresolved globals: '+repr(errs));need(not DEST.exists(),'Archive destination must be fresh')
need(PREP.is_file() and sha(LEAF)==load(PREP)['copied_source_hashes']['hdl/056/mig_7series_v4_2_fi_xor.v'],'Frozen actual FI_XOR leaf differs from source closure')
root_review=load(ROOT_REVIEW);obligation=load(OBLIGATION)
need(root_review['status']=='PASS_ROOT_FI_LEAF_NATIVE_BEHAVIOR_ONLY_WITH_RECORDED_ICARUS_VENDOR_WARNING' and
     root_review['failed_v10_receipt_relabelled'] is False and root_review['hardware_accessed'] is False,
     'Root FI leaf review disposition changed')
need(obligation['status']=='SOURCE_REVIEW_ONLY_NOT_INJECTION_QUALIFICATION' and
     obligation['physical_ecc_injection_qualified'] is False and obligation['recovery_qualified'] is False and
     obligation['hardware_accessed'] is False and obligation['vivado_executed'] is False,
     'ECC source-obligations review changed')
reports={}
for n in range(1,11):
 folder=ATTEMPTS/f'ddr-ecc-fi-leaf-validation-v{n}'
 reports[n]=load(folder/'report.json') if (folder/'report.json').is_file() else None
need(reports[1]['status']=='FAIL' and reports[2]['status']=='FAIL' and reports[3]['status']=='FAIL',
     'Preserved version-probe/Icarus-warning attempts changed')
need(reports[5]['status']=='FAIL' and reports[6]['status']=='FAIL' and
     reports[7]['status']=='PASS_FI_XOR_LEAF_VERILATOR_ONLY' and
     all(reports[n]['status']=='FAIL' for n in (8,9,10)),
     'Preserved strict-Verilator/Icarus producer outcomes changed')
need(reports[10]['commands'][0]['returncode']==reports[10]['commands'][1]['returncode']==0 and
     reports[10]['commands'][1]['stdout_sha256'],'V10 actual Icarus native run result not present')
need(root_review['same_vendor_and_bench_bytes_both_simulators'] is True and
     root_review['memory_controller_decoder_or_phy_simulated'] is False and
     root_review['physical_ecc_injection_qualified'] is False,
     'Root acceptance scope changed')
need(not (ATTEMPTS/'ddr-ecc-fi-leaf-validation-v4/report.json').exists(),
     'Do not invent v4 producer report; preserve its no-report observation separately')
strict_prep=load(PREP)
expected_leaf=strict_prep['copied_source_hashes']['hdl/056/mig_7series_v4_2_fi_xor.v']
need(expected_leaf=='ba05d31545d807b8e485a6d2c4e6bd51824aefe31981c9fe4e3d98bbd4e06fb1',
     'Frozen FI_XOR leaf hash changed')
reviewed_native={case['simulator']:case for case in root_review['cases']}
need(set(reviewed_native)=={'icarus','verilator'},'Root review must cover both native simulators')
native_results={}
for simulator,n in (('verilator',7),('icarus',10)):
 report=reports[n];case=reviewed_native[simulator]
 need(case['native_compile_rc']==0 and case['native_run_rc']==0 and
      case['exact_marker']=='PASS fi_xor_leaf seed=00003588 scenarios=38 byte_lanes=9 low72_only=1 write_clear=1',
      'Root native execution result changed: '+simulator)
 leaf_hashes=[h for p,h in report['source_inputs'].items() if pathlib.Path(p).name=='mig_7series_v4_2_fi_xor.v']
 bench_hashes=[h for p,h in report['source_inputs'].items() if pathlib.Path(p).name=='tb_mig_fi_xor.sv']
 need(leaf_hashes and all(h==expected_leaf for h in leaf_hashes) and bench_hashes and len(set(bench_hashes))==1,
      'Root-reviewed source/bench bytes differ for '+simulator)
 commands={cmd['name']:cmd for cmd in report['commands']}
 need(len(commands)==2 and all(c['returncode']==0 and sha(c['stdout_log'])==c['stdout_sha256'] and
      sha(c['stderr_log'])==c['stderr_sha256'] for c in commands.values()),
      'Root-reviewed native command logs changed for '+simulator)
 compile_name='verilator_compile' if simulator=='verilator' else 'iverilog_compile'
 run_name='verilator_run' if simulator=='verilator' else 'vvp_run'
 compile_stderr=Path(commands[compile_name]['stderr_log']).read_text(errors='replace')
 run_stdout=Path(commands[run_name]['stdout_log']).read_text(errors='replace')
 need(case['compile_warning'] is None if simulator=='verilator' else
      'Anachronistic use of begin/end to surround generate schemes.' in compile_stderr,
      'Root-reviewed compile warning disposition changed: '+simulator)
 need(case['producer_status_preserved']==report['status'] and
      ('PASS_FI_XOR_LEAF_VERILATOR_ONLY' if simulator=='verilator' else 'FAIL'),
      'Native producer status was not honestly preserved: '+simulator)
 need(case['exact_marker'] in run_stdout,'Native marker missing from actual run log: '+simulator)
 native_results[simulator]={'attempt':n,'producer_status_preserved':report['status'],
  'native_compile_rc':case['native_compile_rc'],'native_run_rc':case['native_run_rc'],
  'exact_marker':case['exact_marker'],'leaf_sha256':leaf_hashes[0],'bench_sha256':bench_hashes[0],
  'compile_warning':case['compile_warning'],'compile_stdout_sha256':commands[compile_name]['stdout_sha256'],
  'compile_stderr_sha256':commands[compile_name]['stderr_sha256'],'run_stdout_sha256':commands[run_name]['stdout_sha256'],
  'run_stderr_sha256':commands[run_name]['stderr_sha256']}

sources={};excluded=[]
def add(path,role,expected=None,dest=None,force_identity=False):
 p=pathlib.Path(path).resolve();need(p.is_file(),'Missing selected archive input: '+str(p));h=sha(p)
 if expected is not None:need(h==expected,'Source hash mismatch: '+str(p))
 need(is_text(p),'Non-text archive payload not allowed: '+str(p))
 key=str(p)
 if dest is None:dest='evidence/'+repo_rel(p)
 if key in sources:
  need(sources[key]['source_sha256']==h,'Changed source alias')
  if role not in sources[key]['roles']:sources[key]['roles'].append(role)
  return
 enc='identity' if force_identity or p.stat().st_size<=16384 else 'gzip-mtime0-level9'
 sources[key]={'path':p,'source_sha256':h,'source_bytes':p.stat().st_size,'roles':[role],'archive_path':dest,'encoding':enc,'kind':'text'}
def exclude(path,reason):
 p=pathlib.Path(path).resolve()
 if not p.is_file():return
 excluded.append({'source_path':repo_rel(p),'sha256':sha(p),'bytes':p.stat().st_size,'reason':reason})
# The exact selected vendor leaf/source closure and root/source-obligations receipts.
add(PREP,'160-file frozen strict route source-preparation manifest')
add(LEAF,'actual selected vendor FI_XOR source; exact frozen source leaf',sha(LEAF))
add(ROOT_REVIEW,'root independent native FI leaf behavior review; failed V10 producer status is preserved')
add(ROOT_REVIEWER,'root independent FI leaf review implementation')
add(OBLIGATION,'source-only ECC injection/recovery obligations review; not qualification')
add(OBLIGATION_REVIEWER,'source-only ECC obligations reviewer implementation')
add(GLOBAL,'stdlib symtable global-binding check receipt')
add(PACKER,'archive packer implementation',dest='evidence/prepare_archive.py')
add(BASE/'verify_archive.py','independent archive verifier source',dest='evidence/verify_archive.py')
add(BASE/'run_archive.py','archive run wrapper source',dest='evidence/run_archive.py')
add(BASE/'run_archive.py','archive runner source',dest='evidence/run_archive.py')
add(OBSERVATION,'v4 observed runner failure note; not a native producer receipt')
# Preserve each attempted private runner and exact testbench/source copy, plus reports/launches/text logs.
for n in range(1,11):
 folder=ATTEMPTS/f'ddr-ecc-fi-leaf-validation-v{n}'
 need(folder.is_dir(),f'missing private attempt directory v{n}')
 for p in sorted(folder.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(folder).as_posix()
  if '__pycache__' in p.parts or p.suffix.lower()=='.pyc':
   exclude(p,f'Python compiled bytecode excluded by hash from private attempt v{n}')
   continue
  if any(part=='obj' for part in p.relative_to(folder).parts) or p.suffix.lower() in {'.vvp','.elf','.exe','.so','.o','.a','.cpp','.h','.mk','.d','.gch'} or p.name=='sim':
   exclude(p,f'Verilator/Icarus compiled simulator or generated compiler intermediate excluded; native result is separately reported and hashed (v{n})')
   continue
  if p.suffix.lower() in TEXT_SUFFIXES:
   add(p,f'private v{n} source/report/launch/native-text artifact',dest='attempts/v'+str(n)+'/'+rel)
# Include each actual v10 runner-produced compile/run log; full stdout/stderr are text and are selected above.
# Exact payload inclusion of root-accepted V7 and Icarus V10 receipts/logs is checked before copying.
for n in (7,10):
 r=reports[n];need(r is not None,'Missing root-reviewed V7/V10 producer record')
 for cmd in r['commands']:
  for key in ('stdout_log','stderr_log'):
   p=Path(cmd[key]);need(p.is_file(),'Missing native log '+str(p));add(p,f'actual V{n} {cmd["name"]} native output',cmd[key.replace('_log','_sha256')],dest='attempts/v'+str(n)+'/logs/'+p.name)
# V4 produced no report or launch.json. Bind its private runner/inputs and observed exception distinctly.
obs=load(OBSERVATION)
need(obs['status']=='FAIL_BEFORE_NATIVE_COMPILATION' and obs['producer_report_exists'] is False and
     obs['launch_json_exists'] is True and obs['v4_launch_json_sha256']==sha(ATTEMPTS/'ddr-ecc-fi-leaf-validation-v4/launch.json') and
     obs['exception']=="AttributeError: 'NoneType' object has no attribute 'update'",
     'V4 runner-failure observation changed')
# Hash external compiler/simulator executables only; never place them in the verification archive.
tools=[]
for name in ('iverilog','vvp','verilator','c++'):
 path=shutil.which(name);need(path,'Missing host tool '+name);p=Path(path).resolve()
 tools.append({'name':name,'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'reason':'Native/compiler executable excluded; exact versions and launch argv are in attempt reports.'})
# Check V7/V10 actual source/bench identities exactly match root review.
for case in root_review['cases']:
 r=json.loads(Path(case['report_path']).read_text())
 need(sha(case['report_path'])==case['report_sha256'] and r['status']==case['producer_status_preserved'],
      'Changed root-reviewed native attempt report')
 for inputpath,digest in r.get('source_inputs',{}).items():
  if Path(inputpath).is_file():need(sha(inputpath)==digest,'Changed native source input '+inputpath)
# Inventory generated outputs not otherwise selected for each attempt, preserving binary hashes/reasons.
selected={str(e['path'].resolve()) for e in sources.values()}
for n in range(1,11):
 folder=ATTEMPTS/f'ddr-ecc-fi-leaf-validation-v{n}'
 for p in sorted(folder.rglob('*')):
  if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.pyc' or str(p.resolve()) in selected:continue
  if p.suffix.lower() in {'.vvp','.elf','.exe','.so','.o','.a','.cpp','.h','.mk','.d','.gch'} or 'obj' in p.parts or p.name=='sim':
   exclude(p,'compiled simulator/object/generated compiler file excluded by SHA and reason')
# Rehash the selected inputs before archive copy.
for key,item in sources.items():need(sha(item['path'])==item['source_sha256'],'Selected source changed before copy '+key)
if '--check-globals-only' in sys.argv:
 print(json.dumps({'status':global_info['status'],'unresolved_globals':global_info['unresolved_globals']},indent=2));raise SystemExit(0)
if '--preflight-only' in sys.argv:
 print(json.dumps({'status':'PASS_FI_ARCHIVE_PREFLIGHT_ONLY','payload_count':len(sources),'source_bytes':sum(x['source_bytes'] for x in sources.values()),
  'attempts':10,'root_reviewed_native_attempts':[7,10],'v4_observation_preserved':True,'destination_created':DEST.exists(),
  'global_bindings':global_info['status']},indent=2));raise SystemExit(0)
need(not DEST.exists(),'Fresh archive destination required')
DEST.mkdir(parents=True);files=[];by_source={}
for key,item in sorted(sources.items(),key=lambda kv:kv[1]['archive_path']):
 rel=item['archive_path'];enc=item['encoding']
 if enc=='gzip-mtime0-level9':rel+='.gz'
 dest=DEST/rel;sd,sn,hd,hn=copy_payload(item['path'],dest,enc)
 need(sd==item['source_sha256'] and sn==item['source_bytes'],'Source changed during copy '+key)
 row={'source_path':repo_rel(item['path']),'archive_path':rel,'roles':item['roles'],'source_sha256':sd,'source_bytes':sn,
      'stored_sha256':hd,'stored_bytes':hn,'encoding':enc,'kind':item['kind']}
 files.append(row);by_source[key]=row
for row in files:
 p=DEST/row['archive_path'];need(sha(p)==row['stored_sha256'],'Stored payload mismatch')
 digest,size=decoded(p,row['encoding']);need(digest==row['source_sha256'] and size==row['source_bytes'],'Decoded payload mismatch')
 src=Path(row['source_path']);src=src if src.is_absolute() else ROOT/src;need(sha(src)==row['source_sha256'],'Origin changed after copy')
coverage=[]
def cover(label,path,expected,role):
 p=Path(path).resolve();key=str(p);need(key in by_source,'Coverage path not archived '+key)
 item=by_source[key];need(item['source_sha256']==expected==sha(p),'Coverage hash mismatch '+key)
 coverage.append({'label':label,'source_path':repo_rel(p),'source_sha256':expected,'source_bytes':p.stat().st_size,'role':role,
   'archive_path':item['archive_path'],'archive_sha256':item['stored_sha256'],'archive_bytes':item['stored_bytes'],'encoding':item['encoding']})
for n in range(1,11):
 folder=ATTEMPTS/f'ddr-ecc-fi-leaf-validation-v{n}'
 for p in sorted(folder.rglob('*')):
  if p.is_file() and (p.suffix.lower() in TEXT_SUFFIXES):
   q=Path(p.resolve());key=str(q)
   if key in by_source:cover('attempt_v'+str(n)+':'+q.relative_to(folder.resolve()).as_posix(),q,by_source[key]['source_sha256'],'attempt source/report/runner/log/history')
for name,path in [('root-review',ROOT_REVIEW),('root-reviewer',ROOT_REVIEWER),('ecc-source-review',OBLIGATION),('ecc-source-reviewer',OBLIGATION_REVIEWER),
                  ('selected-leaf',LEAF),('strict-source-preparation',PREP)]:cover('review:'+name,path,sha(path),'root reviewed source evidence')
for ref in coverage:need((DEST/ref['archive_path']).is_file() and sha(DEST/ref['archive_path'])==ref['archive_sha256'],'Coverage archive pointer mismatch')
index={'schema':1,'status':'PASS_DDR_FI_XOR_LEAF_SIMULATION_EVIDENCE_ARCHIVE',
 'scope':{'evidence_scope':'Root-reviewed actual vendor FI_XOR leaf behavioral test in Icarus13 and strict Verilator5.048. One unsuppressed Icarus vendor generate-style warning is preserved. V10 producer status remains FAIL due its finish-metadata postchecker; native run rc0/marker is separately root-reviewed.',
  'leaf_source_sha256':'ba05d31545d807b8e485a6d2c4e6bd51824aefe31981c9fe4e3d98bbd4e06fb1','scenario_count':38,
  'physical_capacity_qualified':False,'physical_ecc_injection_qualified':False,'controller_or_decoder_simulated':False,
  'memory_simulated':False,'phy_simulated':False,'recovery_qualified':False,'hardware_accessed':False,'vivado_executed':False,
  'preserved_attempts_v1_to_v10':True,'v7_strict_verilator_native_pass':True,'v10_icarus_native_behavior_pass_producer_fail_preserved':True,
  'v4_missing_producer_report':'A separately labeled tool-output observation records the private Python runner exception; not a synthesized producer receipt.'},
 'file_count':len(files),'source_bytes':sum(x['source_bytes'] for x in files),'stored_bytes':sum(x['stored_bytes'] for x in files),
 'encoding_policy':'Text payloads larger than 16KiB use deterministic gzip level9/mtime0; smaller text identity. Compiled simulator/object/tool binaries excluded by SHA/reason.',
 'files':files,'coverage_references':coverage,'hash_only_excluded_binaries':excluded,'hash_only_excluded_tools':tools,
 'attempt_producer_statuses':{str(n):(reports[n]['status'] if reports[n] else 'NO_PRODUCER_REPORT_V4_RUNNER_EXCEPTION_CAPTURED_SEPARATELY') for n in range(1,11)},
 'root_reviewed_native_results':native_results,
 'root_fi_leaf_review_sha256':sha(ROOT_REVIEW),'root_fi_leaf_review_status':root_review['status'],
 'ecc_injection_source_review_sha256':sha(OBLIGATION),'ecc_injection_source_review_status':obligation['status'],
 'selected_source_preparation_sha256':sha(PREP),'archive_packer_sha256':sha(PACKER),'global_binding_receipt_sha256':sha(GLOBAL)}
indexpath=DEST/'index.json';indexpath.write_text(json.dumps(index,indent=2,sort_keys=True)+'\n')
actual={p.relative_to(DEST).as_posix() for p in DEST.rglob('*') if p.is_file()}
need(actual=={f['archive_path'] for f in files}|{'index.json'},'Archive has extra/missing payloads')
print(json.dumps({'status':index['status'],'archive':repo_rel(DEST),'payload_count':len(files),'source_bytes':index['source_bytes'],
 'stored_bytes':index['stored_bytes'],'coverage_count':len(coverage),'excluded_binaries':len(excluded),'excluded_tools':len(tools),
 'index_sha256':sha(indexpath),'packer_sha256':sha(PACKER)},indent=2))
