#!/usr/bin/env python3
"""Unlaunchable-by-default full512 CH1 volatile trial preparation.

Offline mode checks source/vector bindings and reports gates only. Hardware
imports and process/socket/lease operations occur only after an exact reviewed
image and separate root execution approval are bound in preparation.json.
"""
from __future__ import annotations
import argparse, datetime, fcntl, hashlib, json, os, pathlib, re, signal, socket, subprocess, sys, time

ROOT=pathlib.Path('/home/fedora/rknpu-fpga')
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
PKG=pathlib.Path(__file__).resolve().parent
PREP=PKG/'preparation.json'
REVIEW=PKG/'image-review.json'
APPROVAL=PKG/'execution-approval.json'
TEMPLATE=PKG/'program-template.tcl.in'
LEASE=pathlib.Path('/home/fedora/ypcb/build/hardware-locks/ypcb-jtag.lock')
TARGET='localhost:3125/xilinx_tcf/Xilinx/80802026a77a01'
DNA='004E544714C705C'; IDCODE='23751093'; SOURCE='5e99f881'
IMAGE_STATUS='PASS_REVIEWED_FULL512_CH1_DDR_DUAL_IMAGE'
APPROVAL_STATUS='ROOT_APPROVED_FULL512_CH1_DDR_TRAINED_VOLATILE_TRIAL'
VIVADO=pathlib.Path('/home/fedora/vivado/2026.1.1/Vivado_Lab/bin/vivado_lab')
HWSERVER=VIVADO.with_name('hw_server')
QUIESCING=False
OWNED_CHILDREN=[]

def interrupted(signum,frame):
    if not QUIESCING: raise InterruptedError('Full512 DDR volatile trial interrupted: '+str(signum))

def sha(path):
    h=hashlib.sha256()
    with pathlib.Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1<<20),b''): h.update(block)
    return h.hexdigest()
def need(ok,msg):
    if not ok: raise RuntimeError(msg)
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path,obj): pathlib.Path(path).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def load(path): return json.loads(pathlib.Path(path).read_text())
def literal(value):
    value=str(value); need(not any(c in value for c in '{}\\\r\n'),'Unsafe Tcl literal')
    return '{'+value+'}'

def check_frozen_inputs(prep):
    image=load(ROOT/prep['full512_image_preparation_path'])
    review=load(ROOT/prep['full512_root_preparation_review_path'])
    bindings=load(ROOT/prep['full512_root_bindings_path'])
    need(sha(ROOT/prep['full512_image_preparation_path'])==prep['full512_image_preparation_sha256'],'full512 image preparation changed')
    need(sha(ROOT/prep['full512_root_preparation_review_path'])==prep['full512_root_preparation_review_sha256'],'root preparation review changed')
    need(sha(ROOT/prep['full512_root_bindings_path'])==prep['full512_root_bindings_sha256'],'root bindings changed')
    manifest=image['hardware_source_manifest']
    digest=hashlib.sha256(json.dumps(manifest,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    need(digest==prep['source_manifest_sha256']==image['hardware_source_sha256'],'source manifest digest changed')
    need(image['source_tag']==prep['source_tag']==digest[:8] and bindings['source_tag']==digest[:8],'source tag changed')
    need(review['hardware_source_sha256']==digest and image['expected_image_review_status']==IMAGE_STATUS,'full512 review contract changed')
    need(manifest['top']=='ypcb_ddr_dual_top' and manifest['part']=='xc7k480tffg1156-2','full512 top/part changed')
    for name,expected in manifest['files'].items():
        p=ROOT/name
        need(p.is_file() and sha(p)==expected,'full512 source input changed: '+name)
    vec=pathlib.Path(prep['trained_vectors_path'])
    need(sha(vec/'report.json')==prep['trained_vectors_report_sha256'],'trained vector report changed')
    vr=load(vec/'report.json')
    need(vr['status']=='STATIC_TRAINED_TILE_JOINED_TEST_VECTORS' and (vr['lines'],vr['cmac_amount'],vr['ew_amount'])==(1408,45,22),'trained tile contract changed')
    for name,digest in vr['files'].items():
        need(sha(vec/name)==digest,'trained vector changed: '+name)
    for name,digest in prep['runtime_source_hashes'].items():
        p=ROOT/name
        need(p.is_file() and sha(p)==digest,'runtime source changed: '+name)
    for name,digest in prep['private_source_hashes'].items():
        p=PKG/name
        need(p.is_file() and sha(p)==digest,'private preparation source changed: '+name)
    for name,digest in prep['tool_hashes'].items():
        p=pathlib.Path(name)
        need(p.is_file() and sha(p)==digest,'native tool binary changed: '+name)
    return image,review,bindings,vr

def pending_gates(prep):
    gates=[]
    image=load(REVIEW); approval=load(APPROVAL)
    if image.get('status')!=IMAGE_STATUS or prep.get('image_review_sha256') is None or sha(REVIEW)!=prep.get('image_review_sha256'):
        gates.append('independent exact full512 CH1 DDR dual-image review and its source-bound hash')
    if image.get('bitstream_path') is None or image.get('bitstream_sha256') is None:
        gates.append('reviewed bitstream path and SHA-256')
    if (approval.get('status')!=APPROVAL_STATUS or approval.get('approved') is not True or
            prep.get('execution_approval_sha256') is None or sha(APPROVAL)!=prep.get('execution_approval_sha256')):
        gates.append('separate final root execution approval and its source-bound hash')
    if not (PKG/'audit_scratch.py').is_file() or prep.get('scratch_auditor_sha256') is None:
        gates.append('root-owned independent scratch-trace auditor and bound hash')
    return gates

def validate_admission(prep):
    image=load(REVIEW); approval=load(APPROVAL)
    need(not pending_gates(prep),'Hardware gates remain pending: '+', '.join(pending_gates(prep)))
    image_digest=sha(REVIEW); bit=pathlib.Path(image['bitstream_path'])
    need(image.get('status')==IMAGE_STATUS,'Wrong full512 image review status')
    need(image.get('top')=='ypcb_ddr_dual_top' and image.get('part')=='xc7k480tffg1156-2','Wrong reviewed image target')
    need((image.get('memory_profile'),image.get('selected_physical_channel'))==('ddr',1),'Reviewed DDR profile/channel changed')
    need((image.get('product_dsps'),image.get('total_dsps'),image.get('bram_blocks'))==(512,516,0),'Reviewed resource counts changed')
    if 'bram_tiles' in image: need(image['bram_tiles']==0,'Alternate BRAM count field changed')
    need(image.get('source_manifest_sha256')==prep['source_manifest_sha256'] and image.get('source_tag')==SOURCE,'Reviewed source binding changed')
    need((image.get('target'),image.get('expected_dna_port'),image.get('expected_raw_idcode'))==(TARGET,DNA,IDCODE),'Reviewed board identity changed')
    need(image.get('programming_scope')=='volatile-sram' and image.get('flash_authorized') is False,'Nonvolatile programming is forbidden')
    need(bit.is_file() and sha(bit)==image['bitstream_sha256'],'Reviewed bitstream hash mismatch')
    bound=image.get('bound_files')
    need(isinstance(bound,dict) and bound,'Image review has no complete bound-file map')
    for name,digest in bound.items():
        p=pathlib.Path(name)
        need(p.is_file() and sha(p)==digest,'Reviewed image input changed: '+name)
    need(prep['image_review_sha256']==image_digest,'Preparation does not bind image review')
    need(approval.get('status')==APPROVAL_STATUS and approval.get('approved') is True,'Missing root execution approval')
    need(approval.get('image_review_sha256')==image_digest and approval.get('bitstream_sha256')==image['bitstream_sha256'],'Approval is not bound to exact review/image')
    for key in ('source_manifest_sha256','source_tag','target','expected_dna_port','expected_raw_idcode',
                'programming_scope','memory_profile','selected_physical_channel','product_dsps','total_dsps','bram_blocks'):
        expected=image.get(key)
        need(approval.get(key)==expected,'Approval binding mismatch: '+key)
    need(approval.get('flash_authorized') is False,'Approval permits flash')
    need(prep['execution_approval_sha256']==sha(APPROVAL),'Preparation does not bind execution approval')
    return image,approval,bit

def recheck_admission(prep,review_sha,approval_sha,bit_sha):
    check_frozen_inputs(prep)
    image,approval,bit=validate_admission(prep)
    need(sha(REVIEW)==review_sha and sha(APPROVAL)==approval_sha and sha(bit)==bit_sha,
         'Image review, execution approval or bitstream changed during trial')
    return image,approval,bit

def offline_preflight():
    prep=load(PREP)
    need(prep['status']=='UNLAUNCHABLE_FULL512_DDR_TRAINED_TRIAL_PREPARATION','Unexpected preparation status')
    check_frozen_inputs(prep)
    gates=pending_gates(prep)
    result={'status':'BLOCKED_PENDING_REVIEW_AND_ROOT_EXECUTION_APPROVAL' if gates else 'READY_REQUIRES_EXPLICIT_EXECUTION_FLAG',
            'pending_gates':gates,'image_review_sha256':prep.get('image_review_sha256'),
            'bitstream_path':None if gates else load(REVIEW)['bitstream_path'],
            'execution_approval_sha256':prep.get('execution_approval_sha256'),
            'hardware_accessed':False,'flash_written':False,'source_tag':SOURCE,
            'scope':'offline-only preflight; no hardware or network operation'}
    print(json.dumps(result,sort_keys=True))
    return 0

def stop_owned(child):
    if child is None: return {'pid':None,'pgid':None,'returncode':None,'members_after':[]}
    pgid=child.pid
    members=live_process_group_members(pgid)
    if members:
        try: os.killpg(pgid,signal.SIGTERM)
        except ProcessLookupError: pass
    deadline=time.monotonic()+10
    while live_process_group_members(pgid) and time.monotonic()<deadline:
        child.poll(); time.sleep(.05)
    members=live_process_group_members(pgid)
    if members:
        try: os.killpg(pgid,signal.SIGKILL)
        except ProcessLookupError: pass
    # Keep the lease until every process in this uniquely owned group is gone.
    while live_process_group_members(pgid):
        child.poll(); time.sleep(.05)
    if child.poll() is None:
        try: child.wait(timeout=.2)
        except subprocess.TimeoutExpired: pass
    members=live_process_group_members(pgid)
    need(not members,'Owned process group did not disappear: '+repr({'pgid':pgid,'members':members}))
    zombies=[row for row in process_group_members(pgid) if row['state'] in {'Z','X'}]
    return {'pid':child.pid,'pgid':pgid,'returncode':child.poll(),'members_after':members,'zombies_after':zombies}

def process_group_members(pgid):
    members=[]
    for entry in pathlib.Path('/proc').iterdir():
        if not entry.name.isdigit(): continue
        try:
            stat=(entry/'stat').read_text(); end=stat.rfind(')')
            fields=stat[end+2:].split()
            if len(fields)>=3 and int(fields[2])==pgid:
                members.append({'pid':int(entry.name),'state':fields[0]})
        except (FileNotFoundError,PermissionError,ProcessLookupError,ValueError,IndexError): pass
    return members

def live_process_group_members(pgid):
    return [row for row in process_group_members(pgid) if row['state'] not in {'Z','X'}]

def start_owned(argv,log,cwd,stderr=subprocess.STDOUT):
    blocked={signal.SIGINT,signal.SIGTERM,signal.SIGHUP,signal.SIGALRM}
    previous=signal.pthread_sigmask(signal.SIG_BLOCK,blocked)
    try:
        child=subprocess.Popen(argv,cwd=cwd,stdout=log,stderr=stderr,start_new_session=True,
            preexec_fn=lambda:signal.pthread_sigmask(signal.SIG_SETMASK,previous))
        OWNED_CHILDREN.append(child)
        return child
    finally:
        signal.pthread_sigmask(signal.SIG_SETMASK,previous)

def wait_owned_natural(child,timeout):
    code=child.wait(timeout=timeout)
    members=live_process_group_members(child.pid)
    if members:
        cleanup=stop_owned(child)
        raise RuntimeError('Owned process leader exited but its group did not: '+repr(cleanup))
    need(code==0,'Owned process exited unsuccessfully: '+str(code))
    zombies=[row for row in process_group_members(child.pid) if row['state'] in {'Z','X'}]
    return {'pid':child.pid,'pgid':child.pid,'returncode':code,'members_after':[],'zombies_after':zombies}

def parse_program_receipt(text):
    rows=text.splitlines(); need(rows,'Empty programming receipt')
    pairs=[]
    for row in rows:
        fields=row.split('\t')
        need(len(fields)==2 and fields[0] and fields[1],'Malformed programming receipt row: '+repr(row))
        pairs.append(fields)
    keys=[key for key,_ in pairs]
    need(len(keys)==len(set(keys)),'Duplicate programming receipt keys')
    return dict(pairs)

def cleanup_owned_groups():
    results=[]
    seen=set()
    for child in reversed(OWNED_CHILDREN):
        if child.pid in seen: continue
        seen.add(child.pid)
        results.append(stop_owned(child))
    need(all(not row['members_after'] for row in results),'Owned live process groups remain before lease release')
    return results

def hardware_admission(image,approval,bit,prep):
    # Imported only after the exact image review and separate root approval passed.
    lease=LEASE.open('r+b')  # existing lock only; never create, truncate or replace
    try:
        need(os.fstat(lease.fileno()).st_ino==prep['lease_inode'],'Shared lease inode changed')
        fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BaseException:
        lease.close()
        raise
    try:
        names={'hw_server','openocd','xsdb','openFPGALoader','fxload','xvcserver','xvc-server','xvc_server','vivado_lab'}
        controllers=[]
        for proc in pathlib.Path('/proc').iterdir():
            if proc.name.isdigit():
                try:
                    comm=(proc/'comm').read_text().strip()
                    if comm in names: controllers.append({'pid':int(proc.name),'name':comm})
                except (FileNotFoundError,PermissionError,ProcessLookupError): pass
        need(not controllers,'Other board controller present: '+repr(controllers))
        for port in (3121,3125,3721,3741,2542):
            with socket.socket() as s:
                s.settimeout(.2); need(s.connect_ex(('127.0.0.1',port))!=0,'Hardware service port already listening: '+str(port))
        usb=subprocess.run(['lsusb','-d','03fd:0008'],capture_output=True,text=True,timeout=10)
        need(usb.returncode==0 and len(usb.stdout.strip().splitlines())==1,'Expected exactly one initialized DLC10')
        m=re.fullmatch(r'Bus (\d{3}) Device (\d{3}):.*',usb.stdout.strip()); need(m,'Cannot identify USB node')
        node='/dev/bus/usb/'+m[1]+'/'+m[2]
        owners=subprocess.run(['fuser',node],capture_output=True,text=True,timeout=10)
        need(owners.returncode==1 and not owners.stdout.strip(),'USB cable is already owned or fuser check failed')
        return lease,{'usb':usb.stdout.strip(),'usb_node':node,'controllers':controllers,'lease_inode':os.fstat(lease.fileno()).st_ino}
    except BaseException:
        try: fcntl.flock(lease,fcntl.LOCK_UN)
        finally: lease.close()
        raise

def main(argv=None):
    global QUIESCING
    parser=argparse.ArgumentParser()
    parser.add_argument('--execute-volatile-sram',action='store_true')
    args=parser.parse_args(argv)
    if not args.execute_volatile_sram: return offline_preflight()
    prep=load(PREP)
    need(prep['status']=='UNLAUNCHABLE_FULL512_DDR_TRAINED_TRIAL_PREPARATION','Unexpected preparation status')
    check_frozen_inputs(prep)
    image,approval,bit=validate_admission(prep)
    review_sha=sha(REVIEW); approval_sha=sha(APPROVAL); bit_sha=sha(bit)
    for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP,signal.SIGALRM): signal.signal(sig,interrupted)

    # Hardware libraries/processes are imported/launched below the complete gate only.
    from tools.host.native_link import render_bridge
    from tools.tinystories.native_trace import RecordedNativeLink
    from tools.ddr.dual_transport import DualDdrRawTransport
    from tools.ddr.raw_test import scratch
    lease=None; server=program=bridge=worker_proc=None; links=[]; logs=[]; paths=[]
    from tools.tinystories.progress import require_memory
    require_memory(4096)
    run=PKG/'physical-test'; need(not run.exists(),'Physical output path already exists'); run.mkdir()
    record={'status':'RUNNING_AUTHORIZED_FULL512_CH1_DDR_VOLATILE_TRIAL','started_utc':utc(),
        'image_review_sha256':sha(REVIEW),'execution_approval_sha256':sha(APPROVAL),
        'bitstream_sha256':sha(bit),'source_manifest_sha256':prep['source_manifest_sha256'],
        'source_tag':SOURCE,'target':TARGET,'expected_dna_port':DNA,'expected_raw_idcode':IDCODE,
        'memory_profile':'ddr','selected_physical_channel':1,'product_dsps':512,'total_dsps':516,'bram_blocks':0,
        'lease_path':str(LEASE),'hardware_programmed':False,'flash_written':False,
        'full_capacity_qualified':False,'ecc_injection_qualified':False,
        'full512_ddr_integrated':False,'pcie_tested':False,'tests':[]}
    write(run/'report.json',record)
    try:
        signal.alarm(1200)
        lease,admission=hardware_admission(image,approval,bit,prep); record['admission']=admission
        recheck_admission(prep,review_sha,approval_sha,bit_sha)
        serverlog=(run/'hw-server.log').open('x'); logs.append(serverlog)
        server=start_owned([str(HWSERVER),'-s','tcp::3125'],serverlog,run); record['hw_server_pid']=server.pid; write(run/'report.json',record)
        limit=time.monotonic()+20
        while True:
            need(server.poll() is None,'Owned hw_server exited')
            with socket.socket() as s:
                s.settimeout(.2)
                if s.connect_ex(('127.0.0.1',3125))==0: break
            need(time.monotonic()<limit,'Owned hw_server startup timeout'); time.sleep(.1)
        load_dir=run/'load-1'; load_dir.mkdir()
        text=TEMPLATE.read_text()
        values={'TARGET':TARGET,'BITSTREAM':bit,'RECEIPT':load_dir/'program.tsv','USR_ACCESS':SOURCE,'BITSTREAM_SHA':image['bitstream_sha256']}
        for name,value in values.items():
            marker='@'+name+'@'; need(text.count(marker)==1,'Program template marker changed: '+name); text=text.replace(marker,literal(value))
        tcl=load_dir/'program.tcl'; tcl.write_text(text); recheck_admission(prep,review_sha,approval_sha,bit_sha)
        argv_hw=[str(VIVADO),'-mode','batch','-source',str(tcl),'-log',str(load_dir/'vivado.log'),'-journal',str(load_dir/'vivado.jou')]
        log=(load_dir/'stdout.log').open('x'); logs.append(log)
        record['hardware_programming_may_have_occurred']=True; write(run/'report.json',record)
        command={'argv':argv_hw,'started_utc':utc(),'program_tcl_sha256':sha(tcl),
                 'bitstream_sha256_before':sha(bit),'flash_written':False}
        write(load_dir/'command.json',command)
        try: program=start_owned(argv_hw,log,load_dir)
        except BaseException as error:
            command.update(pid=None,pgid=None,returncode=None,finished_utc=utc(),spawn_error=repr(error))
            write(load_dir/'command.json',command)
            raise
        command['pid']=program.pid; command['pgid']=program.pid; write(load_dir/'command.json',command)
        try: program_code=program.wait(timeout=180)
        except subprocess.TimeoutExpired:
            command.update(returncode=None,timeout=True)
            write(load_dir/'command.json',command)
            cleanup=stop_owned(program)
            command.update(returncode=program.returncode,finished_utc=utc(),owned_group_cleanup=cleanup)
            write(load_dir/'command.json',command)
            raise RuntimeError('Native volatile programming Tcl exceeded 180-second limit')
        command.update(returncode=program_code,finished_utc=utc(),timeout=False)
        write(load_dir/'command.json',command)
        need(program_code==0,'Native volatile programming Tcl failed')
        receipt=parse_program_receipt((load_dir/'program.tsv').read_text())
        expected={'TARGET':TARGET,'DNA_PORT':DNA,'TCK_HZ':'3000000','IDCODE_BEFORE':IDCODE,'IDCODE_AFTER':IDCODE,
            'INIT_COMPLETE':'1','DONE':'1','PROGRAM_RETURNED':'1','PROGRAMMED':'1','CLEANUP':'1','PASS':'1',
            'PROGRAM_FILE':str(bit),'BITSTREAM_SHA256':image['bitstream_sha256'],'USR_ACCESS':SOURCE}
        need(set(receipt)==set(expected) and all(receipt.get(key)==value for key,value in expected.items() if key!='USR_ACCESS') and
             receipt.get('USR_ACCESS','').lower()==SOURCE,'Full512 image programming receipt mismatch: '+repr(receipt))
        record.update(hardware_programmed=True,program_receipt_sha256=sha(load_dir/'program.tsv')); write(run/'report.json',record)
        recheck_admission(prep,review_sha,approval_sha,bit_sha)

        # First connection records and independently audits exactly six lines, two orders.
        scratch_dir=run/'scratch'; trace_path=scratch_dir/'native-scans.jsonl'
        bridge,bridge_ready=launch_bridge(scratch_dir,render_bridge,server,record,run,logs)
        with trace_path.open('x') as trace:
            link=RecordedNativeLink(trace,'127.0.0.1',3721); links.append(link)
            device=DualDdrRawTransport(link.host,link.port,link=link); links.append(device)
            device.wait_memory_ready(timeout=30.0)
            statuses={}
            device.select_profile('cmac'); statuses['cmac_before']=device.reg_read(8)
            need(statuses['cmac_before']==0x10,'CMAC namespace not memory-ready before scratch')
            device.select_profile('ew'); statuses['ew_before']=device.reg_read(8)
            need(statuses['ew_before']==0x10,'EW namespace not memory-ready before scratch')
            result=scratch(device)
            device.select_profile('cmac'); statuses['cmac_after']=device.reg_read(8)
            device.select_profile('ew'); statuses['ew_after']=device.reg_read(8)
            need(set(statuses.values())=={0x10},'DDR namespace status changed during scratch')
            link.shutdown_bridge(); device.close()
        record['tests'].append(dict(result,namespace_statuses=statuses,trace=str(trace_path),trace_sha256=sha(trace_path)))
        wait_owned_natural(bridge,20); bridge=None
        scratch_audit=run/'scratch'/'independent-wire-audit.json'
        audit_scratch=PKG/'audit_scratch.py'
        need(sha(audit_scratch)==prep['scratch_auditor_sha256'],'Root scratch auditor changed')
        cmd=[sys.executable,str(audit_scratch),'--trace',str(trace_path),'--out',str(scratch_audit)]
        p=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True,timeout=120)
        (run/'scratch'/'audit.stdout.log').write_text(p.stdout); (run/'scratch'/'audit.stderr.log').write_text(p.stderr)
        need(p.returncode==0 and 'PASS_FIXED_DUAL_DDR_SCRATCH_WIRE_REPLAY_ONLY' in p.stdout,'Independent scratch audit failed')
        recheck_admission(prep,review_sha,approval_sha,bit_sha)
        record['scratch_audit_sha256']=sha(scratch_audit); record['scratch_auditor_source_sha256']=prep['scratch_auditor_sha256']; write(run/'report.json',record)

        # The unchanged trained worker gets a new bridge after scratch transport teardown.
        trained_dir=run/'trained-tile'; bridge,ready=launch_bridge(run/'trained-bridge',render_bridge,server,record,run,logs)
        vectors=pathlib.Path(prep['trained_vectors_path'])
        worker_cmd=['python3',str(ROOT/'tools/tinystories/run_projection.py'),'--vectors',str(vectors),
            '--vectors-sha256',prep['trained_vectors_report_sha256'],'--memory-profile','ddr','--port','3721','--quit-bridge','--out',str(trained_dir)]
        write(run/'trained-worker-command.json',{'argv':worker_cmd,'started_utc':utc(),'script_sha256':prep['runtime_source_hashes']['tools/tinystories/run_projection.py'],'vectors_report_sha256':prep['trained_vectors_report_sha256']})
        with (run/'trained-worker.stdout.log').open('x') as out, (run/'trained-worker.stderr.log').open('x') as err:
            worker_proc=start_owned(worker_cmd,out,ROOT,err)
            worker_code=worker_proc.wait()
            worker_proc=None
        wait_owned_natural(bridge,20); bridge=None
        need(worker_code==0,'Original trained tile worker failed; preserve complete output')
        recheck_admission(prep,review_sha,approval_sha,bit_sha)
        auditor=ROOT/'tools/ddr/audit_trained_tile.py'; audit_path=run/'trained-audit.json'
        audit_cmd=['python3',str(auditor),'--worker',str(trained_dir),'--vectors',str(vectors),
            '--vectors-sha256',prep['trained_vectors_report_sha256'],'--out',str(audit_path)]
        with (run/'trained-audit.stdout.log').open('x') as out, (run/'trained-audit.stderr.log').open('x') as err:
            audited=subprocess.run(audit_cmd,cwd=ROOT,stdout=out,stderr=err,timeout=300)
        need(audited.returncode==0 and load(audit_path)['status']=='PASS_INDEPENDENT_DDR_TRAINED_TILE_RAW_WIRE_AUDIT_ONLY','Independent trained tile audit failed')
        recheck_admission(prep,review_sha,approval_sha,bit_sha)
        record.update(status='PASS_FULL512_CH1_SCRATCH_AND_TRAINED_TILE_REQUIRES_ROOT_AUDIT',
            scratch_audit_sha256=sha(scratch_audit),trained_worker_report_sha256=sha(trained_dir/'report.json'),
            trained_audit_sha256=sha(audit_path),flash_written=False,full_capacity_qualified=False,
            ecc_injection_qualified=False,full512_ddr_integrated=False,pcie_tested=False)
    except BaseException as error:
        record.update(status='FAIL_FULL512_CH1_TRAINED_VOLATILE_TRIAL',error=repr(error))
        raise
    finally:
        QUIESCING=True
        signal.alarm(0)
        for link in links:
            try: link.close()
            except BaseException: pass
        # Track and quiesce every started group, including a bridge whose READY
        # helper raised before returning its local handle.
        record['owned_process_groups']=cleanup_owned_groups()
        record['owned_process_groups_absent_before_lease_release']=True
        for log in logs:
            try: log.close()
            except BaseException: pass
        record['finished_utc']=utc()
        record['artifacts']={str(p.relative_to(run)):sha(p) for p in sorted(run.rglob('*')) if p.is_file() and p!=run/'report.json'}
        write(run/'report.json',record)
        if lease is not None:
            fcntl.flock(lease,fcntl.LOCK_UN); lease.close()
    print(json.dumps({'status':record['status'],'report':str(run/'report.json'),'flash_written':False}),flush=True)

def launch_bridge(out,render_bridge,server,record,run,logs):
    out.mkdir(parents=True,exist_ok=False)
    ready=out/'ready.txt'; script=out/'bridge.tcl'
    script.write_text(render_bridge(TARGET,'localhost:3125',SOURCE,ready,3721))
    argv=[str(VIVADO),'-mode','batch','-source',str(script),'-log',str(out/'vivado.log'),'-journal',str(out/'vivado.jou')]
    log=(out/'bridge-stdout.log').open('x'); logs.append(log)
    child=start_owned(argv,log,out)
    record.setdefault('bridge_processes',[]).append({'pid':child.pid,'argv':argv,'script_sha256':sha(script),'started_utc':utc()})
    write(run/'report.json',record)
    limit=time.monotonic()+90
    while not ready.exists():
        need(child.poll() is None,'Owned bridge exited before READY')
        need(time.monotonic()<limit,'Owned bridge startup timeout'); time.sleep(.1)
    need(ready.read_text().strip()=='PASS_AUDITED_NATIVE_USER2_BRIDGE_READY','Wrong bridge READY')
    return child,ready

def main_entry():
    try: return main()
    except RuntimeError as error:
        print(json.dumps({'status':'BLOCKED_OR_FAILED','error':str(error),'hardware_accessed':False,'flash_written':False}),file=sys.stderr)
        return 2

if __name__=='__main__': raise SystemExit(main_entry())
