"""Audited volatile capacity trial; default operation is offline preflight.

The reviewed image and root execution binding remain absent until the fresh
route/image gates pass. Reuses unchanged process/lease and loader utilities;
does not delegate its new-source/image admission to their historical checks.
"""
from pathlib import Path
import argparse
import datetime
import fcntl
import hashlib
import importlib.util
import json
import signal
import socket
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
BASE = Path(__file__).resolve().parent
PREP = BASE / 'preparation.json'
TARGET = 'localhost:3125/xilinx_tcf/Xilinx/80802026a77a01'
DNA = '004E544714C705C'
IDCODE = '23751093'
REVIEW_STATUS = 'PASS_ROOT_REVIEWED_FULL512_RETIRE_IMAGE'
APPROVAL_STATUS = 'ROOT_APPROVED_FULL512_RETIRE_VOLATILE_TRIAL'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def frozen(prep):
    for path, digest in prep['frozen_inputs'].items():
        need(sha(path) == digest, 'Frozen preparation input changed: ' + path)
    manifest = prep['hardware_source_manifest']
    digest = hashlib.sha256(json.dumps(manifest, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    need(digest == prep['source_manifest_sha256'] and digest[:8] == prep['source_tag'],
         'New retirement source manifest/tag changed')
    need(len(manifest['files']) == 171 and manifest['top'] == 'ypcb_ddr_dual_top' and
         manifest['part'] == 'xc7k480tffg1156-2' and
         manifest['profile'] == 'full512-ch1-ddr-capacity-retire-snapshot-ecc-test-off',
         'Retirement source closure changed')
    for path, digest in manifest['files'].items():
        need(sha(path) == digest, 'Capacity hardware input changed: ' + path)


def admission(prep):
    frozen(prep)
    for key, filename in (('image_review_sha256', 'image-review.json'),
                          ('execution_approval_sha256', 'execution-approval.json')):
        path = BASE / filename
        need(prep.get(key) and path.is_file() and sha(path) == prep[key],
             'Pending exact capacity image/execution binding: ' + filename)
    image = load(BASE / 'image-review.json')
    approval = load(BASE / 'execution-approval.json')
    need(image['status'] == REVIEW_STATUS and approval['status'] == APPROVAL_STATUS and
         approval['approved'] is True, 'Capacity review/approval incomplete')
    expected = dict(top='ypcb_ddr_dual_top', part='xc7k480tffg1156-2',
                    source_manifest_sha256=prep['source_manifest_sha256'], source_tag=prep['source_tag'],
                    target=TARGET, expected_dna_port=DNA, expected_raw_idcode=IDCODE,
                    product_dsps=512, total_dsps=516, bram_blocks=0,
                    memory_profile='ddr', selected_physical_channel=1,
                    capacity_base=0, capacity_bytes=1 << 31, ecc_test_enabled=False,
                    programming_scope='volatile-sram', flash_authorized=False)
    for key, value in expected.items():
        need(image.get(key) == value and approval.get(key) == value,
             'Wrong capacity image/approval binding: ' + key)
    need(image.get('flash_authorized') is False and approval.get('flash_authorized') is False and
         image.get('ecc_test_enabled') is False and approval.get('ecc_test_enabled') is False,
         'Explicit false flash/ECC-test policy required')
    need(approval['image_review_sha256'] == prep['image_review_sha256'] and
         approval['bitstream_sha256'] == image['bitstream_sha256'], 'Approval names another image')
    need(image.get('bound_files') and image.get('route_review_path') in image['bound_files'] and
         image.get('bitfile_audit_path') in image['bound_files'], 'Missing route/bitfile review bindings')
    for path, digest in image['bound_files'].items():
        need(sha(path) == digest, 'Reviewed image dependency changed: ' + path)
    need(load(image['route_review_path']).get('status') == 'PASS_ROOT_FULL512_RETIRE_ROUTE_TIMING',
         'Capacity route/timing review has not passed')
    need(load(image['bitfile_audit_path']).get('status') == 'PASS_INDEPENDENT_FULL512_RETIRE_BITFILE_AUDIT',
         'Capacity bitfile audit has not passed')
    bit = Path(image['bitstream_path'])
    need(sha(bit) == image['bitstream_sha256'], 'Exact capacity bitstream changed')
    return image, approval, bit


def utility_module(prep):
    path = Path(prep['utility_path'])
    spec = importlib.util.spec_from_file_location('capacity_owned_utilities', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run_trial(prep):
    image, approval, bit = admission(prep)
    common = utility_module(prep)
    from tools.host.native_link import render_bridge
    from tools.tinystories.native_trace import RecordedNativeLink
    from tools.tinystories.audit_scans import commands
    from tools.ddr.dual_transport import DualDdrRawTransport
    from tools.ddr.raw_test import run_case
    from tools.ddr.raw_test import scratch
    from tools.ddr.capacity_client import CapacityClient
    from tools.ddr.audit_capacity import audit as audit_capacity
    from tools.ddr.audit_raw_case import replay as audit_raw
    available = int(next(row.split()[1] for row in Path('/proc/meminfo').read_text().splitlines()
                         if row.startswith('MemAvailable:'))) * 1024
    need(available >= 4 << 30, 'Less than 4 GiB available for physical runtime')
    output = BASE / 'physical-test'
    output.mkdir(exist_ok=False)
    record = dict(status='RUNNING_REVIEWED_FULL512_RETIRE_TRIAL', started_utc=utc(),
                  image_review_sha256=prep['image_review_sha256'],
                  execution_approval_sha256=prep['execution_approval_sha256'],
                  bitstream_sha256=sha(bit), source_tag=prep['source_tag'],
                  target=TARGET, expected_dna_port=DNA, expected_raw_idcode=IDCODE,
                  hardware_accessed=False, hardware_programmed=False, flash_written=False,
                  full_capacity_qualified=False, ecc_injection_qualified=False,
                  live_joint_reset_tested=False, pcie_tested=False, phases=[])
    lease = None
    logs = []
    links = []

    def save():
        write(output / 'report.json', record)

    def program(epoch):
        admission(prep)
        directory = output / ('load-' + str(epoch))
        directory.mkdir()
        text = Path(prep['program_template_path']).read_text()
        for key, value in dict(TARGET=TARGET, BITSTREAM=bit, RECEIPT=directory / 'program.tsv',
                               USR_ACCESS=prep['source_tag'], BITSTREAM_SHA=sha(bit)).items():
            marker = '@' + key + '@'
            need(text.count(marker) == 1, 'Changed loader marker: ' + key)
            text = text.replace(marker, common.literal(value))
        script = directory / 'program.tcl'
        script.write_text(text)
        log = (directory / 'stdout.log').open('x')
        logs.append(log)
        argv = [str(common.VIVADO), '-mode', 'batch', '-source', str(script),
                '-log', str(directory / 'vivado.log'), '-journal', str(directory / 'vivado.jou')]
        record['hardware_accessed'] = True
        record['hardware_programming_may_have_occurred'] = True
        command = dict(argv=argv, started_utc=utc(), script_sha256=sha(script))
        write(directory / 'command.json', command)
        save()
        child = common.start_owned(argv, log, directory)
        command.update(pid=child.pid, pgid=child.pid)
        write(directory / 'command.json', command)
        cleanup = common.wait_owned_natural(child, 180)
        command.update(returncode=child.returncode, cleanup=cleanup, finished_utc=utc())
        write(directory / 'command.json', command)
        need(child.returncode == 0, 'Reviewed volatile load failed')
        receipt = common.parse_program_receipt((directory / 'program.tsv').read_text())
        expected = dict(TARGET=TARGET, DNA_PORT=DNA, TCK_HZ='3000000', IDCODE_BEFORE=IDCODE,
                        IDCODE_AFTER=IDCODE, INIT_COMPLETE='1', DONE='1', PROGRAM_RETURNED='1',
                        PROGRAMMED='1', CLEANUP='1', PASS='1', PROGRAM_FILE=str(bit),
                        BITSTREAM_SHA256=sha(bit), USR_ACCESS=prep['source_tag'])
        need(set(receipt) == set(expected) and all(
             receipt[k].lower() == v.lower() if k in ('USR_ACCESS', 'DNA_PORT') else receipt[k] == v
             for k, v in expected.items()), 'Exact programming/target receipt differs')
        record['hardware_programmed'] = True
        record.setdefault('load_receipts', []).append(dict(epoch=epoch, path=str(directory / 'program.tsv'),
                                                          sha256=sha(directory / 'program.tsv')))
        save()

    def phase(name, callback):
        directory = output / name
        directory.mkdir()
        bridge_dir = directory / 'bridge'
        bridge_dir.mkdir()
        ready = bridge_dir / 'ready.txt'
        script = bridge_dir / 'bridge.tcl'
        script.write_text(render_bridge(TARGET, 'localhost:3125', prep['source_tag'], ready, 3721))
        log = (bridge_dir / 'stdout.log').open('x')
        logs.append(log)
        argv = [str(common.VIVADO), '-mode', 'batch', '-source', str(script),
                '-log', str(bridge_dir / 'vivado.log'), '-journal', str(bridge_dir / 'vivado.jou')]
        child = common.start_owned(argv, log, bridge_dir)
        row = dict(name=name, started_utc=utc(), bridge_pid=child.pid, bridge_argv=argv,
                   bridge_script_sha256=sha(script), status='RUNNING')
        record['phases'].append(row)
        save()
        limit = time.monotonic() + 90
        while not ready.exists():
            need(child.poll() is None and time.monotonic() < limit, 'Bridge startup failed/timed out')
            time.sleep(.1)
        need(ready.read_text().strip() == 'PASS_AUDITED_NATIVE_USER2_BRIDGE_READY', 'Wrong bridge readiness')
        trace_path = directory / 'native-scans.jsonl'
        with trace_path.open('x') as stream:
            link = RecordedNativeLink(stream, '127.0.0.1', 3721)
            links.append(link)
            device = DualDdrRawTransport(link.host, link.port, link=link)
            links.append(device)
            device.wait_memory_ready(timeout=30)
            result = callback(device, directory)
            link.shutdown_bridge()
            device.close()
        row.update(result=result, trace_sha256=sha(trace_path),
                   bridge_cleanup=common.wait_owned_natural(child, 20),
                   finished_utc=utc(), status='PASS_DEVICE_PHASE_REQUIRES_WIRE_AUDIT')
        need(child.returncode == 0, 'Bridge did not exit cleanly')
        admission(prep)
        save()
        return directory, row

    def normal(epoch, case):
        profile = case['profile']
        def execute(device, directory):
            device.select_profile(profile)
            return run_case(device, case['upload'], case['expected'], directory / 'observed.txt',
                            command_address=case['command_address'], initial_amount=case['amount'],
                            expected_tasks=case['tasks'], tag=case['tag'])
        directory, row = phase(f'epoch-{epoch}-{profile}', execute)
        stats = {}
        result = audit_raw(commands(directory / 'native-scans.jsonl', stats),
                           case['upload'], case['expected'], profile=profile,
                           command_address=case['command_address'], amount=case['amount'],
                           tasks=case['tasks'], tag=case['tag'])
        write(directory / 'independent-wire-audit.json', dict(result, scan_statistics=stats))
        row['wire_audit_sha256'] = sha(directory / 'independent-wire-audit.json')
        save()

    save()
    try:
        for signum in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP, signal.SIGALRM):
            signal.signal(signum, common.interrupted)
        signal.alarm(1800)
        lease, lease_receipt = common.hardware_admission(image, approval, bit, prep)
        record['lease_admission'] = lease_receipt
        admission(prep)
        log = (output / 'hw-server.log').open('x')
        logs.append(log)
        server = common.start_owned([str(common.HWSERVER), '-s', 'tcp::3125'], log, output)
        record['hw_server_pid'] = server.pid
        save()
        limit = time.monotonic() + 20
        while True:
            need(server.poll() is None, 'Owned hw_server exited')
            with socket.socket() as sock:
                sock.settimeout(.2)
                if sock.connect_ex(('127.0.0.1', 3125)) == 0:
                    break
            need(time.monotonic() < limit, 'Owned hw_server startup timeout')
            time.sleep(.1)
        program(1)
        def scratch_case(device, directory):
            device.select_profile('cmac')
            device.select_profile('ew')
            result = scratch(device)
            device.select_profile('cmac')
            device.select_profile('ew')
            return result
        directory, row = phase('scratch', scratch_case)
        spec = importlib.util.spec_from_file_location('capacity_scratch_audit', prep['scratch_auditor_path'])
        scratch_auditor = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(scratch_auditor)
        stats = {}
        scratch_result = scratch_auditor.replay(commands(directory / 'native-scans.jsonl', stats))
        write(directory / 'independent-wire-audit.json', dict(scratch_result, scan_statistics=stats))
        row['wire_audit_sha256'] = sha(directory / 'independent-wire-audit.json')
        save()
        for case in prep['normal_cases']:
            normal(1, case)
        def sweep(device, directory):
            with (directory / 'progress.jsonl').open('x') as progress:
                def update(snapshot):
                    progress.write(json.dumps(dict(utc=utc(), **snapshot)) + '\n')
                    progress.flush()
                return CapacityClient(device).run(timeout=600, on_progress=update)
        directory, row = phase('capacity', sweep)
        write(directory / 'independent-wire-audit.json', audit_capacity(directory / 'native-scans.jsonl'))
        row['wire_audit_sha256'] = sha(directory / 'independent-wire-audit.json')
        save()
        # Deliberate reviewed volatile reconfiguration; no implicit fault retry.
        program(2)
        for case in prep['normal_cases']:
            normal(2, case)
        admission(prep)
        record['status'] = 'PASS_DEVICE_FULL512_RETIRE_CAPACITY_AND_RECONFIGURED_RAW_JOBS_REQUIRES_ROOT_REVIEW'
    except BaseException as error:
        record.update(status='FAIL_FULL512_RETIRE_VOLATILE_TRIAL', error=repr(error))
        raise
    finally:
        common.QUIESCING = True
        signal.alarm(0)
        for link in reversed(links):
            try:
                link.close()
            except BaseException:
                pass
        record['owned_groups'] = common.cleanup_owned_groups()
        record['owned_groups_absent_before_lease_release'] = True
        for log in logs:
            log.close()
        record['finished_utc'] = utc()
        record['artifacts'] = {str(p.relative_to(output)): sha(p) for p in sorted(output.rglob('*'))
                               if p.is_file() and p != output / 'report.json'}
        save()
        if lease is not None:
            fcntl.flock(lease, fcntl.LOCK_UN)
            lease.close()
    print(json.dumps(dict(status=record['status'], report=str(output / 'report.json'))))


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute-volatile-sram', action='store_true')
    args = parser.parse_args(argv)
    prep = load(PREP)
    frozen(prep)
    if not args.execute_volatile_sram:
        pending = []
        for key in ('image_review_sha256', 'execution_approval_sha256'):
            if not prep.get(key):
                pending.append(key)
        if not pending:
            admission(prep)
        print(json.dumps(dict(status='PREPARED_PENDING_RETIRE_CAPACITY_IMAGE' if pending else 'READY_EXPLICIT_EXECUTION_REQUIRED',
                              pending=pending, hardware_accessed=False, flash_written=False,
                              source_tag=prep['source_tag'])))
        return 0
    run_trial(prep)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
